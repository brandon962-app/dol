"use strict";
(() => {
  // src/ui/visual-scope.ts
  function visualScope() {
    const frames = /* @__PURE__ */ new Map(), cleanups = /* @__PURE__ */ new Set();
    let disposed = false;
    function cancelFrame(task) {
      const id = frames.get(task);
      if (id !== void 0) {
        cancelAnimationFrame(id);
        frames.delete(task);
      }
    }
    function cancelFrames() {
      for (const id of frames.values()) cancelAnimationFrame(id);
      frames.clear();
    }
    function own(cleanup) {
      let live = true;
      const release = () => {
        if (!live) return;
        live = false;
        cleanups.delete(release);
        cleanup();
      };
      if (disposed) release();
      else cleanups.add(release);
      return release;
    }
    return {
      active: () => !disposed,
      cancelFrame,
      cancelFrames,
      own,
      timeout(task, delay) {
        if (disposed) return () => {
        };
        let pending = true;
        const id = setTimeout(() => {
          if (!pending) return;
          release();
          if (!disposed) task();
        }, delay), release = own(() => {
          pending = false;
          clearTimeout(id);
        });
        return release;
      },
      frame(task) {
        if (disposed || frames.has(task)) return false;
        const id = requestAnimationFrame(() => {
          if (disposed || frames.get(task) !== id) return;
          frames.delete(task);
          task();
        });
        frames.set(task, id);
        return true;
      },
      dispose() {
        if (disposed) return;
        disposed = true;
        cancelFrames();
        const errors = [];
        for (const cleanup of [...cleanups].reverse()) try {
          cleanup();
        } catch (error) {
          errors.push(error);
        }
        cleanups.clear();
        if (errors.length) throw new AggregateError(errors, "Visual scope cleanup failed");
      }
    };
  }

  // compat/reoverfits-soft-wet/reoverfits-soft-wet.ts
  (() => {
    const host = window;
    if (host.ReOverfitsSoftWet) return;
    const icons = { overhead: "\u5916\u5C42\u5934\u9970", overupper: "\u5916\u5957\u4E0A\u88C5", overlower: "\u5916\u5957\u4E0B\u88C5" };
    const undo = /* @__PURE__ */ new Map();
    let owner, mapping;
    const scope = visualScope();
    let reason = "runtime-unavailable";
    function supported() {
      const version = host.modUtils?.getMod("ReOverfits")?.version;
      if (typeof version !== "string" || !/^\d+(?:\.\d+){1,3}(?:-[\w.-]+)?(?:\+[\w.-]+)?$/.test(version)) return false;
      try {
        const tools = host.modUtils?.getSemVerTools?.();
        return !!tools && tools.satisfies(tools.parseVersion(version).version, tools.parseRange(">=4.1.1"));
      } catch {
        return false;
      }
    }
    function attribute(el, name, value) {
      if (el.getAttribute(name) === value) return;
      let changes = undo.get(el);
      if (!changes) {
        changes = /* @__PURE__ */ new Map();
        undo.set(el, changes);
      }
      if (!changes.has(name)) changes.set(name, { before: el.getAttribute(name), applied: value });
      else changes.get(name).applied = value;
      el.setAttribute(name, value);
    }
    function restore() {
      for (const [el, changes] of undo) for (const [name, change] of changes) {
        if (el.getAttribute(name) !== change.applied) continue;
        if (change.before === null) el.removeAttribute(name);
        else el.setAttribute(name, change.before);
      }
      undo.clear();
    }
    function attach() {
      const api = host.DoLGameUI?.wardrobe;
      const compatible = supported();
      if (compatible && owner === api && mapping) return;
      mapping?.destroy();
      mapping = void 0;
      owner = api;
      reason = "wardrobe-api-unavailable";
      if (!compatible) {
        reason = "target-version-mismatch";
        return;
      }
      if (api?.apiVersion !== 1 || typeof api.registerSlotMapping !== "function") return;
      try {
        mapping = api.registerSlotMapping({ id: "ReOverfitsSoftWet", target: { name: "ReOverfits", versions: [">=4.1.1"] }, slots: { over_head: "\u5916\u5C42\u5934\u9970", over_upper: "\u5916\u5957\u4E0A\u88C5", over_lower: "\u5916\u5957\u4E0B\u88C5" } });
        reason = "model-registered";
      } catch {
        reason = "registration-failed";
      }
    }
    function refresh() {
      observer.disconnect();
      attach();
      for (const el of undo.keys()) if (!el.isConnected) undo.delete(el);
      const ui = host.DoLGameUI?.ui;
      if (!mapping || !supported() || !ui?.getCapabilities?.().enabled) restore();
      else for (const img of document.querySelectorAll(".passage:not(.passage-out) #clothingShop-div img")) {
        const match = /^img\/ui\/clothes\/categories\/(overhead|overupper|overlower)\.png$/.exec(img.getAttribute("ml-src") ?? img.getAttribute("src") ?? "");
        if (!match) continue;
        const label = match[1] ? icons[match[1]] : void 0;
        if (!label) continue;
        const tab = img.closest(".category-tab"), link = tab?.querySelector("a.link-internal");
        if (tab && link && !link.textContent?.trim()) {
          attribute(tab, "data-reoverfits-category", label);
          attribute(link, "aria-label", label);
          attribute(tab, "title", label);
        } else if (img.nextElementSibling?.matches("a.link-internal")) {
          attribute(img, "data-reoverfits-entry-icon", "");
          attribute(img.nextElementSibling, "data-reoverfits-entry", "");
        }
      }
      if (scope.active()) {
        const passages = document.getElementById("passages");
        if (passages) observer.observe(passages, { childList: true, subtree: true });
      }
    }
    function schedule() {
      scope.frame(refresh);
    }
    const observer = new MutationObserver(schedule), themeObserver = new MutationObserver(schedule);
    themeObserver.observe(document.documentElement, { attributes: true, attributeFilter: ["data-dol-midnight"] });
    document.addEventListener("dol-ui-runtime-ready", schedule);
    scope.own(() => observer.disconnect());
    scope.own(() => themeObserver.disconnect());
    Object.assign(host, { ReOverfitsSoftWet: Object.freeze({
      getDiagnostics: () => Object.freeze({ adapterVersion: "1.0.0", target: "ReOverfits", targetVersion: host.modUtils?.getMod("ReOverfits")?.version ?? "", supportedVersions: [">=4.1.1"], level: "UI Model Extension", reason }),
      destroy() {
        scope.dispose();
        document.removeEventListener("dol-ui-runtime-ready", schedule);
        mapping?.destroy();
        mapping = void 0;
        owner = void 0;
        restore();
        delete host.ReOverfitsSoftWet;
      }
    }) });
    refresh();
  })();
})();
