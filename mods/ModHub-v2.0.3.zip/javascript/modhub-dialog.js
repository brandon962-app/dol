/**
 * ModHub - 公共提示与原生暗黑模态框。
 * 在早期注入阶段提供转义与弹窗接口；弹窗栈仅在本文件中维护。
 */

window.modHubEscapeHtml = function(str) {
    return String(str ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;')
        .replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
};

// 仅共同模组的相对顺序变化算重排，增删造成的序号偏移单独说明。
window.modHubDescribeOrderChanges = function(before, after) {
    const previous = new Map(before.map((name, index) => [name, index + 1]));
    const target = new Map(after.map((name, index) => [name, index + 1]));
    const shared = new Map(before.filter(name => target.has(name)).map((name, index) => [name, index]));
    const changes = [];
    let sharedIndex = 0;
    for (const name of after) {
        if (!previous.has(name)) {
            changes.push({ name, kind: 'added', currentIndex: null, targetIndex: target.get(name) });
            continue;
        }
        if (shared.get(name) !== sharedIndex) changes.push({ name, kind: 'moved', currentIndex: previous.get(name), targetIndex: target.get(name) });
        sharedIndex++;
    }
    for (const name of before) if (!target.has(name)) changes.push({ name, kind: 'removed', currentIndex: previous.get(name), targetIndex: null });
    return changes;
};

const MODHUB_PROGRESS_FRAMES = Array.from({ length: 120 }, (_, index) => String.fromCharCode(0xE000 + index)).join('');
let modHubProgressFontLoading = false;

window.modHubProgressRingHtml = function(percent = null, label = '', describedBy = '') {
    if (document.fonts?.load && !modHubProgressFontLoading) {
        modHubProgressFontLoading = true;
        document.fonts.load('32px ModHubProgress', MODHUB_PROGRESS_FRAMES).then(fonts => {
            if (fonts.length) document.documentElement?.classList.add('modhub-progress-font-ready');
            else modHubProgressFontLoading = false;
        }).catch(() => { modHubProgressFontLoading = false; });
    }
    const value = Number.isFinite(percent) ? Math.max(0, Math.min(100, percent)) : null;
    const escape = window.modHubEscapeHtml;
    const semantics = label ? ' role="progressbar" aria-label="' + escape(window.modHubT?.(label) || label) + '" aria-valuemin="0" aria-valuemax="100"'
        + (value === null ? '' : ' aria-valuenow="' + value + '"') : ' aria-hidden="true"';
    return '<svg class="modhub-progress-ring' + (value === null ? '' : ' is-determinate') + '" viewBox="0 0 32 32" focusable="false"' + semantics
        + (describedBy ? ' aria-describedby="' + escape(describedBy) + '"' : '') + '>'
        + '<text class="modhub-progress-frames" x="0" y="32" display="none" aria-hidden="true">' + MODHUB_PROGRESS_FRAMES + '</text>'
        + '<circle class="modhub-progress-indeterminate" cx="16" cy="16" r="13"></circle>'
        + '<circle class="modhub-progress-track" cx="16" cy="16" r="13"></circle><circle class="modhub-progress-value" cx="16" cy="16" r="13" pathLength="100" stroke-dasharray="100 100" stroke-dashoffset="'
        + (value === null ? 100 : 100 - value) + '" opacity="' + (value === 0 ? 0 : 1) + '"></circle></svg>';
};

window.modHubSetProgressRing = function(ring, percent) {
    if (!ring) return;
    const value = Number.isFinite(percent) ? Math.max(0, Math.min(100, percent)) : null;
    ring.classList.toggle('is-determinate', value !== null);
    if (value === null) ring.removeAttribute('aria-valuenow');
    else if (ring.getAttribute('role') === 'progressbar') ring.setAttribute('aria-valuenow', String(value));
    const arc = ring.querySelector('.modhub-progress-value');
    if (arc) {
        arc.setAttribute('stroke-dashoffset', String(value === null ? 100 : 100 - value));
        arc.setAttribute('opacity', value === 0 ? '0' : '1');
    }
};

const modHubBusyButtons = new WeakMap();

window.modHubSetButtonBusy = function(button, busy) {
    if (!button) return;
    const previous = modHubBusyButtons.get(button);
    if (busy) {
        if (previous) return;
        const label = document.createElement('span');
        label.className = 'modhub-button-busy-label';
        while (button.firstChild) label.appendChild(button.firstChild);
        const ring = document.createElement('span');
        ring.className = 'modhub-button-busy-ring';
        ring.innerHTML = window.modHubProgressRingHtml();
        modHubBusyButtons.set(button, {
            disabled: button.disabled,
            ariaBusy: button.getAttribute('aria-busy'),
            label,
            ring
        });
        button.appendChild(ring);
        button.appendChild(label);
        button.classList.add('modhub-button-busy');
        button.disabled = true;
        button.setAttribute('aria-busy', 'true');
    } else if (previous) {
        previous.ring.remove();
        while (previous.label.firstChild) button.insertBefore(previous.label.firstChild, previous.label);
        previous.label.remove();
        button.classList.remove('modhub-button-busy');
        button.disabled = previous.disabled;
        if (previous.ariaBusy === null) button.removeAttribute('aria-busy');
        else button.setAttribute('aria-busy', previous.ariaBusy);
        modHubBusyButtons.delete(button);
    }
};

window.modHubYieldToBrowser = function() {
    if (typeof window.requestAnimationFrame !== 'function') return Promise.resolve();
    return new Promise(resolve => {
        const fallback = setTimeout(() => {
            window.cancelAnimationFrame?.(frame);
            resolve();
        }, 80);
        const frame = window.requestAnimationFrame(() => {
            clearTimeout(fallback);
            setTimeout(resolve, 0);
        });
    });
};

window.modHubLoadingHtml = function(message) {
    const html = '<div class="modhub-loading-state grey" role="status" aria-live="polite">' + window.modHubProgressRingHtml()
        + '<p>' + window.modHubEscapeHtml(message) + '</p></div>';
    return window.modHubTranslateHtml?.(html) || html;
};

// 统一 Toast 提示
window.modHubShowToast = function(message, type = '', duration = 2500) {
    let toast = document.getElementById('modHubToast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'modHubToast';
        toast.className = 'toast';
        document.body.appendChild(toast);
    }
    if (window.modHubBindText) window.modHubBindText(toast, message);
    else toast.textContent = message;
    toast.className = 'toast ' + type + ' show';
    if (window._modHubToastTimer) clearTimeout(window._modHubToastTimer);
    window._modHubToastTimer = setTimeout(() => {
        toast.classList.remove('show');
    }, Math.max(1000, duration || 2500));
};

/**
 * 游戏原生暗黑风格确认模态框（替代浏览器原生突兀白底 confirm）
 * @param {Object|string} options 参数对象或提示文字
 * @returns {Promise<boolean>}
 */
// 活动模态弹窗栈，支持多层弹窗平滑嵌套与层级递增，彻底杜绝子弹窗破坏父弹窗 DOM
const modHubModalStack = [];
let modHubModalSequence = 0;

window.modHubConfirm = function(options) {
    window.modHubEnsureStyles?.({ active: true });
    let title = '提示';
    let message = '';
    let confirmText = '确定';
    let cancelText = '取消';
    let isDanger = false;
    let selectOptions = [];
    let selectValue = '';
    let selectLabel = '请选择';
    let trustedMessageHtml = '';
    let dialogClass = '';
    let requireSelection = false;
    let confirmDelay = 0;

    let customResult = null;
    let onRender = null;
    let validateConfirm = null;

    if (typeof options === 'string') {
        message = options;
    } else if (options && typeof options === 'object') {
        title = options.title || '提示';
        message = options.message || '';
        confirmText = options.confirmText || '确定';
        cancelText = options.cancelText !== undefined ? options.cancelText : '取消';
        isDanger = options.confirmType === 'danger';
        selectOptions = Array.isArray(options.selectOptions) ? options.selectOptions : [];
        selectValue = options.selectValue !== undefined ? String(options.selectValue) : (selectOptions[0]?.value || '');
        selectLabel = options.selectLabel || '请选择';
        trustedMessageHtml = typeof options.trustedMessageHtml === 'string' ? options.trustedMessageHtml : '';
        dialogClass = String(options.dialogClass || '').split(/\s+/).filter(name => /^[a-z0-9_-]+$/i.test(name)).join(' ');
        requireSelection = options.requireSelection === true;
        if (Number(options.confirmDelay) > 0) confirmDelay = Math.ceil(Number(options.confirmDelay));
        if (typeof options.customResult === 'function') customResult = options.customResult;
        if (typeof options.onRender === 'function') onRender = options.onRender;
        if (typeof options.canConfirm === 'function') validateConfirm = options.canConfirm;
    }

    // 针对非 DOM / Node 单元测试环境的安全回退
    if (typeof document === 'undefined' || !document.createElement || !document.body) {
        return Promise.resolve(false);
    }

    return new Promise((resolve) => {
        const previousFocus = document.activeElement;
        const stackLevel = modHubModalStack.length;
        const titleId = `modHubConfirmTitle_${++modHubModalSequence}`;
        const overlay = document.createElement('div');
        overlay.id = stackLevel === 0 ? 'modHubConfirmOverlay' : `modHubConfirmOverlay_${stackLevel}`;
        overlay.className = 'modhub-modal-backdrop';
        overlay.style.zIndex = String(100000 + stackLevel * 20);

        const dialog = document.createElement('div');
        dialog.className = `modhub-modal-dialog${dialogClass ? ` ${dialogClass}` : ''}`;
        dialog.setAttribute('role', 'dialog');
        dialog.setAttribute('aria-modal', 'true');
        dialog.setAttribute('aria-labelledby', titleId);
        dialog.tabIndex = -1;

        const messageHtml = trustedMessageHtml || window.modHubEscapeHtml(window.modHubT?.(message) || message).replace(/\n/g, '<br>');
        const selectHtml = selectOptions.length ? `
            <label class="modhub-modal-select-wrap">
                <span>${window.modHubEscapeHtml(selectLabel)}</span>
                <select class="modhub-modal-select">
                    ${selectOptions.map(option => `<option value="${window.modHubEscapeHtml(option.value)}" ${String(option.value) === selectValue ? 'selected' : ''} ${option.disabled ? 'disabled' : ''}>${window.modHubEscapeHtml(option.label)}</option>`).join('')}
                </select>
            </label>
        ` : '';

        const initialConfirmBtnText = confirmDelay > 0
            ? `${window.modHubT?.(confirmText) || confirmText} (${confirmDelay}s)`
            : confirmText;

        dialog.innerHTML = `
            <div class="modhub-modal-header">
                <span id="${titleId}" class="${isDanger ? 'red' : 'gold'} modhub-modal-title">${window.modHubEscapeHtml(title)}</span>
                <button type="button" class="modhub-modal-close" aria-label="关闭">&times;</button>
            </div>
            <div class="modhub-modal-body" tabindex="0" role="region" aria-label="提示内容">
                <div class="modhub-modal-message">${messageHtml}</div>
                ${selectHtml}
            </div>
            <div class="modhub-modal-footer">
                <button type="button" class="macro-button ${isDanger ? 'modhub-btn-danger' : 'modhub-btn-primary'} modhub-modal-btn-confirm"${confirmDelay > 0 ? ' disabled' : ''}>${window.modHubEscapeHtml(initialConfirmBtnText)}</button>
                ${cancelText ? `<button type="button" class="macro-button modhub-modal-btn-cancel">${window.modHubEscapeHtml(cancelText)}</button>` : ''}
            </div>
        `;
        window.modHubLocalizeOwned?.(dialog);

        overlay.appendChild(dialog);
        document.body.appendChild(overlay);

        let delayTimer = null;
        let isDelaying = confirmDelay > 0;
        let remainingSeconds = confirmDelay;

        const confirmBtn = dialog.querySelector('.modhub-modal-btn-confirm');
        const select = dialog.querySelector('.modhub-modal-select');

        const canConfirm = () => {
            if (isDelaying) return false;
            if (requireSelection && !select?.value) return false;
            if (validateConfirm && !validateConfirm(dialog)) return false;
            return true;
        };

        const syncConfirmState = () => {
            if (confirmBtn) {
                if (isDelaying) {
                    confirmBtn.disabled = true;
                } else {
                    confirmBtn.disabled = !canConfirm();
                }
            }
        };
        dialog.modHubSyncConfirmState = syncConfirmState;

        if (confirmDelay > 0) {
            delayTimer = setInterval(() => {
                remainingSeconds--;
                if (remainingSeconds <= 0) {
                    clearInterval(delayTimer);
                    delayTimer = null;
                    isDelaying = false;
                    if (confirmBtn) {
                        if (window.modHubBindText) window.modHubBindText(confirmBtn, confirmText);
                        else confirmBtn.textContent = confirmText;
                        syncConfirmState();
                    }
                } else if (confirmBtn) {
                    confirmBtn.textContent = `${window.modHubT?.(confirmText) || confirmText} (${remainingSeconds}s)`;
                }
            }, 1000);
        }

        dialog.modHubClearDelay = () => {
            if (delayTimer) {
                clearInterval(delayTimer);
                delayTimer = null;
            }
            isDelaying = false;
            syncConfirmState();
        };

        let resolved = false;
        const contains = node => node === dialog || dialog.contains?.(node) || node?.closest?.('.modhub-modal-dialog') === dialog;
        const available = node => node && node.isConnected !== false && !node.disabled && !node.hidden
            && !node.matches?.(':disabled') && !node.closest?.('[inert], [hidden]') && node.getClientRects?.().length !== 0
            && !['hidden', 'collapse'].includes(window.getComputedStyle?.(node)?.visibility);
        const focusable = () => Array.from(dialog.querySelectorAll('button, input, select, textarea, summary, a[href], [contenteditable="true"], [tabindex]'))
            .filter(node => available(node) && node.tabIndex !== -1);
        const focus = preferred => {
            const controls = focusable();
            const target = contains(preferred) && available(preferred) ? preferred
                : available(confirmBtn) ? confirmBtn : controls.find(node => node.classList.contains('modhub-modal-btn-cancel')) || controls[0] || dialog;
            target.focus?.();
        };
        const keepFocus = event => {
            if (modHubModalStack.at(-1) === modalEntry && !contains(event.target)) focus();
        };

        const getConfirmResult = () => {
            if (typeof customResult === 'function') {
                return customResult(dialog);
            }
            return selectOptions.length ? select?.value : true;
        };

        const closeWith = (result) => {
            if (resolved) return;
            resolved = true;
            const wasActive = modHubModalStack.at(-1) === modalEntry;
            if (delayTimer) {
                clearInterval(delayTimer);
                delayTimer = null;
            }
            const stackIdx = modHubModalStack.indexOf(modalEntry);
            if (stackIdx !== -1) {
                modHubModalStack.splice(stackIdx, 1);
            }

            if (typeof document.removeEventListener === 'function') {
                document.removeEventListener('keydown', handleKeydown);
                document.removeEventListener('focusin', keepFocus);
            }
            overlay.classList.add('modhub-modal-closing');
            overlay.inert = true;
            if (wasActive) {
                const parent = modHubModalStack.at(-1);
                if (parent) parent.focus(previousFocus);
                else if (available(previousFocus)) previousFocus.focus?.();
                else document.querySelector?.('.modhub-restore-panel')?.focus?.();
            }
            setTimeout(() => {
                if (overlay.parentNode) overlay.parentNode.removeChild(overlay);
                window.modHubRefreshLanguageSelectors?.();
            }, 180);
            resolve(result);
        };

        const handleKeydown = (e) => {
            // 仅有栈顶活动模态框响应按键
            if (modHubModalStack[modHubModalStack.length - 1] !== modalEntry) return;

            if (e.key === 'Escape') {
                e.preventDefault();
                closeWith(false);
            } else if (e.key === 'Tab') {
                const controls = focusable(), first = controls[0], last = controls.at(-1);
                if (!first) { e.preventDefault(); dialog.focus(); }
                else if (!controls.includes(document.activeElement)) { e.preventDefault(); (e.shiftKey ? last : first).focus(); }
                else if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
                else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
            } else if (e.key === 'Enter') {
                if (e.defaultPrevented) return;
                if (!contains(e.target || document.activeElement)) { e.preventDefault(); focus(); return; }
                if (e.target?.closest?.('button, a, input, select, textarea, summary, [contenteditable="true"]')) return;
                e.preventDefault();
                if (canConfirm()) closeWith(getConfirmResult());
            }
        };

        const modalEntry = {
            overlay,
            dialog,
            focus,
            closeWith
        };
        modHubModalStack.push(modalEntry);
        window.modHubRefreshLanguageSelectors?.();

        if (typeof document.addEventListener === 'function') {
            document.addEventListener('keydown', handleKeydown);
            document.addEventListener('focusin', keepFocus);
        }

        dialog.querySelector('.modhub-modal-close')?.addEventListener('click', () => closeWith(false));
        dialog.querySelector('.modhub-modal-btn-cancel')?.addEventListener('click', () => closeWith(false));
        confirmBtn?.addEventListener('click', () => {
            if (canConfirm()) closeWith(getConfirmResult());
        });
        select?.addEventListener('change', syncConfirmState);

        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) {
                closeWith(false);
            }
        });

        if (typeof onRender === 'function') {
            try {
                onRender(dialog);
                window.modHubLocalizeOwned?.(dialog);
            } catch (err) {
                console.warn('[modHubConfirm] onRender 执行异常:', err);
            }
        }
        syncConfirmState();
        if (modHubModalStack.at(-1) === modalEntry) focus();
    });
};

// 游戏原生暗黑风格提示框（替代浏览器原生 alert）
window.modHubAlert = function(message, title = '提示') {
    return window.modHubConfirm({
        title,
        message,
        confirmText: '确定',
        cancelText: ''
    });
};
