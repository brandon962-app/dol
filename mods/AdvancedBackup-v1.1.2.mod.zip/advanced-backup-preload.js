(() => {
  // src/preload.ts
  var OVERLAY = "overlayReplace";
  var MARK = "data-advbk-tab";
  var LABEL = "`'<span data-advbk-tab>' + (setup.AdvbkTab || 'Advanced Backup') + '</span>'`";
  var BUTTON = [
    `		<<button ${LABEL}>>`,
    "			<<toggleTab>>",
    "			<<run window.AdvancedBackup && window.AdvancedBackup.enterTab ? window.AdvancedBackup.enterTab() : undefined>>",
    "		<</button>>"
  ].join("\n");
  function patch(text) {
    if (text.includes(MARK)) return text;
    const start = text.indexOf('<<widget "titleSaves">>');
    if (start < 0) return text;
    const end = text.indexOf("<</widget>>", start);
    if (end < 0) return text;
    const block = text.slice(start, end);
    const close = block.lastIndexOf("<<closeButton>>");
    if (close < 0) return text;
    const div = block.lastIndexOf("</div>", close);
    if (div < 0) return text;
    const at = start + div;
    return `${text.slice(0, at)}${BUTTON}
	${text.slice(at)}`;
  }
  var win = window;
  var utils = win.modUtils;
  var manager = win.modSC2DataManager;
  if (utils && manager) {
    const old = manager.getSC2DataInfoAfterPatch();
    const next = old.cloneSC2DataInfo();
    const passage = next.passageDataItems.map.get(OVERLAY);
    if (passage) {
      passage.content = patch(passage.content);
      next.passageDataItems.back2Array();
      utils.replaceFollowSC2DataInfo(next, old);
    }
    next.clean();
    old.clean();
  }
})();
