(() => {
  // src/preload.ts
  var OVERLAY = "overlayReplace";
  var PANEL = "hotkeysPanel";
  var LABEL = "`'<span data-dolhk-tab>' + (setup.DoLHKTab || 'Hotkeys') + '</span>'`";
  var BUTTON = [
    `		<<button ${LABEL}>>`,
    "			<<toggleTab>>",
    "			<<replace #customOverlayContent>><<hotkeysPanel>><</replace>>",
    "		<</button>>"
  ].join("\n");
  var PANEL_WIDGET = [
    '<<widget "hotkeysPanel">>',
    "	<<run window.DoLHK && window.DoLHK.renderInto ? window.DoLHK.renderInto() : undefined>>",
    "<</widget>>",
    ""
  ].join("\n");
  function patch(text) {
    if (text.includes(PANEL)) return text;
    const start = text.indexOf('<<widget "titleOptions">>');
    if (start < 0) return text;
    const end = text.indexOf("<</widget>>", start);
    if (end < 0) return text;
    const block = text.slice(start, end);
    const close = block.lastIndexOf("<<closeButton>>");
    if (close < 0) return text;
    const div = block.lastIndexOf("</div>", close);
    if (div < 0) return text;
    const at = start + div;
    return `${text.slice(0, at)}${BUTTON}
	${text.slice(at)}`;
  }
  var win = window;
  var utils = win.modUtils;
  var manager = win.modSC2DataManager;
  if (utils && manager) {
    const old = manager.getSC2DataInfoAfterPatch();
    const next = old.cloneSC2DataInfo();
    const passage = next.passageDataItems.map.get(OVERLAY);
    if (passage) {
      passage.content = patch(passage.content);
      if (!next.passageDataItems.map.has(PANEL)) {
        next.passageDataItems.map.set(PANEL, { id: 0, name: PANEL, tags: ["widget"], content: PANEL_WIDGET });
      }
      next.passageDataItems.back2Array();
      utils.replaceFollowSC2DataInfo(next, old);
    }
    next.clean();
    old.clean();
  }
})();
