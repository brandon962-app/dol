/* 基本需求 · 居家与日用品：杯子/肥皂/牙膏/沐浴露耐久、放置件独立状态、
 * 杯子装水/喝水、刷牙与洗手池管理、花洒区洗澡流程、大厅饮水机、发型锁定 */
(function () {
  'use strict';
  const BN = (window.BN = window.BN || {});

  // ===== 日用品功能化（v0.4.0）：杯子容量 / 肥皂耐久 / 毛巾擦干 / 刷牙 / 洗护毫升 + 发型锁定 =====
  // 数值口径（用户 257f91 设计 + 平衡默认，全部可调）：
  // 牙齿 0-10000（认真有牙膏 -1000 / 认真无牙膏 -400 / 敷衍 -300/-150），牙齿 60/h（原 100，用户要求减缓）；头发 80/h（50h≈2 天不洗头触发锁定）
  // 肥皂/牙膏耐久 %（100 起，-20/次，5 次/份），沐浴露/洗发水 500ml（-50/次，10 次/瓶）
  // 毛巾湿度 0-100（擦干 +50，30/h 晾干，湿透不可用）；湿身 0-100（25/h 晾干，穿衣浸湿衣物 +80）
  const CUP_ML = 300;
  const WATER_THIRST_PER_ML = 10;
  const TEETH_RATE = 60;
  const TEETH_SWEET = { soda: 200, sweets: 300, biscuits: 100 };
  // 敷衍 2 分钟效果弱（牙齿/压力约认真档 30-40%），认真 5 分钟=原档
  const BRUSH_PASTE = 1000;
  const BRUSH_DRY = 400;
  const BRUSH_PASTE_QUICK = 300;
  const BRUSH_DRY_QUICK = 150;
  const BRUSH_STRESS = 100;
  const BRUSH_STRESS_QUICK = 40;
  const TOOTHPASTE_USE = 20;
  const TOOTHPASTE_USE_QUICK = 10;
  const HAIR_RATE = 80;
  const HAIR_LOCK_AT = 4000;
  const SHAMPOO_USE_ML = 50;
  const BODYWASH_USE_ML = 50;
  const BODYWASH_MOOD = 240;
  // 洗护品额外减压（用户要求）：原版洗澡本体 <<stress -6>>=480 点、mod 刷牙减 100 点，
  // 沐浴露/洗发水各额外 200 点（2%）
  const STRESS_WASH_EXTRA = 200;
  const TOWEL_WET_PER = 50;
  const TOWEL_DRY_RATE = 30;

  let bnBathChoice = null; // 本轮洗澡选择记录（body/hair/dry -> hand|bodywash/shampoo|no/towel|air；null=未开始）
  let bnBathLinkEl = null; // 被拦截的洗澡原链接（radiobutton 选完后模拟点击放行原版宏流程）
  let bnBathFrom = 'Bathroom'; // 进准备场景前的来源页（"不洗了"返回目标）
  // 洗手池放置标记（"管理洗手池"）：牙刷/牙膏/杯子放到池边才能刷牙——独立于库存，
  // 只是位置描述；牙膏耗尽时自动收回
  // sink: { toothbrush, toothpaste, cup }

  // 耐久消耗：dur/durMl = "当前打开那份"的剩余；amount = 拥有总数（含当前份）。
  // 当前份耗尽 → 还有存货就自动开新份，否则 amount 归 0（物品移除）。返回 false = 没货可用
  // ===== 放置件独立状态（背包/摆放真分离）：放置时从堆叠真实拆出一件，耐久/水量
  // 由 placed 条目自带——外部使用（刷牙/洗澡/喝水）扣 placed，背包堆叠（原版堆叠共享语义）
  // 不再跟着变；背包数量即纯背包持有量 =====
  function placedSnapshot(key, st) {
    if (key === 'cup') return { waterMl: st ? (st.waterMl || 0) : 0 };
    if (key === 'toothpaste') return { dur: st && st.dur !== undefined ? st.dur : 100 };
    if (key === 'bodywash' || key === 'shampoo') return { durMl: st && st.durMl !== undefined ? st.durMl : 500 };
    return {};
  }

  // 收回：placed 单件并回堆叠（耐久取 min——堆叠共享语义下保守合并；杯子水相加）
  function mergePlacedBack(key) {
    const bn = BN.ensureVars();
    const p = bn.placed && bn.placed[key];
    if (!p) return;
    const st = V.foodstuff[key];
    if (st && (st.amount || 0) > 0) {
      st.amount += 1;
      if (key === 'cup') st.waterMl = (st.waterMl || 0) + (p.waterMl || 0);
      else if (key === 'toothpaste') st.dur = Math.min(st.dur === undefined ? 100 : st.dur, p.dur === undefined ? 100 : p.dur);
      else if (key === 'bodywash' || key === 'shampoo') st.durMl = Math.min(st.durMl === undefined ? 500 : st.durMl, p.durMl === undefined ? 500 : p.durMl);
    } else {
      const fresh = { amount: 1 };
      if (key === 'cup') fresh.waterMl = p.waterMl || 0;
      else if (key === 'toothpaste') fresh.dur = p.dur === undefined ? 100 : p.dur;
      else if (key === 'bodywash' || key === 'shampoo') fresh.durMl = p.durMl === undefined ? 500 : p.durMl;
      V.foodstuff[key] = fresh;
    }
    delete bn.placed[key];
  }

  // 消耗放置件（外部使用：刷牙牙膏/洗澡沐浴露洗发水）：耗尽 → 物品消失+自动收起
  function consumePlaced(key, use, isMl) {
    const bn = BN.ensureVars();
    const p = bn.placed && bn.placed[key];
    if (!p) return false;
    const full = isMl ? 500 : 100;
    const cur = isMl ? (p.durMl === undefined ? full : p.durMl) : (p.dur === undefined ? full : p.dur);
    const left = cur - use;
    if (left > 0) {
      if (isMl) p.durMl = left; else p.dur = left;
      return true;
    }
    delete bn.placed[key];
    bn.sink[key] = false;
    return true;
  }

  // 背包卡片的耐久/状态小字
  function bnDurText(key) {
    const st = V.foodstuff[key];
    if (!st || !(st.amount > 0)) return '';
    switch (key) {
      case 'cup':
        return (st.waterMl || 0) > 0 ? '水 ' + Math.round(st.waterMl) + 'ml' : '空杯';
      case 'soap':
      case 'toothpaste':
        return '剩 ' + Math.round(st.dur === undefined ? 100 : st.dur) + '%';
      case 'bodywash':
      case 'shampoo':
        return '剩 ' + Math.round(st.durMl === undefined ? 500 : st.durMl) + 'ml';
      case 'sponge': {
        const w = st.wet || 0;
        return w >= 100 ? '湿透了（需晾干）' : (w > 0 ? '有点湿' : '干爽');
      }
      default: return '';
    }
  }

  // 发型锁定：长期不洗头 → 快照当前发型；恢复检测（不管从哪改的都弹回去）
  function lockHair() {
    const bn = V.BasicNeeds;
    bn.hairLocked = true;
    bn.hairSnap = {
      hairtype: V.hairtype, haircolour: V.haircolour, hairlength: V.hairlength,
      fringelength: V.fringelength, hairfringecolour: V.hairfringecolour
    };
    try { if (V.hairColourGradient) bn.hairSnap.gradient = JSON.parse(JSON.stringify(V.hairColourGradient)); } catch (e) { /* 快照失败不阻塞锁定 */ }
  }

  function unlockHair() {
    const bn = V.BasicNeeds;
    const was = !!bn.hairLocked;
    bn.hairDirty = 0;
    bn.hairLocked = false;
    bn.hairSnap = null;
  }

  function bnHairGuard() {
    const bn = V.BasicNeeds;
    if (!bn.hairLocked || !bn.hairSnap) return;
    const s = bn.hairSnap;
    if (V.hairtype === s.hairtype && V.haircolour === s.haircolour && V.hairlength === s.hairlength &&
      V.fringelength === s.fringelength && V.hairfringecolour === s.hairfringecolour) return;
    V.hairtype = s.hairtype; V.haircolour = s.haircolour; V.hairlength = s.hairlength;
    V.fringelength = s.fringelength; V.hairfringecolour = s.hairfringecolour;
    if (s.gradient) { try { V.hairColourGradient = JSON.parse(JSON.stringify(s.gradient)); } catch (e) { /* 恢复失败不阻塞 */ } }
  }

  // 刷牙场景内容（洗手池管理版）：牙刷/牙膏/杯子要"摆到池边"才出现在池边文案和
  // 刷牙选项里（管理 = 摆放/收起切换，独立于库存）；漱口水由洗手池现场接（自动装水，不占
  // 杯中饮用水），牙膏未摆出/缺货时"有牙膏刷牙"不显示
  function brushSceneHtml() {
    const st = V.foodstuff || {};
    const bn = BN.ensureVars();
    const sink = (bn.sink || {});
    const plc = (bn.placed || {});
    const tb = st.toothbrush;
    const tbOk = (tb && (tb.amount || 0) > 0) || sink.toothbrush;
    if (!tbOk) {
      return '你走到洗手池前，翻遍了柜子，也没找到自己的牙刷。<br><br>' +
        '看来得去超市买一支。<br><br>' +
        '<<link [[返回|_bnExit]]>><</link>>';
    }
    const tp = st.toothpaste || {};
    const tpDur = sink.toothpaste && plc.toothpaste ? (plc.toothpaste.dur === undefined ? 100 : plc.toothpaste.dur) : (tp.dur === undefined ? 100 : tp.dur);
    const tpOwn = (tp.amount || 0) > 0 || sink.toothpaste;
    const cp = st.cup || {};
    const cupWater = sink.cup && plc.cup ? (plc.cup.waterMl || 0) : (cp.waterMl || 0);
    const hasCup = (cp.amount || 0) > 0 || sink.cup;
    const pasteStock = sink.toothpaste && plc.toothpaste && tpDur > 0;
    const placed = [];
    if (sink.toothbrush) placed.push('牙刷');
    if (sink.toothpaste && pasteStock) placed.push('牙膏');
    if (sink.cup && hasCup) placed.push('你的杯子');
    let out = '你走到洗手池前。' + (placed.length ? placed.join('、') + '摆在池边。' : '池边空空的。') + '<br><br>';
    out += '牙刷（' + (sink.toothbrush ? '已摆到池边' : '收在包里') + '） <<link "' + (sink.toothbrush ? '收起来' : '摆到池边') + '">><<run window.bnSinkToggle("toothbrush")>><</link>><br>';
    if (tpOwn) {
      out += '牙膏 剩 ' + Math.round(tpDur) + '%（' + (sink.toothpaste ? '已摆到池边' : '收在包里') + '） <<link "' + (sink.toothpaste ? '收起来' : '摆到池边') + '">><<run window.bnSinkToggle("toothpaste")>><</link>><br>';
    }
    if (hasCup) {
      out += '杯子（' + (cupWater > 0 ? '杯里 ' + Math.round(cupWater) + 'ml' : '空杯') + '） <<link "' + (sink.cup ? '收起来' : '摆到池边') + '">><<run window.bnSinkToggle("cup")>><</link>><br>';
    }
    out += '<br>';
    if (!sink.toothbrush) {
      out += '<span class="small-description">池边没有牙刷，先把它摆出来。</span><br>';
    } else {
      if (sink.toothpaste && pasteStock) {
        out += '<<link "有牙膏敷衍刷牙（2分钟）">><<run window.bnBrushPick("paste", true)>><</link>> | <span class="green">- 压力</span> | <span class="green">- 牙齿</span><br>';
        out += '<<link "有牙膏认真刷牙（5分钟）">><<run window.bnBrushPick("paste")>><</link>> | <span class="green">- 压力</span> | <span class="green">- 牙齿</span><br>';
      }
      out += '<<link "无牙膏敷衍刷牙（2分钟）">><<run window.bnBrushPick("dry", true)>><</link>> | <span class="green">- 压力</span> | <span class="green">- 牙齿</span><br>';
      out += '<<link "无牙膏认真刷牙（5分钟）">><<run window.bnBrushPick("dry")>><</link>> | <span class="green">- 压力</span> | <span class="green">- 牙齿</span><br>';
    }
    out += '<br><<link [[返回|_bnExit]]>><</link>>';
    return out;
  }

  // 花洒区场景：沐浴露/洗发水移出洗手池，改在这里的置物架管理（放置只是位置
  // 描述，与库存独立），并有"洗澡"入口——点进后仍走两段式准备页（bindFoodLinks 拦截）
  function bnShowerAreaHtml() {
    const st = V.foodstuff || {};
    const bn = BN.ensureVars();
    const sink = bn.sink || {};
    const plc = bn.placed || {};
    const bw = st.bodywash || {};
    const sh = st.shampoo || {};
    const bwDur = sink.bodywash && plc.bodywash ? (plc.bodywash.durMl === undefined ? 500 : plc.bodywash.durMl) : (bw.durMl === undefined ? 500 : bw.durMl);
    const shDur = sink.shampoo && plc.shampoo ? (plc.shampoo.durMl === undefined ? 500 : plc.shampoo.durMl) : (sh.durMl === undefined ? 500 : sh.durMl);
    const bwOwn = (bw.amount || 0) > 0 || sink.bodywash;
    const shOwn = (sh.amount || 0) > 0 || sink.shampoo;
    const rows = [];
    if (bwOwn) {
      rows.push('泡泡精沐浴露 剩 ' + Math.round(bwDur) + 'ml（' + (sink.bodywash ? '放在置物架上' : '收在包里') + '） <<link "' + (sink.bodywash ? '收起来' : '放到置物架上') + '">><<run window.bnSinkToggle("bodywash")>><</link>>');
    }
    if (shOwn) {
      rows.push('柔顺宝洗发水 剩 ' + Math.round(shDur) + 'ml（' + (sink.shampoo ? '放在置物架上' : '收在包里') + '） <<link "' + (sink.shampoo ? '收起来' : '放到置物架上') + '">><<run window.bnSinkToggle("shampoo")>><</link>>');
    }
    let out = '你走进花洒区。热水器的指示灯亮着，水龙头旁有一个置物架。<br><br>';
    out += rows.length ? rows.join('<br>') + '<br>' : '<span class="small-description">置物架上空空的。</span><br>';
    // 雨中洗澡：仍会被雨淋的部位（裸露或盖着淋湿档的衣）交给雨淋结算——淋浴清零后
    // 每小时又 +5，来回打架；雨停/室内/打伞时没有雨淋来源，全身照常清零
    const covered = BN.bnRainSoak() ? bnFilterCoveredParts() : [];
    if (covered.length) {
      out += '外面还在下雨。<br><span class="small-description">这场雨会把' + covered.join('、') + '重新淋湿——洗澡清掉的水马上又会回来。</span><br>';
      out += '<br><<link [[洗澡 (0:30)|Bath]]>><<strip>><<pass 30>><<stress -6>><<set $hygiene to 0>><</link>><br>';
    } else {
      out += '<br><<link [[洗澡 (0:30)|Bath]]>><<strip>><<pass 30>><<stress -6>><<set $hygiene to 0>><<run window.bnSetBodyWaterAll(0)>><</link>><br>';
    }
    out += '[[返回|_bnExit]]';
    return out;
  }

  // 花洒区清理语义：BN.bnWaterParts() 中"仍然会被雨淋"的部位 = BN.bnPartCoverWetness
  // 返回 null（无覆盖衣）或湿度已达淋湿档（>=80）的部位。洗澡时这些部位的水交给
  // BN.rainWetBodyWater 的雨淋结算（雨中每小时×雨强步进，必然比"清零后靠蒸发"更快湿透，
  // 且不会来回打架）；其余部位（盖着干衣的）雨淋不进去，洗澡仍按原逻辑清零
  function bnFilterCoveredParts() {
    return BN.bnWaterParts().filter(part => {
      const cover = BN.bnPartCoverWetness(part);
      return cover === null || cover >= BN.BN_WET_GATE;
    });
  }

  // 水的体液描述（用户 257f91"按照原版这样，给水的描述也添加类似的文案"）：仿原版
  // goo widget（侧栏体液描述，<<goo>> 输出紧邻 #statmeters 之前）给 water 生成同档位文案。
  // 原版档位（体表合计 $liquidoutsidecount）：>=25 drenched pink / >=20 soaked / >=15 slick /
  // >=10 wet / >=5 moist / >=1 feel on skin blue（100 档 water 上限 60 到不了，不设）；
  // 内部三处（子宫/肠/咳出）无 water，不需要对应描述。中文直接写入 mod 渲染
  // （v0.3.13 tab 按钮先例：mod 动态文本不经 ModI18N）
  function toggleSinkItem(key) {
    const bn = BN.ensureVars();
    if (!bn.sink || typeof bn.sink !== 'object') bn.sink = { toothbrush: false, toothpaste: false, cup: false, bodywash: false, shampoo: false };
    if (!bn.placed || typeof bn.placed !== 'object') bn.placed = {};
    if (bn.sink[key]) {
      bn.sink[key] = false;
      mergePlacedBack(key);
    } else {
      const st = V.foodstuff[key];
      if (!st || !(st.amount > 0)) return;
      st.amount -= 1;
      bn.placed[key] = placedSnapshot(key, st);
      // 水跟杯走：杯子摆出去时带走全部存水，堆叠（含未拆出的杯子）不留水
      if (key === 'cup') st.waterMl = 0;
      if (st.amount <= 0) delete V.foodstuff[key];
      bn.sink[key] = true;
    }
    SugarCube.Engine.play(SugarCube.State.passage);
  }

  // 刷牙结算（场景链接调用）：敷衍 quick=2 分钟弱效果、认真=5 分钟原档（与原版等价 <<pass 5>>）。
  // 有牙膏 → 原版 Bathroom Brush 场景（eventPoolOverride 锁定挤牙膏剧情）；无牙膏 → mod 干刷结算场景
  function brushPick(mode, quick) {
    const bn = BN.ensureVars();
    const passSec = quick ? 120 : 300;
    if (mode === 'paste') {
      consumePlaced('toothpaste', quick ? TOOTHPASTE_USE_QUICK : TOOTHPASTE_USE);
      bn.teeth = BN.clamp(Math.max(0, (bn.teeth || 0) - (quick ? BRUSH_PASTE_QUICK : BRUSH_PASTE)));
    } else {
      bn.teeth = BN.clamp(Math.max(0, (bn.teeth || 0) - (quick ? BRUSH_DRY_QUICK : BRUSH_DRY)));
    }
    V.stress = Math.max(0, (V.stress || 0) - (quick ? BRUSH_STRESS_QUICK : BRUSH_STRESS));
    Time.pass(passSec);
    BN.settle();
    BN.updatePanel();
    if (mode === 'paste') {
      // 原版 Bathroom Brush 的事件池随机会抽到"有人用光了牙膏/找不到牙刷"剧情，与真实库存矛盾——
      // 用原版预留的 eventPoolOverride（runeventpool 支持）强制走正常挤牙膏剧情
      V.eventPoolOverride = 'orphanage_toothbrushing_normal';
      SugarCube.Engine.play('Bathroom Brush');
    } else {
      SugarCube.Engine.play('BasicNeeds Brush Finish');
    }
  }

  // 干刷结算场景：原版 Bathroom Brush 事件池没有"无牙膏"剧情，干刷走 mod
  // 自建场景输出对应文案；Next 链接复刻原版行为（endevent+清 canvas 嘴部动作+清 $bathroomExit）
  function brushFinishHtml() {
    return '你把牙刷放进嘴里，干刷了起来。没有牙膏的泡沫，你刷得格外用力。<br><br>' +
      '刷完之后，你把口水吐到水槽里，漱了漱口。<br><br>' +
      '<<link [[继续|_bnExit]]>><<endevent>><<canvas-model-override "clear">><<run delete $bathroomExit>><</link>>';
  }

  // 装水场景内容（v0.4.1 去弹窗；只认背包里的杯子——池边杯是摆在洗手池的容器，
  // 不可能被拿到大厅接水）：容量选项按剩余空间过滤，装不下的量不显示
  function fillSceneHtml() {
    const bn = BN.ensureVars();
    const st = V.foodstuff.cup;
    if (!st || !(st.amount > 0)) {
      const atSink = bn.sink.cup && bn.placed.cup;
      return '你想接点水，但手头没有杯子' + (atSink
        ? '——你的杯子都摆在洗手池了。<br><br>先去洗手池把它收起来，或者去超市再买一个。<br><br>'
        : '。<br><br>超市的日用品货架上应该有卖。<br><br>') +
        '<<link [[返回|Orphanage]]>><</link>>';
    }
    const cups = st.amount;
    const cap = cups * CUP_ML;
    const cur = st.waterMl || 0;
    let out = '饮水机流出清澈的凉水，你把杯子凑到出水口下。<br><br>' +
      '杯里现有 ' + Math.round(cur) + 'ml（' + cups + ' 个杯子，总容量 ' + cap + 'ml）。<br><br>';
    if (cur >= cap) {
      out += '<span class="small-description">杯子已经满了。</span><br>';
    } else {
      [100, 200, 300].forEach(n => {
        if (n > cap - cur) return;
        out += '<<link "装 ' + n + 'ml">><<run window.bnFillPick(' + n + ')>><</link>><br>';
      });
    }
    out += '<br><<link [[返回|Orphanage]]>><</link>>';
    return out;
  }

  // 装水结算：推 1 分钟与原版装水食谱一致
  function fillPick(n) {
    const st = V.foodstuff.cup;
    if (!st || !(st.amount > 0)) return;
    const cap = st.amount * CUP_ML;
    st.waterMl = Math.min(cap, (st.waterMl || 0) + n);
    Time.pass(60);
    BN.settle();
    BN.updatePanel();
    SugarCube.Engine.play('Orphanage');
  }

  // 喝杯中水：一次喝光（想少喝点就少装点），效果按毫升换算（300ml = 原版一杯水）。
  // 喝完重演当前页（大厅饮水机原地反馈，无提示弹层）
  function drinkCup() {
    const st = V.foodstuff.cup;
    const ml = st ? (st.waterMl || 0) : 0;
    if (!(st && st.amount > 0) || ml <= 0) return;
    const bn = BN.ensureVars();
    bn.thirst = BN.clamp(bn.thirst - ml * WATER_THIRST_PER_ML);
    st.waterMl = 0;
    Time.pass(120);
    BN.settle();
    BN.updatePanel();
    SugarCube.Engine.play(SugarCube.State.passage);
  }

  // 洗澡选择区（复刻原版自慰动作行）：每组 = 状态句正文 + 逐项 "| <label><input
  // type=radio><span class=checked-gold>文本</span></label>" + <br>×2——原版 masturbationActions
  // 的 generateOption/"| " 前导分隔结构，选中金色由页面级 CSS input:checked+.checked-gold 提供，
  // radio 用浏览器原生外观（原版无 accent-color 定制）。已选组锁定（disabled）——消耗品选定即结算
  // 不可反悔；缺货选项整个不渲染。返回 { html, done }——done = 没有待答组（底部"继续"按钮显示条件）
  function bathRadio(group, val, label, checked) {
    return '| <label><input type="radio" name="bnBath' + group + '" data-group="' + group +
      '" value="' + val + '"' + (checked ? ' checked' : '') +
      '> <span class="checked-gold">' + label + '</span></label> ';
  }

  function bathChoiceHtml() {
    const st = V.foodstuff || {};
    const ch = bnBathChoice || {};
    const bn = BN.ensureVars();
    const sink = bn.sink || {};
    const plc = bn.placed || {};
    // 洗澡只消耗已摆到置物架的那件（placed 独立状态），容量读 placed
    const bwLeft = (sink.bodywash && plc.bodywash) ? Math.round(plc.bodywash.durMl === undefined ? 500 : plc.bodywash.durMl) : 0;
    const shLeft = (sink.shampoo && plc.shampoo) ? Math.round(plc.shampoo.durMl === undefined ? 500 : plc.shampoo.durMl) : 0;
    const sp = st.sponge;
    const towelOk = sp && (sp.amount || 0) > 0 && (sp.wet || 0) < 100;
    const bwOk = bwLeft > 0;
    const shOk = shLeft > 0;
    // 原版 radiobutton 语义：点击只改选（金色随 checked 移动，可随时换），结算统一点"继续"时做
    // done = 存在的组（body 恒在/hair 有洗发水时/dry 有毛巾时）全部已选
    // 洗护品行效果预告：额外减压+改善心情，形态同 刷牙标注（白竖线+绿字）
    const washTag = ' | <span class="green">- 压力</span> | <span class="green">- 心情</span>';
    let out = '';
    out += '你的身体还没有洗。<br>' +
      bathRadio('Body', 'hand', '徒手洗', ch.body === 'hand') +
      (bwOk ? bathRadio('Body', 'bodywash', '使用泡泡精沐浴露（剩 ' + bwLeft + 'ml）', ch.body === 'bodywash') + washTag : '') +
      ((st.bodywash && (st.bodywash.amount || 0) > 0 && !sink.bodywash) ? '<br><span class="small-description">泡泡精沐浴露还收在包里，先到花洒区把它放到置物架上。</span>' : '') +
      '<br><br>';
    if (shOk || (st.shampoo && (st.shampoo.amount || 0) > 0)) {
      out += '你的头发还没有洗。<br>' +
        bathRadio('Hair', 'no', '不洗头', ch.hair === 'no') +
        (shOk ? bathRadio('Hair', 'shampoo', '用柔顺宝洗发水洗头（剩 ' + shLeft + 'ml）', ch.hair === 'shampoo') + washTag : '') +
        ((st.shampoo && (st.shampoo.amount || 0) > 0 && !sink.shampoo) ? '<br><span class="small-description">柔顺宝洗发水还收在包里，先到花洒区把它放到置物架上。</span>' : '') +
        '<br><br>';
    }
    if (towelOk) {
      out += '你还没有决定洗完后怎么擦干身体。<br>' +
        bathRadio('Dry', 'towel', '用毛巾擦干', ch.dry === 'towel') +
        bathRadio('Dry', 'air', '自然晾干', ch.dry === 'air') +
        '<br><br>';
    }
    const bodyDone = ch.body === 'hand' || ch.body === 'bodywash';
    const hairGroupShown = shOk || (st.shampoo && (st.shampoo.amount || 0) > 0);
    const hairDone = !hairGroupShown || ch.hair === 'shampoo' || ch.hair === 'no';
    const dryDone = !towelOk || ch.dry === 'towel' || ch.dry === 'air';
    return { html: out, done: bodyDone && hairDone && dryDone };
  }

  // 洗澡准备场景（战斗 UI 形态）：正文 + 问句区（renderBathChoice 填充）+ 底部固定
  // 按钮区 #bn-bath-next（复刻原版战斗 #next 样式）——"继续洗澡"全部问句处理完毕才显示
  // （#bn-bath-go 默认 CSS 隐藏），"不洗了"一直可用。选好后点"继续"放行原链接
  function bathPrepSceneHtml() {
    return '你走进浴室，拧开龙头，热水哗啦啦地流了下来。水汽很快弥漫开来，镜子上蒙上了一层白雾。<br>' +
      '你把换洗衣物放在架子上，准备先把自己从头到脚搓洗干净。<br>' +
      '<div id="bn-bath-choice"></div>' +
      '<br><br><br>' +
      '<div id="bn-bath-next">' +
      '<div id="bn-bath-go"><<link "继续洗澡">><<run window.bnBathGo()>><</link>></div>' +
      '<div class="bn-bath-skip"><<link "不洗了">><<run window.bnBathSkip()>><</link>></div>' +
      '</div>';
  }

  // 放行原洗澡链接：置标记后模拟点击，bindFoodLinks 的洗澡分支检测到标记即放行
  // （原版 <<strip>> 脱衣、<<pass>> 推时长、Bath 场景导航全部照原版走）
  function bathGo() {
    // 统一结算：radio 只是意向选择，点"继续"此刻才消耗/生效；
    // 沐浴露/洗发水额外减压（STRESS_WASH_EXTRA）
    const bn = BN.ensureVars();
    const ch = bnBathChoice || {};
    if (ch.body === 'bodywash' && consumePlaced('bodywash', BODYWASH_USE_ML, true)) {
      bn.mood = BN.clamp(bn.mood - BODYWASH_MOOD);
      V.stress = Math.max(0, (V.stress || 0) - STRESS_WASH_EXTRA);
    }
    if (ch.hair === 'shampoo' && consumePlaced('shampoo', SHAMPOO_USE_ML, true)) {
      unlockHair();
      V.stress = Math.max(0, (V.stress || 0) - STRESS_WASH_EXTRA);
    }
    if (ch.dry === 'towel') {
      const sp = V.foodstuff.sponge;
      if (sp && (sp.amount || 0) > 0) sp.wet = Math.min(100, (sp.wet || 0) + TOWEL_WET_PER);
      BN.setBodyWater(0);
    } else {
      // 自然晾干：洗澡全身带水，随时间由 BN.settle 蒸发（"慢慢干掉"）。
      // 水位 5→3（用户 257f91"洗澡选择不擦干也会全部攒满水"——湿漉漉即可，
      // 不必到浸透流淌满档；3 点约 3 小时干透）。穿衣后由 BN.wetClothesFromBody 浸湿衣物
      BN.setBodyWater(3);
    }
    BN.updatePanel();
    bnBathChoice = null;
    const el = bnBathLinkEl;
    bnBathLinkEl = null;
    if (el && el.isConnected) {
      el.dataset.bnBathGo = '1';
      el.click();
    } else {
      bnBathPending = true;
      SugarCube.Engine.play('Bath');
    }
  }

  function bathSkip() {
    // Prep 进场已 <<strip>> 脱衣，"不洗了"按原版"Dress as you were"语义穿回
    try { SugarCube.Wikifier.wikifyEval('<<clotheson>>'); } catch (e) { /* 无 widget 环境跳过 */ }
    bnBathLinkEl = null;
    bnBathChoice = null;
    SugarCube.Engine.play(bnBathFrom);
  }

  // 动作行选择（原版 radiobutton 语义）：点击只改选（可随时换），统一结算放 bathGo
  function pickBathOption(group, val) {
    if (group !== 'body' && group !== 'hair' && group !== 'dry') return;
    bnBathChoice = bnBathChoice || {};
    bnBathChoice[group] = val;
    renderBathChoice();
  }

  // 洗澡问句列表：填充 bathPrepSceneHtml 里的 #bn-bath-choice 占位；"继续"
  // 按钮在全问句处理完毕后显示（#bn-bath-go）。重渲染后 BN.bnNumberLinks 手动编号（mod 行
  // 编号接续原版）
  function bnBathPendingEnd() {
    if (V.passage === 'BasicNeeds Bath Prep') {
      renderBathChoice();
    } else if (bnBathPending) {
      V.hygiene = 0;
      if (!(V.passage === 'Bath' || /Shower$/.test(V.passage))) {
        bnBathPending = false;
      }
    }
  }

  function renderBathChoice() {
    const box = document.querySelector('#bn-bath-choice');
    if (!box) return;
    if (!box._bnBound) {
      box._bnBound = true;
      box.addEventListener('change', e => {
        const r = e.target;
        if (!r || r.type !== 'radio' || r.disabled) return;
        pickBathOption((r.dataset.group || '').toLowerCase(), r.value);
      });
    }
    const r = bathChoiceHtml();
    box.innerHTML = r.html;
    box.style.display = r.html ? '' : 'none';
    const go = document.querySelector('#bn-bath-go');
    if (go) go.style.display = r.done ? 'inline-grid' : 'none';
    BN.bnNumberLinks();
  }

  // 离开浴室：没用毛巾擦干 = 自然晾干（身体会湿，穿衣会浸湿衣物）
  // 理发店锁定：发型锁定时遮住理发选项，提供"店内洗头"（£10 · 0:20，洗完解锁可继续理发）
  function injectHairdresserLock() {
    if (V.passage !== 'Hairdressers Seat') return;
    const bn = V.BasicNeeds;
    if (!bn || !bn.hairLocked) return;
    const box = document.querySelector('#hairDressers');
    if (!box || box.querySelector('.bn-hairlock')) return;
    box.style.position = 'relative';
    const d = document.createElement('div');
    d.className = 'bn-hairlock';
    const afford = (V.money || 0) >= 1000;
    d.innerHTML = '<div class="bn-hairlock-card">' +
      '<p>理发师捏了捏你的头发，皱起眉头："亲爱的，你这头发又脏又油，我没法直接给你做造型——先洗洗吧。"</p>' +
      (afford
        ? '<button class="bn-hairwash">在店里洗头（£10 · 0:20）</button>'
        : '<span class="small-description">在店里洗头需要 £10，你的钱不够。</span>') +
      '</div>';
    box.appendChild(d);
    if (afford) {
      d.querySelector('.bn-hairwash').addEventListener('click', () => {
        try { Wikifier.wikifyEval('<<money -1000 "hairdressers">>'); } catch (e) { /* 扣费失败仍洗头 */ }
        Time.pass(20 * 60);
        BN.settle();
        unlockHair();
        BN.updatePanel();
        d.remove();
        box.style.position = '';
      });
    }
  }

  // 洗澡清零标记：点击洗澡链接时置位，:passageend 的 BN.settle 之后清回 0。
  // 原版洗澡场景先 <<set $hygiene to 0>> 再推时长（淋浴 30 分钟），mod 的 BN.settle 在渲染
  // 结束才结算——0 + 150×0.5 = 75，用户实测"洗完不是 0 而是 75"。结算后补清一次归零
  let bnBathPending = false;

  function bindFoodLinks() {
    document.addEventListener('click', e => {
      const a = e.target.closest('a.link-internal');
      if (!a) return;
      // 刷牙（v0.4.0 功能化）：原版刷牙链接内联宏只有 <<pass 5>>，阻断后手动导航；进 mod
      // 注册的场景选有/无牙膏刷牙（洗手池版，无牙刷在场景里用剧情说明），Time.pass(300)
      // 等价补时长，选完进原版 Bathroom Brush 场景（清口腔液体等剧情照走）
      if (a.dataset.passage === 'Bathroom Brush') {
        e.preventDefault();
        e.stopPropagation();
        SugarCube.Engine.play('BasicNeeds Brush Teeth');
        return;
      }
      // 洗澡/泡澡（两段式）：点击拦截进准备场景选问句（不推时间），选好后
      // "继续洗澡"带标记模拟点击放行原导航（<<strip>><<pass>> 宏照走）——此时才置
      // pending/基础心情 -480；消耗在 bathGo 统一结算
      const dp = a.dataset.passage || '';
      if (dp === 'Bath' || /Shower$/.test(dp)) {
        if (a.dataset.bnBathGo === '1') {
          if (!bnBathPending) {
            const bn = BN.ensureVars();
            bnBathPending = true;
            bn.mood = BN.clamp(bn.mood - 480);
            BN.updatePanel();
          }
          return;
        }
        if (a.dataset.bnShower === '1') {
          e.preventDefault();
          e.stopPropagation();
          SugarCube.Engine.play('BasicNeeds Shower Area');
          return;
        }
        e.preventDefault();
        e.stopPropagation();
        bnBathChoice = {};
        bnBathLinkEl = a;
        bnBathFrom = SugarCube.State.passage;
        SugarCube.Engine.play('BasicNeeds Bath Prep');
        return;
      }
      const act = BN.FOOD_ACTIONS.find(x => x.re.test(a.textContent || ''));
      if (!act) return;
      const bn = BN.ensureVars();
      if (act.hunger) bn.hunger = BN.clamp(bn.hunger - act.hunger);
      if (act.thirst) bn.thirst = BN.clamp(bn.thirst - act.thirst);
      BN.updatePanel();
    }, true);
  }

  // 在原版吃喝链接旁标注 mod 扣减预告（用户要求购买前标明效果，样式按原版效果提示：
  // " | " + 绿色"- 名称"，无数值，同 statDisplay.statChange 的 DOM 结构——text.js 4-15 行）。
  // 与 BN.FOOD_ACTIONS 同表匹配；由 MutationObserver 回调 + :passageend 双驱动，dataset 防重插
  function annotateFoodLinks() {
    document.querySelectorAll('.passage a.link-internal').forEach(a => {
      if (a.dataset.bnAnnotated) return;
      const act = BN.FOOD_ACTIONS.find(x => x.re.test(a.textContent || ''));
      if (!act) return;
      a.dataset.bnAnnotated = '1';
      const frag = document.createDocumentFragment();
      frag.appendChild(document.createTextNode(' | '));
      const span = document.createElement('span');
      span.className = 'green';
      span.textContent = act.hunger ? '- 饥饿' : '- 口渴';
      frag.appendChild(span);
      a.after(frag);
    });
  }

  // 洗澡/泡澡链接旁的预告标注：进入花洒区入口（bnShower 标记）不加注——用户要求
  // 删掉该行的"压力/心情"；花洒区场景"洗澡"链接改标"- 压力"（原版 <<stress -6>> 语义）；
  // Shower 淋浴减心情维持"- 心情"（脏污清零不重复标注：原版链接自带清零，mod 另在结算后补清一次）
  function annotateShowerLinks($root) {
    ($root || document).querySelectorAll('.passage a.link-internal').forEach(a => {
      if (a.dataset.bnAnnotated) return;
      if (a.dataset.bnShower === '1') return;
      const dp = a.dataset.passage || '';
      if (dp !== 'Bath' && !/Shower$/.test(dp)) return;
      a.dataset.bnAnnotated = '1';
      const frag = document.createDocumentFragment();
      frag.appendChild(document.createTextNode(' | '));
      const span = document.createElement('span');
      span.className = 'green';
      span.textContent = dp === 'Bath' ? '- 压力' : '- 心情';
      frag.appendChild(span);
      a.after(frag);
    });
  }

  // 厨房"吃库存食物"：原版食物系统有库存（V.foodstuff[key].amount）但没有"吃"的动作，
  // 在两个玩家厨房（孤儿院/阁楼）注入入口。扣减按类别：饮品解渴、水果两头补、
  // 成品菜顶饱、原料少量；四种纯调味原料（面粉/盐/糖/油）不能生吃，不显示
  const KITCHEN_SCENES = ['Kitchen', 'Orphanage Loft Kitchen'];
  const DRINK_KEYS = [
    'orange_juice', 'lemonade', 'red_wine', 'white_wine', 'wolfbrew', 'ghostbrew',
    'bottle_of_milk', 'bottle_of_breast_milk', 'baby_bottle_of_breast_milk',
    'bottle_water', 'soda'
  ];
  const INEDIBLE_RAW = ['flour', 'salt', 'sugar', 'vegetable_oil', 'cup', 'soap', 'sponge', 'water', 'toothbrush', 'toothpaste', 'bodywash', 'shampoo'];

  // 超市零食/饮料的定制吃效果（其余条目走 category 默认表）：心情字段为该条目的总心情收益
  const CUSTOM_EAT_EFFECT = {
    bottle_water: { thirst: 3000, mood: 100 },
    soda: { thirst: 2500, mood: 500, teeth: TEETH_SWEET.soda },
    crisps: { hunger: 1500, mood: 400 },
    biscuits: { hunger: 1200, mood: 300, teeth: TEETH_SWEET.biscuits },
    sweets: { hunger: 800, mood: 800, teeth: TEETH_SWEET.sweets }
  };

  // 刷牙入口改名（用户要求"点击去洗手池才会出现这个内容"）：只替换链接内业务
  // 文本节点，引擎编号节点与链接外标注不动；data-passage 不变，bindFoodLinks 拦截照旧
  function injectSinkEntry() {
    document.querySelectorAll('#passages .passage a[data-passage="Bathroom Brush"]').forEach(a => {
      if (a.dataset.bnSink === '1') return;
      a.dataset.bnSink = '1';
      const tn = Array.from(a.childNodes).find(nd => nd.nodeType === 3 && /刷牙|Brush teeth/i.test(nd.textContent));
      if (tn) tn.textContent = tn.textContent
        .replace(/刷牙(?:\s*\(0:0\d\))?/, '去洗手池')
        .replace(/Brush teeth(?:\s*\(\d+:\d+\))?/i, 'Go to the sink');
    });
  }

  // 浴室页洗澡入口改"进入花洒区"：沐浴露/洗发水管理移出洗手池，改在花洒区
  // 置物架管理+发起洗澡。只改文本节点（编号/标注不碰），标记 bnShower 供 bindFoodLinks
  // 拦截进花洒区场景；紧邻的 <<lstress>> 压力标注（- 压力 green span）随改名删除
  function injectShowerArea() {
    if (V.passage !== 'Bathroom') return;
    document.querySelectorAll('#passages .passage a[data-passage="Bath"]').forEach(a => {
      if (a.dataset.bnShower === '1') return;
      const tn = Array.from(a.childNodes).find(nd => nd.nodeType === 3 && /Have a bath|洗澡/.test(nd.textContent));
      if (!tn) return;
      a.dataset.bnShower = '1';
      tn.textContent = tn.textContent
        .replace(/洗澡(?:\s*\(0:30\))?/, '进入花洒区')
        .replace(/Have a bath(?:\s*\(\d+:\d+\))?/i, 'Enter the shower area');
      // 删紧邻效果标注（循环）：mod 心情标注与原版 lstress 压力标注各带一个 " | "
      // 前导文本节点，全是"分隔文本节点→标注 span"交替，遇第一个非标注兄弟停止
      let sib = a.nextSibling;
      while (sib) {
        const next = sib.nextSibling;
        if (sib.nodeType === 3 && sib.textContent.trim() === '|') { sib.remove(); sib = next; continue; }
        if (sib.nodeType === 1 && sib.tagName === 'SPAN' && !sib.querySelector('a') &&
            /压力|stress|心情|mood/i.test(sib.textContent)) { sib.remove(); sib = next; continue; }
        break;
      }
    });
  }

  // 大厅饮水机（原厨房装水功能按用户要求移除，厨房恢复原版剧情）：Orphanage
  // 场景末尾追加饮水机一句+接水/喝水链接（原版链接风格，融入编号系统）。接水进 mod 装水
  // 场景（fillSceneHtml，返回 Orphanage），喝水原地结算后重演当前页
  function injectWaterDispenser() {
    if (V.passage !== 'Orphanage') return;
    const $p = $('.passage').last();
    if (!$p.length || $p[0].querySelector('#bn-dispenser')) return;
    // 大厅事件态（Bailey 收租/Robin 系列/<<homeevent>> 随机事件等分支渲染完选项就结束，
    // 没有底部动作区）不注入饮水机——Garden 链接只在默认大厅分支的底部动作区出现
    if (!$p[0].querySelector('a[data-passage="Garden"]')) return;
    // 大厅饮水机只认背包里的杯子：摆到洗手池的杯子拿不到大厅
    const cup = V.foodstuff.cup;
    const cur = cup && cup.amount > 0 ? (cup.waterMl || 0) : 0;
    let html = '<br>大厅角落里放着一台还能使用的饮水机。<br>';
    if (!cup || !(cup.amount > 0)) {
      html += '<span class="small-description">你没有杯子可以接水。</span><br>';
    } else {
      html += '<a class="bn-disp-act link-internal" data-act="fill">用水杯接水 (0:01)</a><br>';
      if (cur > 0) html += '<a class="bn-disp-act link-internal" data-act="drink">喝水 (0:02)</a><br>';
    }
    const box = document.createElement('div');
    box.id = 'bn-dispenser';
    box.innerHTML = html;
    box.addEventListener('click', e => {
      const a = e.target.closest('a.bn-disp-act');
      if (!a) return;
      e.preventDefault();
      if (a.dataset.act === 'fill') SugarCube.Engine.play('BasicNeeds Fill Water');
      else drinkCup();
    });
    $p[0].appendChild(box);
    BN.bnNumberLinks();
  }

  // ===== 学校食堂自助区（用户要求"类似原版超市那样"）：早/中/晚菜单各不同，每菜定价，
  // 饮品减口渴、食品减饥饿；点菜进餐盘，买单时统一扣钱+吃下+推 20 分钟。直接注入原版
  // Canteen 场景（锚 = 离开链接行前；离开行也是 img+a 兄弟结构，只能插在 img 前——
  // 同孤儿院大厅 Garden 链接的教训）。图标全部用游戏自带 tending/根目录图标，无 404 问题
  const CANTEEN_MENU = {
    breakfast: [
      { name: '白粥', icon: 'tending/porridge.png', price: 50, type: 'food', effect: { hunger: 3000, thirst: 6500 } },
      { name: '茶叶蛋', icon: 'tending/egg.png', price: 80, type: 'food', effect: { hunger: 1200 } },
      { name: '煎蛋卷', icon: 'tending/omelette.png', price: 180, type: 'food', effect: { hunger: 2500 } },
      { name: '英式早餐', icon: 'tending/full-english-breakfast.png', price: 400, type: 'food', effect: { hunger: 4500 } },
      { name: '温牛奶', icon: 'tending/milk.png', price: 100, type: 'drink', effect: { thirst: 7000 } },
      { name: '鲜榨橙汁', icon: 'tending/orange-juice.png', price: 250, type: 'drink', effect: { thirst: 7500 } }
    ],
    lunch: [
      { name: '米饭', icon: 'tending/rice.png', price: 100, type: 'food', effect: { hunger: 1500 } },
      { name: '糖醋鸡', icon: 'tending/sweet-and-sour-chicken.png', price: 350, type: 'food', effect: { hunger: 3000 } },
      { name: '煎牛排', icon: 'tending/steak.png', price: 500, type: 'food', effect: { hunger: 4000 } },
      { name: '周日烤肉', icon: 'tending/roast-dinner.png', price: 600, type: 'food', effect: { hunger: 5000 } },
      { name: '柠檬水', icon: 'tending/lemonade.png', price: 150, type: 'drink', effect: { thirst: 7000 } },
      { name: '瓶装水', icon: 'water-bottle.png', price: 50, type: 'drink', effect: { thirst: 6500 } }
    ],
    dinner: [
      { name: '炸鱼薯条', icon: 'tending/fish-and-chips.png', price: 400, type: 'food', effect: { hunger: 3500 } },
      { name: '千层面', icon: 'tending/lasagne.png', price: 450, type: 'food', effect: { hunger: 4000 } },
      { name: '三文鱼酥皮卷', icon: 'tending/salmon-wellington.png', price: 650, type: 'food', effect: { hunger: 5000 } },
      { name: '蔬菜沙拉', icon: 'tending/salad.png', price: 200, type: 'food', effect: { hunger: 1800 } },
      { name: '热牛奶', icon: 'tending/milk.png', price: 120, type: 'drink', effect: { thirst: 7000 } },
      { name: '冰镇柠檬饮', icon: 'tending/lemonade.png', price: 180, type: 'drink', effect: { thirst: 7500 } }
    ]
  };
  const CANTEEN_LABELS = { breakfast: '早餐', lunch: '午餐', dinner: '晚餐' };

  // 跨文件共享：挂到 window.BN
  Object.assign(BN, {
    annotateFoodLinks, annotateShowerLinks, bathChoiceHtml, bathGo, bathPrepSceneHtml,
    bathRadio, bathSkip, bindFoodLinks, bnDurText, bnFilterCoveredParts,
    bnHairGuard, bnShowerAreaHtml, brushFinishHtml, brushPick, brushSceneHtml,
    consumePlaced, drinkCup, fillPick, fillSceneHtml, injectHairdresserLock,
    injectShowerArea, injectSinkEntry, injectWaterDispenser, lockHair, mergePlacedBack,
    pickBathOption, placedSnapshot, renderBathChoice, toggleSinkItem, unlockHair,
    BODYWASH_MOOD, BODYWASH_USE_ML, BRUSH_DRY, BRUSH_DRY_QUICK, BRUSH_PASTE, BRUSH_PASTE_QUICK,
    BRUSH_STRESS, BRUSH_STRESS_QUICK, CANTEEN_LABELS,
    CANTEEN_MENU, CUP_ML, CUSTOM_EAT_EFFECT, DRINK_KEYS, HAIR_LOCK_AT,
    HAIR_RATE, INEDIBLE_RAW, KITCHEN_SCENES, SHAMPOO_USE_ML, STRESS_WASH_EXTRA,
    TEETH_RATE, TEETH_SWEET, TOOTHPASTE_USE, TOOTHPASTE_USE_QUICK, TOWEL_DRY_RATE, TOWEL_WET_PER,
    WATER_THIRST_PER_ML, bnBathPendingEnd,
  });
})();
