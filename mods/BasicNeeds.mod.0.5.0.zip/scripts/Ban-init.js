/* 基本需求 · 启动与挂载：:storyready init、各场景注入注册、读档迁移（身体框架见 Ban-body.js） */
(function () {
  'use strict';
  const BN = (window.BN = window.BN || {});

  function init() {
    BN.ensureVars();
    BN.injectFoodstuff();
    BN.lockCheatsBodySize();
    BN.initBackpackTab();
    BN.bindBackpackClicks();
    maplebirch.tool.addTo('StatusBar', BN.panelHtml);
    window.bnBrushSceneHtml = BN.brushSceneHtml;
    window.bnBrushPick = BN.brushPick;
    window.bnBrushFinishHtml = BN.brushFinishHtml;
    window.bnSinkToggle = BN.toggleSinkItem;
    window.bnFillSceneHtml = BN.fillSceneHtml;
    window.bnFillPick = BN.fillPick;
    window.bnBathPrepSceneHtml = BN.bathPrepSceneHtml;
    window.bnShowerAreaHtml = BN.bnShowerAreaHtml;
    window.bnBathGo = BN.bathGo;
    window.bnBathSkip = BN.bathSkip;
    window.bnSetBodyWater = BN.setBodyWater;
    window.bnSetBodyWaterAll = BN.setBodyWaterAll;
    window.bnWetClothesFromBody = BN.wetClothesFromBody;
    window.bnPartWetSlot = BN.bnPartWetSlot;
    window.bnWaterGooHtml = BN.bnWaterGooHtml;
    BN.registerMealScene();
    BN.registerShoppingBasement();
    BN.registerGroomScenes();
    BN.registerStreetShops();
    BN.registerMallToilet();
    window.bnMealTalkHtml = BN.contractTalkHtml;
    window.bnMealOptionsHtml = BN.contractOptionsHtml;
    window.bnBasementShopsHtml = BN.bnBasementShopsHtml;
    window.bnStreetShopHtml = BN.streetShopHtml;

    BN.watchBladderCheat();
    BN.bindWaterCheat();
    maplebirch.on(':passagedisplay', BN.injectCheatWater, 'BasicNeeds:cheatWater');
    jQuery(document).on(':passagedisplay.bnWater', BN.injectCheatWater);
    // observer 必须挂 document.body——#customOverlayContent 在 passage-footer 里随换页
    // 销毁重建（真实浏览器取证：storyready 时挂上的是开场页 footer 里的死元素，
    // 换页后永不触发）；BN.injectCheatWater 幂等早退（box 在/anchor 不在均无 DOM 操作），
    // 高频 body 子树变化安全
    if (window.MutationObserver && document.body) {
      new MutationObserver(() => BN.injectCheatWater()).observe(document.body, { childList: true, subtree: true });
      // 水的体液描述注入（侧栏 #statmeters 前，随侧栏重建自动重挂）
      new MutationObserver(() => BN.injectWaterGoo()).observe(document.body, { childList: true, subtree: true });
      // 侧栏菜单"身体"按钮（#overlayButtons 可能随菜单 overlay 重建，observer 兜底重挂）
      new MutationObserver(() => BN.injectMenuBodyButton()).observe(document.body, { childList: true, subtree: true });
    }
    BN.injectMenuBodyButton();
    BN.bindFoodLinks();
    // 每个 passage 渲染后按 V.timeStamp 差值连续结算——短行动也精确累计，
    // 不依赖整点事件（onHour 只在跨整点时触发，短行动会漏算）
    maplebirch.on(':passageend', () => {
      BN.tick();
      // 洗澡补清零（用户 257f91 v0.2.16"洗完是 75"）：洗澡场景体先 <<set $hygiene to 0>>
      // 再推时长（淋浴 30 分钟），settle 把这段时长按自然变脏加回去（0 + 150×0.5 = 75）——
      // 结算完成后重新归零，洗完即 0（bnBathPending 状态在 household 域内）
      BN.bnBathPendingEnd();
      // 睡觉渲染完成的结算（dt=整段睡眠）已在此发生，睡醒即清标志：
      // 醒后停留在 Sleep 页推的时间按清醒处理（满值会正常累计失禁）
      const bnNow = BN.ensureVars();
      if (bnNow.sleepingNow) bnNow.sleepingNow = false;
      BN.updatePanel();
      BN.injectRelief(); BN.injectEat(); BN.annotateFoodLinks(); BN.annotateShowerLinks(); BN.injectMobileStats(); BN.injectMealContract(); BN.injectMeals(); BN.bnRenumberLinks(); BN.bnNumberLinks(); BN.injectSinkEntry(); BN.injectShowerArea(); BN.injectWaterDispenser(); BN.injectHairdresserLock(); BN.injectCanteen(); BN.injectShoppingBasement();
    }, 'BasicNeeds:init');
    // DOL 存档快照（moment）在 :passageend 之前生成——只挂 :passageend 的话，
    // BN.tick 结算进不了当前时刻的存档，读档会回到旧数值并重复结算（读档灌满 bug）。
    // :passageinit 在引擎 push moment 之前触发，这里先结算，让修改进入即将保存的快照。
    maplebirch.on(':passageinit', BN.tick, 'BasicNeeds:presave');
    // 睡觉标志：所有睡觉流程最终渲染 :: Sleep passage（渲染循环逐小时 <<pass 1 hour>>），
    // 渲染开始即置位、:passageend 结算后清位（见 BN.settle 内注释）
    jQuery(document).on(':passagestart.bnSleep', () => {
      if (V.passage === 'Sleep') V.BasicNeeds.sleepingNow = true;
    });
    BN.tick();
    BN.updatePanel();
    console.log('[BasicNeeds] 基本需求 v0.5.0 已加载');
  }

  maplebirch.on(':storyready', init, 'BasicNeeds:startup');

  maplebirch.on(
    ':onLoad',
    save => {
      if (!save.V) return;
      if (!save.V.BasicNeeds && save.V.basicNeeds) {
        save.V.BasicNeeds = save.V.basicNeeds;
        delete save.V.basicNeeds;
      }
      if (!save.V.BasicNeeds || save.V.BasicNeeds.ver !== BN.BN_VER) {
        save.V.BasicNeeds = {
          ver: BN.BN_VER,
          hunger: 0,
          thirst: 0,
          bladder: 0,
          bowels: 0,
          lastTs: null,
          bladderFullHrs: 0
        };
      }
      // 读档后结算起点强制对齐存档时刻：无论存档由哪个版本保存、lastTs 是否被旧版本残留污染，
      // 时间差都从 0 起算，杜绝"读档即灌满"（数值保持存档时的值，之后随游戏时间正常增长）
      if (typeof save.V.timeStamp === 'number' && save.V.timeStamp >= 0) {
        save.V.BasicNeeds.lastTs = save.V.timeStamp;
      }
    },
    'BasicNeeds:onload'
  );
  // 跨文件共享：挂到 window.BN
  Object.assign(BN, {
    init,
  });
})();
