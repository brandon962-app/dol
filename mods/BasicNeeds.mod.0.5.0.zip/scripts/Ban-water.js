/* 基本需求 · 水液体系统：体表水位（0-5）、雨淋/自然晾干蒸发/穿衣蹭衣、
 * 侧栏水描述（仿原版 goo 档位）。水不注册进原版 liquidtype 类型表，
 * 由本系统全权管理写入与清除 */
(function () {
  'use strict';
  const BN = (window.BN = window.BN || {});

  function bnWaterParts() {
    const p = V.player || {};
    return BN.WATER_PARTS.filter(part => {
      if (part === 'vaginaoutside') return !!p.vaginaExist;
      if (part === 'penis') return !!p.penisExist;
      return true;
    });
  }

  // 自然晾干联动：按部位写入 bodyliquid.water（满值 5 与原版 cheat 面板上限一致；
  // 只动 water，goo/semen/nectar 不受影响；数据缺失时静默跳过）
  function setBodyWater(v) {
    if (!(V.player && V.player.bodyliquid)) return;
    for (const part of bnWaterParts()) {
      const obj = V.player.bodyliquid[part];
      if (obj) obj.water = v;
    }
  }

  // 全身水液体写值（表）：与 setBodyWater 等价的别名导出，供花洒区场景
  // 洗澡链接（<<setBodyWaterAll 0>>）与测试统一调用
  function setBodyWaterAll(v) {
    setBodyWater(v);
  }

  // 自然晾干蒸发：累计小时满 1 才全身 -1（整数步进，保持原版 numberStepper 整数语义；
  // floor 兜历史小数——0.5 会被下一次扣减直接清零）
  function dryBodyWater(hours, bn) {
    if (!(V.player && V.player.bodyliquid)) return;
    bn.waterDryAcc = (bn.waterDryAcc || 0) + hours;
    while (bn.waterDryAcc >= 1) {
      bn.waterDryAcc -= 1;
      for (const part of bnWaterParts()) {
        const obj = V.player.bodyliquid[part];
        if (obj && obj.water > 0) obj.water = Math.max(0, Math.floor(obj.water) - WATER_DRY_PER_HOUR);
      }
    }
  }

  // 雨天淋湿身体（用户 257f91）：部位→覆盖衣槽的门控湿度。返回 null=该部位无衣服
  // 覆盖（裸露，雨水直接淋身体），数字=覆盖衣的湿度（原版 V.upperwet 等 0-200），达到淋湿档
  // （>=80）才渗到身体。映射贴合原版衣服覆盖：胸=under_upper(贴身)→upper、肚子/双臂=upper、
  // 屁股/阴唇/阴茎=under_lower(贴身)→lower、大腿=lower；原版无湿度系统的槽位（帽子/鞋等）
  // 一律视为裸露。naked 占位（type 含 "naked"）视同没穿
  // bnPartWetSlot 返回部位覆盖衣的湿度变量键名（"underupperwet" 等）或 null=裸露；
  // bnPartCoverWetness 在其上读出当前湿度数字
  function bnPartWetSlot(part) {
    const w = V.worn || {};
    const naked = c => !c || !c.type || c.type.includes("naked");
    switch (part) {
      case "chest":
        if (!naked(w.under_upper)) return "underupperwet";
        if (!naked(w.upper)) return "upperwet";
        return null;
      case "tummy":
      case "rightarm":
      case "leftarm":
        return naked(w.upper) ? null : "upperwet";
      case "bottom":
      case "vaginaoutside":
      case "penis":
        if (!naked(w.under_lower)) return "underlowerwet";
        if (!naked(w.lower)) return "lowerwet";
        return null;
      case "thigh":
        return naked(w.lower) ? null : "lowerwet";
      default:
        return null;
    }
  }

  function bnPartCoverWetness(part) {
    const slot = bnPartWetSlot(part);
    if (slot === null) return null;
    return Number.isFinite(V[slot]) ? V[slot] : 0;
  }

  // 身上有水穿衣浸湿衣物（用户 257f91"玩家身上存在水（液体）时，穿上衣服也会浸湿衣物"）：
  // 每次结算把每个覆盖部位的原版衣湿度保底拉到 水位×BN_BODY_TO_CLOTH_WET（3 点=90"wet"档、
  // 5 点=150"drenched"档）——洗澡晾干 water 3 穿衣几分钟内衣服变湿，雨淋透 water 5 穿衣衣服湿透。
  // max 语义不叠加不回落：衣湿已被雨淋更高时保持原值，水蒸发后衣湿自行晾干。取代 v0.4.x 的
  // bn.bodyWet 穿衣 +80 湿身检测（其唯一行为被本函数以更准的水位档位覆盖）
  const BN_BODY_TO_CLOTH_WET = 30;
  function wetClothesFromBody(bn) {
    if (!(V.player && V.player.bodyliquid)) return;
    for (const part of bnWaterParts()) {
      const obj = V.player.bodyliquid[part];
      if (!obj) continue;
      const w = Math.floor(obj.water || 0);
      if (w < 1) continue;
      const slot = bnPartWetSlot(part);
      if (slot === null) continue;
      const cur = Number.isFinite(V[slot]) ? V[slot] : 0;
      const target = Math.min(200, w * BN_BODY_TO_CLOTH_WET);
      if (target > cur) V[slot] = target;
    }
  }

  // 雨天淋湿身体（改版：下雨就开始淋湿——用户 257f91"我需要没有遮挡的部分
  // 在下雨就开始淋湿"）：每个部位独立小数累计器 bn.waterRainFrac[part] 按结算小时数累积
  // RAIN_WET_PER_HOUR×雨强，floor 部分进 water（cap 5）——淋雨几分钟就有水位变化，不再等
  // 满 1 整点才步进。裸露部位（cover null）恒淋；被遮部位当刻覆盖衣湿度达淋湿档（>=80）
  // 才开始积（干衣挡雨、湿透衣渗水）。只写 water，不碰 goo/semen/nectar
  function rainWetBodyWater(hours, bn) {
    if (!(V.player && V.player.bodyliquid)) return;
    let itv = 1;
    try {
      const n = Number(Weather && Weather.precipitationIntensity);
      if (Number.isFinite(n) && n > 0) itv = n;
    } catch (e) {}
    if (!bn.waterRainFrac || typeof bn.waterRainFrac !== 'object') bn.waterRainFrac = {};
    for (const part of bnWaterParts()) {
      const cover = bnPartCoverWetness(part);
      if (cover !== null && cover < BN_WET_GATE) continue;
      const obj = V.player.bodyliquid[part];
      if (!obj) continue;
      bn.waterRainFrac[part] = (bn.waterRainFrac[part] || 0) + hours * RAIN_WET_PER_HOUR * itv;
      if (bn.waterRainFrac[part] >= 1) {
        const add = Math.floor(bn.waterRainFrac[part]);
        bn.waterRainFrac[part] -= add;
        obj.water = Math.min(5, Math.floor(obj.water || 0) + add);
      }
    }
  }

  // 雨中淋湿判定（与原版雨中加湿分支同款条件）：室外（原版 truthy 判定）+ 降雨 +
  // 头部/手持无 rainproof（雨帽/伞挡全身）。防水衣（swim/stealthy/rainproof/waterproof）在
  // 原版不加湿、湿度恒低，门控天然挡雨，无需显式判定
  function bnRainSoak() {
    try {
      if (!V.outside) return false;
      if (!Weather || Weather.precipitation !== "rain") return false;
      const rp = c => c && c.type && c.type.includes("rainproof");
      if (rp(V.worn && V.worn.head) || rp(V.worn && V.worn.handheld)) return false;
      return true;
    } catch (e) {
      return false;
    }
  }

  // 自然晾干联动：身体水液体（bodyliquid water）蒸发速率，每小时全身 -1 点（满 5 点约 5 小时干透）
  const WATER_DRY_PER_HOUR = 1;
  // 雨天淋湿身体：雨中每小时全身 +5 点（裸露或覆盖衣已达淋湿档的部位），1 小时淋透；
  // 覆盖衣门控阈值沿用原版 wetnessKeyword 的 "wet"（淋湿）档下限（衣湿 0-200：>=50 damp/潮湿、>=80 wet/淋湿、>=100 drenched/湿透）
  const RAIN_WET_PER_HOUR = 5;
  const BN_WET_GATE = 80;
  function bnWaterGooHtml() {
    if (!(V.player && V.player.bodyliquid)) return '';
    let cnt = 0;
    for (const part of bnWaterParts()) cnt += V.player.bodyliquid[part].water || 0;
    if (cnt <= 0) return '';
    let text;
    if (cnt >= 25) text = '<span class="pink">大量的水浸透了你。</span>';
    else if (cnt >= 20) text = '<span class="purple">你被水淋得湿透。</span>';
    else if (cnt >= 15) text = '<span class="purple">你的皮肤被水浸得湿滑。</span>';
    else if (cnt >= 10) text = '<span class="purple">你浑身湿漉漉地淌着水。</span>';
    else if (cnt >= 5) text = '<span class="purple">你的皮肤上水汪汪的。</span>';
    else text = '<span class="blue">你感到皮肤上有水。</span>';
    return text + '<br>';
  }

  // 注入：#statmeters beforebegin（原版 <<goo>> 输出正后方）。幂等早退防 body observer 自触
  // 循环（BN.syncDetailBox 同款模式）
  function injectWaterGoo() {
    try {
      const anchor = document.getElementById('statmeters');
      if (!anchor) return;
      const html = bnWaterGooHtml();
      const old = document.getElementById('bn-water-goo');
      if (!html) {
        if (old) old.remove();
        return;
      }
      if (old) {
        if (old.__bnHtml === html) return;
        old.__bnHtml = html;
        old.innerHTML = html;
        return;
      }
      const box = document.createElement('div');
      box.id = 'bn-water-goo';
      box.__bnHtml = html;
      box.innerHTML = html;
      anchor.insertAdjacentElement('beforebegin', box);
    } catch (e) { /* 侧栏结构异常时静默跳过 */ }
  }

  // 池边/置物架摆放切换（管理；真分离）：放置 = 从堆叠拆一件独立出去
  // （背包数量真实减一、耐久/水量由 placed 自带），收回 = 并回堆叠（耐久取 min、杯水相加）
  // 跨文件共享：挂到 window.BN
  Object.assign(BN, {
    bnPartCoverWetness, bnPartWetSlot, bnRainSoak, bnWaterGooHtml, bnWaterParts,
    dryBodyWater, injectWaterGoo, rainWetBodyWater, setBodyWater, setBodyWaterAll,
    wetClothesFromBody, BN_BODY_TO_CLOTH_WET, BN_WET_GATE, RAIN_WET_PER_HOUR, WATER_DRY_PER_HOUR,
  });
})();
