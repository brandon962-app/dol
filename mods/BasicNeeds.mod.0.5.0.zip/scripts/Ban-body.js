/* 基本需求 · 身体框架：侧栏"身体"按钮 + 基础信息面板（身份/热量/状态区块）+ 身高体重 BMI
 * 面板挂在原版 customOverlay（与"属性"页同款机制）；身高体重 BMI 联动原版身体尺寸；
 * 创建页"基础信息"分区与统计页身高体重行也由本文件注入
 */
(function () {
  'use strict';
  const BN = (window.BN = window.BN || {});

  // 侧栏菜单"身体"格子：点击打开身体总览面板（customOverlay 机制与原版"属性"页同款
  // ——标题用原版 tab 按钮形态+customOverlayClose 关闭键，内容填 #customOverlayContent 后移除 hidden）。
  // 关闭走原版 X（closeOverlay）或再点一次身体按钮（toggle 保证总能退出）
  function bnShowBody() {
    const co = document.getElementById('customOverlay');
    const cc = document.getElementById('customOverlayContainer');
    const title = document.getElementById('customOverlayTitle');
    const content = document.getElementById('customOverlayContent');
    if (!co || !cc || !title || !content) return;
    if (!co.classList.contains('hidden') && content.querySelector('#bn-body-panel')) {
      co.classList.add('hidden');
      cc.classList.add('hidden');
      return;
    }
    const pages = { base: BN.bodyPanelHtml(), parts: '<div id="bn-body-panel">' + BN.bodyPartsHtml() + '</div>' };
    title.innerHTML = '<div id="overlayTabs" class="tab">'
      + '<button class="link-internal macro-button tab-selected" type="button" role="button" tabindex="0" data-bn-tab="base">基础信息</button>'
      + '<button class="link-internal macro-button" type="button" role="button" tabindex="0" data-bn-tab="parts">部件详细</button></div>'
      + '<div class="customOverlayClose" onclick="closeOverlay()"></div>';
    content.innerHTML = pages.base;
    title.querySelectorAll('[data-bn-tab]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        title.querySelectorAll('[data-bn-tab]').forEach(function (b) { b.classList.toggle('tab-selected', b === btn); });
        content.innerHTML = pages[btn.getAttribute('data-bn-tab')];
      });
    });
    cc.classList.remove('hidden');
    co.classList.remove('hidden');
  }

  // 往 #overlayButtons 开头（"属性"按钮上方）插独占一行"身体"按钮（Mod管理器按钮同款形态）；
  // 幂等：已有标记行就跳过
  function injectMenuBodyButton() {
    const ob = document.getElementById('overlayButtons');
    if (!ob || ob.querySelector('[data-bn-body-btn]')) return;
    ob.insertAdjacentHTML('afterbegin',
      '<div class="sidebarButtonSplit" data-bn-body-btn="1"><button type="button" class="link-internal macro-button">身体</button></div><br>');
    const btn = ob.querySelector('[data-bn-body-btn] button');
    if (btn) btn.addEventListener('click', bnShowBody);
  }
  BN.injectMenuBodyButton = injectMenuBodyButton;

  // ===== 身高 / 体重 / BMI（v0.2.9，用户需求：创建时输入身高体重，按 BMI 联动原版身体尺寸）=====
  // 原版变量：$bodysize 0-3（偏小/娇小/中等/大体型）+ $physiquesize（6000/9000/12000/15000，物理上限）
  // 体型（bodyshape）用户要求不接管——保持原版自由选择
  const BN_HW_SIZE_PX = [6000, 9000, 12000, 15000];
  const BN_HW_SIZE_LABELS = ['偏小', '娇小', '中等', '大体型'];
  const BN_HW_DEFAULTS = [[150, 38], [158, 48], [165, 58], [172, 74]];
  function bnBmi(h, w) { return w / Math.pow(h / 100, 2); }
  function bnBmiToSize(bmi) { return bmi < 17 ? 0 : bmi < 19.5 ? 1 : bmi < 24 ? 2 : 3; }
  function bnHwText() {
    const h = Math.round(BN.clamp(V.bnHeight || 165, 120, 220));
    const w = Math.round(BN.clamp(V.bnWeight || 58, 30, 200));
    const bmi = bnBmi(h, w);
    return '身高 ' + h + ' cm　体重 ' + w + ' kg　BMI ' + bmi.toFixed(1) + '（' + BN_HW_SIZE_LABELS[bnBmiToSize(bmi)] + '）';
  }
  function bnApplyBmi() {
    const h = Math.round(BN.clamp(V.bnHeight || 165, 120, 220));
    const w = Math.round(BN.clamp(V.bnWeight || 58, 30, 200));
    V.bnHeight = h; V.bnWeight = w;
    const bmi = bnBmi(h, w);
    const size = bnBmiToSize(bmi);
    // physique 按体能上限比例同步缩放（同原版 cheatsBodySize 联动模式）
    const oldPx = typeof V.physiquesize === 'number' ? V.physiquesize : null;
    V.bodysize = size;
    V.physiquesize = BN_HW_SIZE_PX[size];
    if (oldPx && typeof V.physique === 'number' && oldPx !== V.physiquesize) V.physique = Math.round(V.physique * V.physiquesize / oldPx);
    return { size, bmi };
  }
  function bnHwInputHtml() {
    const h = Math.round(BN.clamp(V.bnHeight || 165, 120, 220));
    const w = Math.round(BN.clamp(V.bnWeight || 58, 30, 200));
    const name = (V.player && V.player.name) || '';
    const blood = (V.BasicNeeds && V.BasicNeeds.bloodType) || '';
    const bloodOpts = ['', 'A', 'B', 'AB', 'O'].map(v =>
      '<option value="' + v + '"' + (blood === v ? ' selected' : '') + '>' + (v ? v + ' 型' : '未设置') + '</option>').join('');
    const frag = document.createDocumentFragment();
    const header = document.createElement('div');
    header.className = 'settingsHeader';
    header.textContent = '基础信息';
    const idCard = document.createElement('div');
    idCard.className = 'settingsToggleItem';
    idCard.id = 'bn-create-identity';
    idCard.innerHTML =
      '<div class="bn-two-col">' +
      '<div><span class="gold">姓名:</span><br>' +
      '<input type="text" id="bn-name" class="bn-hw-input bn-name-input" maxlength="16" value="' + BN.escapeHtml(name) + '" placeholder="输入姓名"></div>' +
      '<div><span class="gold">血型:</span><br>' +
      '<select id="bn-bloodtype" class="bn-hw-input">' + bloodOpts + '</select></div>' +
      '</div>';
    const bodyCard = document.createElement('div');
    bodyCard.className = 'settingsToggleItem';
    bodyCard.id = 'bn-create-body';
    bodyCard.innerHTML =
      '<span class="gold">身高 / 体重:</span><br>' +
      '<input type="number" id="bn-height" class="bn-hw-input" min="120" max="220" step="1" value="' + h + '"> cm　' +
      '<input type="number" id="bn-weight" class="bn-hw-input" min="30" max="200" step="1" value="' + w + '"> kg　' +
      '<span id="bn-bmi-display" class="blue">' + bnHwText().split('　')[2] + '</span><br>' +
      '<span class="small-description">根据 BMI 自动调整身体尺寸（改身高/体重立即生效）。体型可在下方自由选择。</span>';
    frag.append(header, idCard, bodyCard);
    return frag;
  }
  function syncHeightWeightCreate() {
    const radio = document.querySelector('#passages input[name="radiobutton-bodysize"]');
    if (!radio) return;
    if (document.querySelector('#bn-create-identity')) return;
    // Start 页有 8 个 .settingsGrid（每分区一个），必须从 radio 所在的"身体"分区 grid 定位，
    // document.querySelector 会命中无横幅的"随机化"grid 导致静默插错
    const grid = radio.closest('.settingsGrid');
    const header = grid && grid.querySelector('.settingsHeader');
    if (!grid || !header) return;
    grid.insertBefore(bnHwInputHtml(), header);
    bindBnHwInputs();
    // 身体尺寸由 BMI 接管（用户要求创建处禁止修改）：禁用 radio + 灰化 label + 提示
    ['radiobutton-bodysize'].forEach(name => {
      document.querySelectorAll('#passages input[name="' + name + '"]').forEach(r => {
        if (r.disabled) return;
        r.disabled = true;
        const lab = r.closest('label');
        if (lab) lab.classList.add('gray');
      });
      const first = document.querySelector('#passages input[name="' + name + '"]');
      const item = first && first.closest('.settingsToggleItem');
      if (item && !item.querySelector('.bn-bmi-lock')) {
        const tip = document.createElement('span');
        tip.className = 'bn-bmi-lock small-description';
        tip.textContent = '（由身高体重 BMI 自动决定）';
        const gold = item.querySelector('span.gold');
        if (gold) gold.appendChild(tip); else item.appendChild(tip);
      }
    });
  }
  function bindBnHwInputs() {
    ['bn-height', 'bn-weight'].forEach(id => {
      const el = document.getElementById(id);
      if (!el || el.dataset.bnBound) return;
      el.dataset.bnBound = '1';
      el.addEventListener('change', () => {
        V[id === 'bn-height' ? 'bnHeight' : 'bnWeight'] = parseFloat(el.value) || (id === 'bn-height' ? 165 : 58);
        bnApplyBmi();
        // 同步原版单选 UI：SugarCube radiobutton 的 input.value 恒为 "on"，真值靠 id 序号（radiobutton-bodysize-N）
        document.querySelectorAll('#passages input[name="radiobutton-bodysize"]').forEach(r => { r.checked = r.id === 'radiobutton-bodysize-' + V.bodysize; });
        const disp = document.getElementById('bn-bmi-display');
        if (disp) disp.textContent = bnHwText().split('　')[2];
      });
    });
    const nameEl = document.getElementById('bn-name');
    if (nameEl && !nameEl.dataset.bnBound) {
      nameEl.dataset.bnBound = '1';
      nameEl.addEventListener('change', () => {
        const v = nameEl.value.trim();
        if (v) V.player.name = v;
        else nameEl.value = (V.player && V.player.name) || '';
      });
    }
    const bloodEl = document.getElementById('bn-bloodtype');
    if (bloodEl && !bloodEl.dataset.bnBound) {
      bloodEl.dataset.bnBound = '1';
      bloodEl.addEventListener('change', () => {
        V.BasicNeeds.bloodType = bloodEl.value;
      });
    }
  }
  function syncHeightWeightStats() {
    const $s = $('#statsBodySize');
    if (!$s.length) return;
    const $card = $s.closest('.settingsToggleItem');
    if (!$card.length) return;
    let $row = $('#bn-hw-stats');
    const text = bnHwText();
    if (!$row.length) {
      // 用户 257f91：身高体重放"身体"卡片下面——插到 Body 卡片内部末尾（grid 格子外插会排到右边）
      $row = $('<div id="bn-hw-stats" style="margin-top:6px"><span class="gold">身高 / 体重:</span><br><span class="bn-hw-text"></span><br><span class="small-description">身体尺寸由身高体重 BMI 自动决定，作弊菜单不可手改。</span></div>');
      $card.append($row);
    }
    $row.find('.bn-hw-text').text(text);
  }

  // 状态快照（基础信息面板"状态"区）：复刻侧栏 #statmeters 的全部行（原版 pain/stress/trauma 等
  // caption 行 + 整合包 allurecaption + mod #bn-panel 行）——不重算档位，颜色/文案/数值 title 所见即所得；
  // 每行追加（数值）（title 解析），两列排布、行间虚线、meter 条由 CSS 修 z-index 后可见
  function statsSnapshotHtml() {
    const sm = document.getElementById('statmeters');
    if (!sm || !sm.children.length) return '';
    const rows = [];
    const numHtml = (title) => {
      const v = Math.round(parseFloat((title || '').split(/[:：]\s*/)[1]));
      return isFinite(v) ? '<span class="teal">（' + v + '）</span>' : '';
    };
    for (const row of sm.children) {
      const isBn = row.id === 'bn-panel';
      const lines = isBn ? Array.from(row.querySelectorAll('.bn-line')) : [row];
      for (const line of lines) {
        const text = isBn ? line.querySelector('.bn-text') : line.querySelector('div:not(.meter)');
        if (!text) continue;
        const meter = line.querySelector('.meter');
        rows.push('<div class="bn-line"' + (line.title ? ' title="' + BN.escapeHtml(line.title) + '"' : '')
          + '><div class="bn-text">' + text.innerHTML.trim() + numHtml(line.title) + '</div>'
          + (meter ? meter.outerHTML : '') + '</div>');
      }
    }
    if (!rows.length) return '';
    const mid = Math.ceil(rows.length / 2);
    return '<div class="settingsHeader">状态</div><div class="settingsToggleItem bn-stats-card">'
      + '<div class="bn-stats-cols"><div class="bn-stats-col">' + rows.slice(0, mid).join('') + '</div>'
      + '<div class="bn-stats-col">' + rows.slice(mid).join('') + '</div></div></div>';
  }

  // 基础信息总览面板（侧栏菜单"身体"格子打开）：身份（姓名/血型）+ 身体状态只读展示；
  // 编辑入口在创建页（姓名/血型）、作弊菜单（牙齿/头发 stepper）、花洒区（洗澡）、理发店（洗头）
  function bodyPanelHtml() {
    const bn = BN.ensureVars();
    const pName = (V.player && V.player.name) || '';
    const nameHtml = pName ? '<span class="teal">' + BN.escapeHtml(pName) + '</span>' : '<span class="gray">未设置</span>';
    const genderRaw = (V.player && V.player.gender) || '';
    const genderHtml = genderRaw
      ? '<span class="teal">' + ({ m: '男', f: '女', herm: '其他' })[genderRaw] + '</span>'
      : '<span class="gray">未知</span>';
    const bloodHtml = bn.bloodType ? '<span class="teal">' + bn.bloodType + ' 型</span>' : '<span class="gray">未知</span>';
    const h = Math.round(BN.clamp(V.bnHeight || 165, 120, 220));
    const w = Math.round(BN.clamp(V.bnWeight || 58, 30, 200));
    const bmi = bnBmi(h, w);
    const bmiHtml = '<span class="teal">' + bmi.toFixed(1) + '</span>（' + BN_HW_SIZE_LABELS[bnBmiToSize(bmi)] + '）';
    const kv = (label, val) => '<div class="bn-text">' + label + '：' + val + '</div>';
    // 热量追踪（框架）：BMR 用 Mifflin-St Jeor（原版无年龄字段，兜底 18）；活动系数/每日需求待接入故值留空
    const kc = bn.kcal;
    const age = (V.player && typeof V.player.age === 'number') ? V.player.age : 18;
    const bmrBase = 10 * w + 6.25 * h - 5 * age;
    const bmr = Math.round(genderRaw === 'f' ? bmrBase - 161 : genderRaw === 'herm' ? bmrBase - 78 : bmrBase + 5);
    const todayDiff = (kc.intake || 0) - (kc.burned || 0);
    let html = '<div id="bn-body-panel">'
      + '<div class="bn-panel-cols"><div class="settingsToggleItem">'
      + '<span class="gold">基础</span><br>'
      + kv('姓名', nameHtml) + kv('性别', genderHtml) + kv('身高', '<span class="teal">' + h + '</span> cm') + kv('体重', '<span class="teal">' + w + '</span> kg') + kv('BMI', bmiHtml) + kv('血型', bloodHtml)
      + '</div><div class="settingsToggleItem bn-kcal-card">'
      + '<span class="gold">热量</span><br>'
      + kv('基础代谢', '<span class="teal">' + bmr + '</span> kcal/天')
      + kv('今日摄入', '<span class="teal">' + kc.intake + '</span> kcal')
      + kv('今日消耗', '<span class="teal">' + kc.burned + '</span> kcal')
      + kv('今日盈亏', '<span class="teal">' + (todayDiff > 0 ? '+' : '') + todayDiff + '</span> kcal')
      + kv('累计盈亏', '<span class="teal">' + (kc.total > 0 ? '+' : '') + kc.total + '</span> kcal')
      + '</div></div>';
    return html + statsSnapshotHtml() + '</div>';
  }

  // 跨文件共享：挂到 window.BN
  Object.assign(BN, {
    bindBnHwInputs, bnApplyBmi, bnBmi, bnBmiToSize, bnHwInputHtml, bnHwText,
    bodyPanelHtml, syncHeightWeightCreate, syncHeightWeightStats,
    BN_HW_DEFAULTS, BN_HW_SIZE_LABELS, BN_HW_SIZE_PX,
  });
})();
