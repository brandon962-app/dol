/* 基本需求 · 背包系统：日志面板"背包"tab、物品详情盒、点击使用 */
(function () {
  'use strict';
  const BN = (window.BN = window.BN || {});

  // 背包 tab（v0.3.13 显示 / 交互化）：数量 = 纯背包持有量（放置件已真实拆出，
  // 不再显示扣减）；点击条目展开详情（效果+状态+直接使用）——展开状态存 bnBpOpen，
  // 点击经 document 级委托（渲染走 <<= >>，无稳定绑定时机）
  let bnBpOpen = null;

  function bnBackpackUseText(key) {
    const eff = BN.eatEffect(key, setup.foodstuff[key]);
    const t = [];
    if (eff.hunger) t.push('饥饿-' + eff.hunger / 1000);
    if (eff.thirst) t.push('口渴-' + eff.thirst / 1000);
    if (eff.mood) t.push('心情+' + eff.mood / 1000);
    return t.join(' ');
  }

  // 详情内容：食用物品 = 效果+吃/喝；日用品 = 用途效果+状态说明（用户明确
  // 删掉"去浴室"跳转按钮——背包只提供信息，使用仍走原版场景流程）
  function bnBpDetailHtml(key) {
    if (BN.INEDIBLE_RAW.indexOf(key) === -1) {
      const effText = bnBackpackUseText(key);
      return (effText ? '<span class="gold">' + effText + '</span><br>' : '') +
        '<a class="bn-bp-use" data-bnuse="' + key + '">' + (BN.DRINK_KEYS.indexOf(key) !== -1 ? '喝掉一份' : '吃掉一份') + ' (0:05)</a>';
    }
    const st = V.foodstuff[key];
    const sink = BN.ensureVars().sink || {};
    switch (key) {
      case 'cup': {
        const ml = st ? (st.waterMl || 0) : 0;
        return ml > 0
          ? '<span class="gold">喝水：口渴-' + Math.round(ml * BN.WATER_THIRST_PER_ML / 100) / 10 + '</span><br><a class="bn-bp-use" data-bndrinkcup="1">喝掉 (0:02)</a>'
          : '<span class="small-description">到大厅或厨房的饮水机装水。</span>';
      }
      case 'toothpaste':
        return '<span class="gold">刷牙：-压力 -牙齿</span><br>' +
          '<span class="small-description">' + (sink.toothpaste ? '在洗手池刷牙时消耗。' : '先到浴室洗手池把它摆出来。') + '</span>';
      case 'toothbrush':
        return '<span class="gold">刷牙：-压力 -牙齿</span><br>' +
          '<span class="small-description">' + (sink.toothbrush ? '已摆在洗手池。' : '先到浴室洗手池把它摆出来。') + '</span>';
      case 'bodywash':
        return '<span class="gold">洗澡：-压力 -心情</span><br>' +
          '<span class="small-description">' + (sink.bodywash ? '在花洒区洗澡时消耗。' : '先到花洒区把它放到置物架上。') + '</span>';
      case 'shampoo':
        return '<span class="gold">洗头：清洁头发 -压力</span><br>' +
          '<span class="small-description">' + (sink.shampoo ? '在花洒区洗头时消耗。' : '先到花洒区把它放到置物架上。') + '</span>';
      case 'sponge': {
        const wet = st ? (st.wet || 0) : 0;
        return '<span class="gold">洗澡后擦干身体</span><br><span class="small-description">' +
          (wet >= 100 ? '湿透了，晾干后才能再用。' : wet > 0 ? '晾干中（湿 ' + Math.round(wet) + '%）。' : '干燥，可以用来擦干身体。') + '</span>';
      }
      case 'soap':
        return '<span class="small-description">日常洗漱用品。</span>';
      default:
        return '<span class="small-description">这件物品不能直接使用。</span>';
    }
  }

  function bnBackpackHtml() {
    const owned = [];
    Object.keys(V.foodstuff || {}).forEach(key => {
      const def = setup.foodstuff[key];
      const st = V.foodstuff[key];
      const n = st ? (st.amount || 0) : 0;
      if (def && n > 0) {
        owned.push({ key, idx: def.index === undefined ? 9999 : def.index });
      }
    });
    if (!owned.length) return '<div class="bn-bp"><p class="bn-bp-empty">背包空空如也。</p></div>';
    if (bnBpOpen && owned.every(it => it.key !== bnBpOpen)) bnBpOpen = null;
    owned.sort((a, b) => a.idx - b.idx);
    let html = '<div class="bn-bp"><div class="bn-bp-grid">';
    owned.forEach(it => {
      const def = setup.foodstuff[it.key];
      const n = V.foodstuff[it.key].amount;
      const img = V.options && V.options.images && def.icon
        ? '<img src="' + BN.bnShopIconSrc(def.icon) + '" alt="">'
        : '';
      const dur = BN.bnDurText(it.key);
      html += '<div class="bn-bp-item' + (bnBpOpen === it.key ? ' bn-bp-open' : '') + '" data-bnbp="' + it.key + '">' + img +
        '<span class="bn-bp-name">' + BN.escapeHtml(BN.bnShopName(it.key)) + '</span>' +
        '<span class="bn-bp-qty gold">×' + n + '</span>' +
        (dur ? '<span class="bn-bp-dur">' + dur + '</span>' : '') + '</div>';
    });
    return html + '</div></div>';
  }

  // 详情盒子：显示在日志面板右侧的独立区域（用户指定），不占物品网格。
  // 挂在原版 #customOverlay（absolute 定位上下文）下、left:100% 贴面板右缘，随面板
  // 一起显示/隐藏；内容与选中物品（bnBpOpen）保持同步
  function syncDetailBox() {
    const c = document.getElementById('customOverlayContent');
    const box = document.getElementById('bn-bp-detailbox');
    if (!c || !c.querySelector('.bn-bp') || !bnBpOpen) {
      if (box) box.remove();
      return;
    }
    const ov = document.getElementById('customOverlay');
    if (!ov) return;
    let b = box;
    if (!b) {
      b = document.createElement('div');
      b.id = 'bn-bp-detailbox';
      ov.appendChild(b);
    }
    // 内容相同不重写：observer 挂 body 子树后，这里每次 innerHTML 赋值都会再触发自己
    // 形成无限循环——数据变化路径（吃掉/喝掉/放置）都走显式 refreshBackpack，输出必然
    // 变化会正常重渲染
    const html = bnBpDetailHtml(bnBpOpen);
    if (b.__bnHtml === html) return;
    b.__bnHtml = html;
    b.innerHTML = html;
  }

  // 背包详情刷新：#customOverlayContent 当前显示背包时重渲染（数量/耐久即时变化）。
  // 显式同步详情盒子（observer 是首帧渲染路径的主通道，这里兜点击路径）
  function refreshBackpack() {
    const c = document.querySelector('#customOverlayContent');
    if (c && c.querySelector('.bn-bp')) c.innerHTML = window.bnBackpackHtml();
    syncDetailBox();
  }

  function bindBackpackClicks() {
    // 背包 tab 渲染在 #customOverlay 内，该元素带内联 onclick="event.stopPropagation()"
    // （防"点外关闭"），document 冒泡委托收不到 overlay 内任何点击——委托必须走捕获阶段
    document.addEventListener('click', e => {
      const use = e.target.closest ? e.target.closest('[data-bnuse]') : null;
      if (use) {
        window.bnEatItem(use.getAttribute('data-bnuse'));
        bnBpOpen = null;
        refreshBackpack();
        return;
      }
      const drink = e.target.closest ? e.target.closest('[data-bndrinkcup]') : null;
      if (drink) {
        BN.drinkCup();
        refreshBackpack();
        return;
      }
      const item = e.target.closest ? e.target.closest('[data-bnbp]') : null;
      if (item) {
        const k = item.getAttribute('data-bnbp');
        bnBpOpen = bnBpOpen === k ? null : k;
        refreshBackpack();
      }
    }, true);
  }

  // tab 行注入方式（v0.4.1 起）：不再运行时覆盖 titleJournal/titlejournalNotes widget
  // （Widget.add 同名覆盖是"最后到者赢"，会抹掉其他 mod 对 tab 行的编译期修改——曾顶掉
  // 原版优化「可用物品」按钮）。改为 boot.json 的 TweeReplacer 编译期补丁：锚原版
  // closeButtonMobile + Journal 按钮原文，在其前插入"背包"按钮（twee/replace/ 片段），
  // 与原版优化的可用物品补丁改动区域不重叠、链式顺序无关。bnBackpack widget 仍运行时注册。
  function initBackpackTab() {
    window.bnBackpackHtml = bnBackpackHtml;
    // 详情盒子同步：content 被任何路径替换（tab 首次渲染/refreshBackpack/切到日志笔记）都经
    // observer 触发——content 是背包且有选中物品则挂/更新右侧盒子，否则移除（切 tab 不残留）。
    // observer 挂 document.body（#customOverlayContent 在 passage-footer 里随换页销毁重建，
    // storyready 时挂的是开场页的死元素，换页后永不触发——真实浏览器取证），subtree
    // 覆盖 <<replace #cheatsShown>> 型深层替换
    try {
      new MutationObserver(syncDetailBox).observe(document.body, { childList: true, subtree: true });
    } catch (e) { console.warn('[BasicNeeds] detailbox observer init failed:', e); }
    try {
      Wikifier.wikifyEval('<<widget "bnBackpack">><<= window.bnBackpackHtml()>><</widget>>');
    } catch (e) { console.warn('[BasicNeeds] backpack tab BN.init failed:', e); }
  }

  // 跨文件共享：挂到 window.BN
  Object.assign(BN, {
    bindBackpackClicks, bnBackpackHtml, bnBackpackUseText, bnBpDetailHtml,
    initBackpackTab, refreshBackpack, syncDetailBox,
  });
})();
