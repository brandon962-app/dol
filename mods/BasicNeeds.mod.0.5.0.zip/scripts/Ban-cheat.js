/* 基本需求 · 作弊面板注入：水分组（numberStepper×部位）、体型尺寸锁定 */
(function () {
  'use strict';
  const BN = (window.BN = window.BN || {});

  function lockCheatsBodySize() {
    // 覆盖原版 cheatsBodySize（作弊菜单/Traits 卡片的"身体尺寸"4 档链接）：渲染只读档位，
    // 无链接——size 修改权全部交给 BMI（BN.bnApplyBmi）
    try {
      Wikifier.wikifyEval(
        '<<widget "cheatsBodySize">>' +
        '<<set _bnlab to ["偏小", "娇小", "中等", "大体型"]>>' +
        '<<set _bni to $bodysize is undefined ? 2 : $bodysize>>' +
        '<<set _bni to _bni gte 0 and _bni lte 3 ? _bni : 2>>' +
        '<span class="gold"><<print _bnlab[_bni]>></span> <span class="small-description">（由身高体重 BMI 自动决定）</span>' +
        '<</widget>>'
      );
    } catch (e) { console.warn('[BasicNeeds] lock cheatsBodySize failed:', e); }
  }

  // ===== 作弊菜单"水"液体（用户 257f91：在液体处增加水的液体，内容要和原版一样）=====
  // 原版 Fluids 区块 = cheatBodyLiquid widget 按类型渲染（semen/goo/nectar），数据
  // $player.bodyliquid[部位][液体类型]，类型表 setup.bodyliquid.liquidtype（原版注释明确
  // 支持"add a new liquid"）。水走同一条数据链：BN.ensureVars 注册类型+初始化键（bodyliquid
  // 宏全清是 BN.clamp(值+amount)，键缺失会 undefined+5=NaN）；分组复用原版 numberStepper 宏
  // （callback 写 V.player.bodyliquid.部位.water + updatesidebarimg），标签直接中文
  // （mod 动态渲染不经 ModI18N）。不含进 combined()（硬编码三项）——不污染"Covered in"
  // 文案与立绘液体层。
  // 修"水没出现"（用户 257f91）：Fluids 区块在作弊 overlay 的 Visual tab
  // （<<replace #cheatsShown>><<cheats-characterVisual>>）里**懒加载**——打开作弊页默认
  // Stats tab，:passagedisplay 只在进页瞬间触发一次，点 Visual 不触发任何 passage 事件，
  // 注入钩子永远等不到那一刻。改为 MutationObserver 监听 #customOverlayContent 子树
  // （背包详情同款机制；cheatsShown 本身动态渲染、不能直接挂），内容一变就试注入；
  // :passagedisplay 双链保留（maplebirch+jQuery，幂等防重复）作直接渲染场景的兜底。
  // 部位表收窄 + 性别过滤：阴道/肛门/口腔三处排除、阴茎/阴唇按
  // penisExist/vaginaExist 动态过滤（BN.bnWaterParts 定义在 BN.setBodyWater 前），本段注入与
  // waterAll 自动沿用动态表。

  function bnCheatWaterSource() {
    let src = '<div class="settingsToggleItem"><span class="gold">水</span><br>';
    src += '<a class="bn-water-all" data-bnwater="1">添加所有水</a> | <a class="bn-water-all" data-bnwater="-1">移除所有水</a><br>';
    for (const part of BN.bnWaterParts()) {
      const cur = V.player && V.player.bodyliquid && V.player.bodyliquid[part] ? V.player.bodyliquid[part].water : 0;
      src += '<<numberStepper "' + BN.WATER_PART_CN[part] + '" ' + (Number.isFinite(cur) ? cur : 0) +
        ' { "max": 5, "step": 1, "values": ["water"], "activeButtons": ["single", "minMax"], "percentage": false, "reverse": true, "css": { "display": "inline-block", "margin-bottom": "0" }, "callback": (value, arr) => { V.player.bodyliquid.' + part + '[arr[0]] = value; Wikifier.wikifyEval("<<updatesidebarimg>>"); } }>>';
    }
    src += '</div>';
    return src;
  }

  function injectCheatWater() {
    // box 已存在即视为已注入，直接早退——observer（subtree）监听下 refreshCheatWater 的
    // 清空重渲染本身是子树变化，会再触发自己形成无限循环
    if (document.getElementById('bn-water-group')) return;
    const anchor = document.getElementById('cheatLiquids-semen');
    if (!anchor) return;
    const grid = anchor.closest('.settingsGrid');
    if (!grid) return;
    const box = document.createElement('div');
    box.id = 'bn-water-group';
    grid.appendChild(box);
    refreshCheatWater(box);
  }

  function refreshCheatWater(box) {
    box = box || document.getElementById('bn-water-group');
    if (!box) return;
    while (box.firstChild) box.removeChild(box.firstChild);
    try {
      box.appendChild(SugarCube.Wikifier.wikifyEval(bnCheatWaterSource()));
    } catch (e) { console.error('[BasicNeeds] water cheat render failed:', e, '\nsource:', bnCheatWaterSource()); }
  }

  function waterAll(sign) {
    if (!V.player || !V.player.bodyliquid) return;
    for (const part of BN.bnWaterParts()) {
      const obj = V.player.bodyliquid[part];
      if (obj) obj.water = sign > 0 ? 5 : 0;
    }
    refreshCheatWater();
    try { SugarCube.Wikifier.wikifyEval('<<updatesidebarimg>>'); } catch (e) { /* 立绘刷新失败不影响数据 */ }
  }

  function bindWaterCheat() {
    document.addEventListener('click', e => {
      const el = e.target.closest ? e.target.closest('[data-bnwater]') : null;
      if (!el) return;
      waterAll(parseInt(el.getAttribute('data-bnwater'), 10) > 0 ? 1 : -1);
    }, true);
  }

  // 跨文件共享：挂到 window.BN
  Object.assign(BN, {
    bindWaterCheat, bnCheatWaterSource, injectCheatWater, lockCheatsBodySize, refreshCheatWater,
    waterAll,
  });
})();
