/* 基本需求 · 生理数值系统：饥饿/口渴/膀胱/肠道自然增长、settle 每小时结算、
 * 事件驱动检测、侧栏状态面板（桌面+移动端）——身体框架见 Ban-body.js */
(function () {
  'use strict';
  const BN = (window.BN = window.BN || {});

  function accident() {
    const bn = V.BasicNeeds;
    bn.bladder = 0;
    bn.bladderFullHrs = 0;
    // 失禁：下半身外层+内层衣物各加 100 湿度（原版系统，0-200 且随时间自然晾干，
    // 防水衣物内部自动忽略）；内裤湿透标记沿用原版逻辑
    try {
      statChange.wet('lower', 100);
      statChange.wet('under_lower', 100);
      V.pantiesSoaked = (V.underlowerwet || 0) >= 100;
    } catch (e) { /* 湿度系统异常不影响主惩罚 */ }
    V.stress = Math.min(V.stressmax || 10000, (V.stress || 0) + 300);
    V.trauma = Math.min(V.traumamax || 5000, (V.trauma || 0) + 100);
    // 失禁弄脏衣物/身体：原版 $hygiene 尺度（事件粒度 +500 同原版射精）；心情大扣
    V.hygiene = (V.hygiene || 0) + 500;
    bn.mood = BN.clamp(bn.mood + 1500);
  }

  function applyStrain(hours) {
    const bn = V.BasicNeeds;
    let tired = 0;
    let stress = 0;
    let pain = 0;
    // 饥渴高值：疲惫（睡一觉可恢复）+ 焦虑压力（慢性折磨，量级小于膀胱失禁这类急性事件）
    // v0.2.5 调低：疲惫 ×8→×2、压力 ×2→×1（×8 时满值疲惫 240/h 几小时打满 2000 上限，用户报"太多"；
    // 压力同批再减半——满值 30/h，惩罚存在但不喧宾夺主）
    if (bn.hunger >= 7000) {
      tired += ((bn.hunger - 7000) / 100) * 2 * hours;
      stress += ((bn.hunger - 7000) / 100) * 1 * hours;
    }
    if (bn.thirst >= 7000) {
      tired += ((bn.thirst - 7000) / 100) * 2 * hours;
      stress += ((bn.thirst - 7000) / 100) * 1 * hours;
    }
    // 小便高值：憋得心慌（满了 1 小时后会失禁，所以高值先加压力）
    if (bn.bladder >= 8000) stress += ((bn.bladder - 8000) / 100) * 15 * hours;
    // 大便没有失禁：满值后持续胀痛，压力与疼痛缓慢累计，直到解手
    if (bn.bowels >= BN.MAX) {
      stress += 150 * hours;
      pain += 50 * hours;
    }
    // 身上发臭（原版 $hygiene 档位：1200 smelly / 2000 filthy）持续加压
    if ((V.hygiene || 0) >= 2000) stress += 150 * hours;
    else if ((V.hygiene || 0) >= 1200) stress += 80 * hours;
    // 心情影响压力：低落时焦虑丛生，愉快时压力自然消散（负值净减也走同一条结算）
    if (bn.mood > 7500) stress += 50 * hours;
    else if (bn.mood <= 2500) stress -= 25 * hours;
    if (tired > 0) V.tiredness = Math.min(2000, (V.tiredness || 0) + tired);
    V.stress = Math.max(0, Math.min(V.stressmax || 10000, (V.stress || 0) + stress));
    if (pain > 0) V.pain = Math.min(V.painmax || 200, (V.pain || 0) + pain);
  }

  // 上次 tick 看到的游戏时间（内存变量，读档不会改变它）：
  // 游戏时间只增不减，一旦"倒流"（读档/历史回溯/改日期）即知发生了状态替换
  let lastSeenNow = null;

  function settle() {
    const bn = V.BasicNeeds;
    const now = V.timeStamp;
    // 时间线校验：标题画面的 timeStamp 是负值（天气模块默认日期 2022-8-10 相对开场起点的偏移），
    // 新游戏把它归 0——若把负值记为结算起点会一次灌入数百小时。负值不结算也不记起点
    if (typeof now !== 'number' || !(now >= 0)) return false;
    // 会话首次结算：lastTs 可能来自读档、session 恢复或旧版残留（起点落后量未知，
    // 且玩家第一次换用新版时 localStorage 没有历史记录可查）——一律对齐起点不补结算，
    // 数值保持存档恢复值，从当前时刻重新起算。这也是跨重启读档灌满的根防线
    if (lastSeenNow === null) {
      bn.lastTs = now;
      lastSeenNow = now;
      updatePanel();
      return false;
    }
    // 读档防线（会话内）：游戏时间倒流 = 状态被存档替换（:onLoad 在 DOL 定制存读档流程里不触发，
    // 只能靠这里兜底）——数值保持存档恢复的值，结算起点重置为当前时刻，从 0 重新累计
    if (now < lastSeenNow) {
      bn.lastTs = now;
      lastSeenNow = now;
      updatePanel();
      return false;
    }
    lastSeenNow = now;
    if (bn.lastTs === null || bn.lastTs === undefined || bn.lastTs > now) {
      bn.lastTs = now;
      updatePanel();
      return false;
    }
    let hours = (now - bn.lastTs) / 3600;
    bn.lastTs = now;
    if (!(hours > 0)) {
      updatePanel();
      return false;
    }
    if (hours > 24 * 7) hours = 24 * 7; // 防御：超长时间跳跃（作弊改日期等）最多按一周计

    // 饥饿值由消化系统驱动（digestSettle→digestHunger），不再随时间自然增长
    bn.thirst = BN.clamp(bn.thirst + BN.RATES.thirst * BN.tempMult(BN.THIRST_TEMP_TIERS) * hours);
    // 自然变脏：原版 $hygiene 无上限（事件 +500 累积、洗澡清零），mod 按时长线性增长；
    // 雨天未撑伞淋雨脏得快 ×2（用户 257f91 v0.2.16，v0.2.14 初版 ×3）——撑伞判定与原版一致：
    // 手持槽物品 type 含 rainproof
    let rainMult = 1;
    try {
      if (Weather.precipitation === 'rain' && !(V.worn?.handheld?.type || []).includes('rainproof')) rainMult = 2;
    } catch (e) { /* Weather/worn 异常时按无雨处理 */ }
    V.hygiene = (V.hygiene || 0) + BN.RATES.hygiene * rainMult * hours;

    // 睡觉不允许失禁（用户要求）：v0.2.6 改用显式睡眠标志——:passagestart(Sleep) 置位、
    // 渲染完成结算后清位。原因：结算主力在 :passageinit（presave），该事件触发时 V.passage
    // 还是旧值（实测 Sleep→Orphanage 导航时 V.passage/State.passage 均为 'Sleep'），
    // 旧版 /sleep/i.test(V.passage) 会把"睡醒后赖在 Sleep 页推时间"也误判成睡觉（豁免漏失禁）；
    // hours>=3 兜底保留（覆盖 Bed 等不含 sleep 名的昏迷/跳时场景）
    const sleeping = bn.sleepingNow === true || hours >= 3;
    // 心情不随时间流逝变化（用户 257f91 v0.2.14）：睡觉恢复、饿渴脏持续变糟均已删除，
    // 心情只由事件驱动——遭遇战结束变糟、洗澡/吃饭变好
    const bladderNew = bn.bladder + BN.RATES.bladder * BN.tempMult(BN.BLADDER_TEMP_TIERS) * hours;
    if (bladderNew >= BN.MAX) {
      bn.bladder = BN.MAX;
      if (!sleeping) {
        bn.bladderFullHrs += hours;
        if (bn.bladderFullHrs >= 1) accident('bladder');
      }
    } else {
      bn.bladder = BN.clamp(bladderNew);
      bn.bladderFullHrs = 0;
    }

    // 大便没有失禁：数值由消化系统肛门粪便量驱动（digestSettle→digestBowels），满值后由 applyStrain 持续加压力/疼痛

    // v0.4.0 清洁系统：牙齿/头发随时间变脏、湿身与毛巾自然晾干、长期不洗头触发发型锁定
    bn.teeth = BN.clamp((bn.teeth || 0) + BN.TEETH_RATE * hours);
    bn.hairDirty = Math.min(10000, (bn.hairDirty || 0) + BN.HAIR_RATE * hours);
    if (!bn.hairLocked && bn.hairDirty >= BN.HAIR_LOCK_AT) BN.lockHair();
    const bnSponge = V.foodstuff.sponge;
    if (bnSponge && (bnSponge.wet || 0) > 0) bnSponge.wet = Math.max(0, bnSponge.wet - BN.TOWEL_DRY_RATE * hours);

    // 自然晾干蒸发（详见 BN.dryBodyWater）——先于雨淋执行：蒸发用结算前水位，雨淋增量
    // 不被同 tick 蒸发抵扣（"先蒸后雨"）
    BN.dryBodyWater(hours, bn);
    // 雨天淋湿身体
    if (BN.bnRainSoak()) BN.rainWetBodyWater(hours, bn);
    else if (bn.waterRainFrac) bn.waterRainFrac = {};
    // 身上有水穿衣浸湿衣物（用户 257f91：水位档位映射衣物湿度保底）——放在最后，
    // 用雨淋/蒸发后的当刻水位蹭衣（雨淋透 1h 即 water 5 → 衣湿 150"drenched"档）
    BN.wetClothesFromBody(bn);

    // 脏污极值一次性（用户 257f91：最高"污秽不堪"压力固定 +1000、心情下降；最低"清爽干净"反之——
    // 不是每小时叠加，进入极值档只触发一次，离开后再次进入才再触发）
    const hygHi = (V.hygiene || 0) >= 2000;
    const hygLo = (V.hygiene || 0) <= 0;
    if (hygHi && bn.hygExtreme !== 1) {
      bn.hygExtreme = 1;
      V.stress = Math.min(V.stressmax || 10000, (V.stress || 0) + 1000);
      bn.mood = BN.clamp(bn.mood + 800);
    } else if (hygLo && bn.hygExtreme !== -1) {
      bn.hygExtreme = -1;
      V.stress = Math.max(0, (V.stress || 0) - 1000);
      bn.mood = BN.clamp(bn.mood - 800);
    } else if (!hygHi && !hygLo && bn.hygExtreme !== 0) {
      bn.hygExtreme = 0;
    }

    // 心情极值一次性（用户 257f91：最差档压力固定 +一半、最好档固定 -1/3，同样一次性非每小时）
    const moodLo = bn.mood >= 8000;
    const moodHi = bn.mood <= 1000;
    if (moodLo && bn.moodExtreme !== 1) {
      bn.moodExtreme = 1;
      V.stress = Math.min(V.stressmax || 10000, (V.stress || 0) + Math.round((V.stress || 0) / 2));
    } else if (moodHi && bn.moodExtreme !== -1) {
      bn.moodExtreme = -1;
      V.stress = Math.max(0, (V.stress || 0) - Math.round((V.stress || 0) / 3));
    } else if (!moodLo && !moodHi && bn.moodExtreme !== 0) {
      bn.moodExtreme = 0;
    }

    if (BN.digestSettle) BN.digestSettle(hours);
    applyStrain(hours);
    updatePanel();
    return true;
  }

  function tick() {
    BN.ensureVars();
    settle();
    bnDetectEvents();
    BN.bnHairGuard();
  }

  // ===== 事件驱动检测（v0.2.14，用户 257f91；v0.2.16 心情战斗联动按压力 1.5:1）=====
  // 心情不随时间流逝变化，改由事件驱动：遭遇战中被强迫（压力上涨）→ 心情按 1.5:1 变糟；
  // 脏污度除自然增长外，被射精（外观液体值上升）、被涂鸦（V.skin writing 部位增加）→ 即时变脏
  // 外观液体部位 = 原版 setup.bodyliquid.outerbodyparts（每部位每液体 0-5 级）
  const BN_LIQUID_PARTS = ['neck', 'rightarm', 'leftarm', 'thigh', 'bottom', 'tummy', 'chest', 'face', 'hair', 'feet', 'vaginaoutside', 'penis'];
  function bnBodyLiquidTotal() {
    const slots = V.player && V.player.bodyliquid;
    if (!slots) return 0;
    let total = 0;
    for (const p of BN_LIQUID_PARTS) {
      const s = slots[p];
      if (s) total += (s.goo || 0) + (s.semen || 0) + (s.nectar || 0);
    }
    return total;
  }
  function bnWritingCount() {
    const skin = V.skin;
    if (!skin) return 0;
    let n = 0;
    for (const k in skin) if (skin[k] && skin[k].writing) n++;
    return n;
  }
  function bnDetectEvents() {
    const bn = V.BasicNeeds;
    // 遭遇战中被强迫：压力每涨 1 心情变糟 1.5（用户 257f91 v0.2.16，v0.2.15 初版 2）——
    // 逐动作即时累积，与原版压力同节奏（原版战斗每个强迫动作 <<stress 1>> 实涨 40 → 心情跌 60）；
    // 非战斗的压力上涨不联动；战斗结束后 lastStress 继续跟随，不重复惩罚
    const stressNow = V.stress || 0;
    if (V.combat === 1 && stressNow > (bn.lastStress || 0)) {
      bn.mood = BN.clamp(bn.mood + (stressNow - (bn.lastStress || 0)) * 1.5);
    }
    bn.lastStress = stressNow;
    // 外观液体上升（不管哪个部位，被射即沾）：每级 +100 脏污（对齐原版事件 $hygiene += 100 的量级）
    const liq = bnBodyLiquidTotal();
    if (liq > (bn.lastLiq || 0)) V.hygiene = (V.hygiene || 0) + (liq - bn.lastLiq) * 100;
    bn.lastLiq = liq;
    // 被涂鸦（画在身体上）：每个新部位 +150 脏污
    const wr = bnWritingCount();
    if (wr > (bn.lastWriting || 0)) V.hygiene = (V.hygiene || 0) + (wr - bn.lastWriting) * 150;
    bn.lastWriting = wr;
  }

  // Time.pass 后立即结算：导航结算要等下一次导航才发生，喝水/吃饭/解手推完时间马上算掉，
  // 否则面板"刚清 0、一回大厅就多出 200"——推的时长全被记到下一次导航头上（用户报过）
  window.bnSettleNow = function () {
    BN.ensureVars();
    settle();
  };
  // 模板内联调用的心情变动入口（<<run window.bnMoodBoost(n)>>）：统一 BN.clamp 与面板刷新
  window.bnMoodBoost = function (n) {
    const bn = BN.ensureVars();
    bn.mood = BN.clamp(bn.mood - (n || 0));
    updatePanel();
  };
  window.bnReliefNow = function () { BN.injectRelief(); };
  window.bnMealsNow = function () { BN.injectMeals(); };

  const BAR_LABELS = { hunger: '饥饿', thirst: '口渴', bladder: '小便', bowels: '大便' };

  // 分档描述与颜色（颜色类复用游戏自带 CSS，视觉与原版状态条一致）
  const CAPTIONS = {
    hunger: [
      [0, 'green', '你吃得饱饱的。'],
      [100, 'teal', '你有一点饿。'],
      [2000, 'lblue', '你的肚子咕咕叫。'],
      [4000, 'blue', '你饿得发慌。'],
      [6000, 'purple', '你饿得头晕眼花。'],
      [8000, 'pink', '你饿得前胸贴后背。'],
      [10000, 'red', '你饿得快要晕过去了。']
    ],
    thirst: [
      [0, 'green', '你一点也不渴。'],
      [100, 'teal', '你有点口干。'],
      [2000, 'lblue', '你口渴难耐。'],
      [4000, 'blue', '你非常口渴。'],
      [6000, 'purple', '你的喉咙干得发疼。'],
      [8000, 'pink', '你渴得头昏脑涨。'],
      [10000, 'red', '你渴得快要晕过去了。']
    ],
    bladder: [
      [0, 'green', '你感觉很轻松。'],
      [100, 'teal', '你有点想上厕所。'],
      [2000, 'lblue', '你的膀胱有些胀。'],
      [4000, 'blue', '你需要去趟厕所。'],
      [6000, 'purple', '你憋得很辛苦。'],
      [8000, 'pink', '你快要憋不住了！'],
      [10000, 'red', '你的膀胱已经涨到极限，再也憋不住了！']
    ],
    bowels: [
      [0, 'green', '你感觉很轻松。'],
      [100, 'teal', '你有一点便意。'],
      [2000, 'lblue', '你的肚子有些坠胀。'],
      [4000, 'blue', '你需要去趟厕所。'],
      [6000, 'purple', '你憋得很辛苦。'],
      [8000, 'pink', '你快要憋不住了！'],
      [10000, 'red', '你的肠道已经涨到极限，再也憋不住了！']
    ]
  };

  function describe(key, v) {
    const rows = CAPTIONS[key];
    let out = rows[0];
    for (const r of rows) if (v >= r[0]) out = r;
    return out;
  }

  function barClass(v) {
    if (v >= BN.MAX) return 'redbar';
    if (v >= BN.MAX * 0.8) return 'pinkbar';
    if (v >= BN.MAX * 0.6) return 'purplebar';
    if (v >= BN.MAX * 0.4) return 'bluebar';
    if (v >= BN.MAX * 0.2) return 'lbluebar';
    if (v >= 100) return 'tealbar';
    return 'greenbar';
  }

  // 脏污走原版 $hygiene 尺度与档位（hygiene widget 文案的中文化，颜色类与原版一致）
  // 注意：describeList 是"v >= 阈值一路命中取最后"的升序表语义，表必须从低到高排
  // （v0.2.12 曾按降序排导致任何脏污值都命中最后一行、文案永远"清爽干净"——用户 257f91 报）
  const HYGIENE_CAPTIONS = [
    [0, 'green', '你清爽干净。'],
    [400, 'lblue', '你还算整洁。'],
    [800, 'blue', '你有点乱了。'],
    [1200, 'purple', '你身上散发出异味。'],
    [1600, 'pink', '你脏兮兮的，急需清洗。'],
    [2000, 'red', '你污秽不堪，浑身发臭。']
  ];
  const MOOD_CAPTIONS = [
    [0, 'green', '你心情愉悦，干劲十足。'],
    [1000, 'teal', '你心情很好。'],
    [2000, 'lblue', '你心情平静。'],
    [4000, 'purple', '你有些烦躁。'],
    [6000, 'pink', '你闷闷不乐。'],
    [8000, 'red', '你心情低落，对什么都提不起劲。']
  ];
  const TEETH_CAPTIONS = [
    [0, 'green', '牙齿洁白，口气清新。'],
    [1500, 'lblue', '牙齿还算干净。'],
    [3000, 'blue', '牙齿有点发黄。'],
    [4500, 'purple', '口气变得有点重。'],
    [6000, 'pink', '口臭明显，牙齿发黄。'],
    [8000, 'red', '满口牙菌斑，口臭熏天。']
  ];
  const HAIR_CAPTIONS = [
    [0, 'green', '秀发柔顺清爽。'],
    [1500, 'lblue', '头发还算干净。'],
    [3000, 'blue', '头发有点油了。'],
    [4500, 'purple', '头发油腻打绺。'],
    [6000, 'pink', '头发散发异味，急需洗头。'],
    [8000, 'red', '头发脏得结块，又油又臭。']
  ];
  function describeList(rows, v) {
    let out = rows[0];
    for (const r of rows) if (v >= r[0]) out = r;
    return out;
  }
  function hygBarClass(v) {
    if (v >= 2000) return 'redbar';
    if (v >= 1600) return 'pinkbar';
    if (v >= 1200) return 'purplebar';
    if (v >= 800) return 'bluebar';
    if (v >= 400) return 'lbluebar';
    return 'greenbar';
  }
  // 心情 0=最佳、10000=最差：色带与坏状态统一（低=绿、高=红），条宽直接用 mood/100
  function moodBarClass(v) {
    if (v >= 8000) return 'redbar';
    if (v >= 6000) return 'pinkbar';
    if (v >= 4000) return 'purplebar';
    if (v >= 2000) return 'bluebar';
    if (v >= 1000) return 'lbluebar';
    return 'greenbar';
  }

  // 面板以纯 HTML 返回，经 maplebirch 函数注入渲染（不依赖 twee 宏注册）；
  // 每次侧边栏渲染时按当前数值重新生成，结构与原版状态条一致（文字行 + meter 细条）
  function panelHtml() {
    const bn = V.BasicNeeds;
    if (!bn) return '';
    let html = '<div id="bn-panel">';
    const BN_PANEL_KEYS = ['hunger', 'thirst', 'bladder', 'bowels'];
    for (const key of BN_PANEL_KEYS) {
      const v = BN.clamp(bn[key]);
      const [min, cls, text] = describe(key, v);
      html +=
        '<div class="bn-line" title="' + BAR_LABELS[key] + ': ' + Math.round(v) + '">' +
        '<div class="bn-text">' + BAR_LABELS[key] + '：<span class="' + cls + '">' + text + '</span></div>' +
        '<div class="meter"><div class="' + barClass(v) + '" style="width:' + Math.floor(v / 100) + '%"></div></div>' +
        '</div>';
    }
    // 脏污（原版 $hygiene）与心情（mod 新数值）：两行追加在基础四行后
    const hyg = Math.max(0, V.hygiene || 0);
    const [, hygCls, hygText] = describeList(HYGIENE_CAPTIONS, hyg);
    html +=
      '<div class="bn-line" title="脏污度: ' + Math.round(hyg) + '">' +
      '<div class="bn-text">脏污度：<span class="' + hygCls + '">' + hygText + '</span></div>' +
      '<div class="meter"><div class="' + hygBarClass(hyg) + '" style="width:' + Math.min(100, Math.floor(hyg / 20)) + '%"></div></div>' +
      '</div>';
    const mood = BN.clamp(bn.mood === undefined ? BN.MOOD_DEFAULT : bn.mood);
    const [, moodCls, moodText] = describeList(MOOD_CAPTIONS, mood);
    html +=
      '<div class="bn-line" title="心情: ' + Math.round(mood) + '">' +
      '<div class="bn-text">心情：<span class="' + moodCls + '">' + moodText + '</span></div>' +
      '<div class="meter"><div class="' + moodBarClass(mood) + '" style="width:' + Math.floor(mood / 100) + '%"></div></div>' +
      '</div>';
    // 牙齿/头发（v0.4.0）：清洁系统新数值；头发锁定时文案替换为锁定提示
    const teeth = BN.clamp(bn.teeth || 0);
    const [, tCls, tText] = describeList(TEETH_CAPTIONS, teeth);
    html +=
      '<div class="bn-line" title="牙齿: ' + Math.round(teeth) + '">' +
      '<div class="bn-text">牙齿：<span class="' + tCls + '">' + tText + '</span></div>' +
      '<div class="meter"><div class="' + barClass(teeth) + '" style="width:' + Math.floor(teeth / 100) + '%"></div></div>' +
      '</div>';
    const hair = Math.min(10000, bn.hairDirty || 0);
    const [, hCls, hText] = bn.hairLocked
      ? [0, 'red', '头发脏得打绺结块。']
      : describeList(HAIR_CAPTIONS, hair);
    html +=
      '<div class="bn-line" title="头发: ' + Math.round(hair) + '">' +
      '<div class="bn-text">头发：<span class="' + hCls + '">' + hText + '</span></div>' +
      '<div class="meter"><div class="' + barClass(hair) + '" style="width:' + Math.floor(hair / 100) + '%"></div></div>' +
      '</div>';
    return html + '</div>';
  }

  // 面板内容在侧边栏每次渲染时由 panelHtml() 按当前数值重新生成；
  function updatePanel() {
    if (!V.BasicNeeds) return;
    const $panel = $('#bn-panel');
    if (!$panel.length) return;
    $panel.replaceWith(panelHtml());
  }

  // 作弊菜单液体区条目：小便 + 大便，均用游戏原生 <<numberStepper>> 宏渲染（与泌乳
  // "乳量/母乳容量"完全同款，样式由游戏 CSS 保证）。前置 gold 标题行（与"液体:/泌乳:"行同款）。
  // percentage 是未取整浮点（原版默认显示走 Math.round，自定义 valueFormat 要自己取整）。
  function bladderCheatHtml() {
    const bn = V.BasicNeeds;
    if (!bn) return null;
    try {
      const ml = Math.round(BN.clamp(bn.bladder) / BN.MAX * BN.BLADDER_ML);
      const urine = Wikifier.wikifyEval(
        '<<numberStepper "膀胱" ' + ml + ' { ' +
        'min: 0, max: ' + BN.BLADDER_ML + ', step: 10, percentage: false, ' +
        'valueFormat: (value, percentage) => Math.round(percentage) + "%(" + Math.round(value) + "ml)", ' +
        'callback: (value) => { V.BasicNeeds.bladder = Math.round(value / ' + BN.BLADDER_ML + ' * 10000); } ' +
        '}>>'
      );
      const bowel = Wikifier.wikifyEval(
        '<<numberStepper "大便" ' + Math.round(BN.clamp(bn.bowels)) + ' { ' +
        'min: 0, max: ' + BN.MAX + ', step: 100, percentage: true, ' +
        'callback: (value) => { V.BasicNeeds.bowels = Math.round(value); } ' +
        '}>>'
      );
      return $('<div id="bn-cheat"></div>')
        .append('<br><span class="gold">小便:</span><br><br>').append(urine)
        .append('<br><span class="gold">大便:</span><br><br>').append(bowel)[0];
    } catch (e) {
      console.warn('[BasicNeeds] bladder cheat render failed:', e);
      return null;
    }
  }

  // 作弊界面不是独立 passage：它是 overlay + <<replace>> 切 tab，全程不触发
  // :passageend，框架 zone 注入点也不在"液体"框内。改用 DOM 监听同步：
  // 液体区（#fluids 所在的 settingsToggleItem）出现且条目缺失就在框内末尾插入
  //（泌乳条目下方），条目在别处就挪进去；tab 切换销毁后下帧自动重建
  function syncBladderCheat() {
    const $box = $('#fluids').closest('.settingsToggleItem');
    if (!$box.length) return;
    const $c = $('#bn-cheat');
    if (!$c.length) {
      const el = bladderCheatHtml();
      if (el) $box.append(el);
    } else if (!$box.has($c).length) {
      $c.appendTo($box);
    }
  }

  // 作弊菜单"状态"区条目：饥饿/口渴，用原生 numberStepper（与原版状态条目同款：
  // percentage 显示百分比、reverse 让满值显红）。插到 #cheatstate 列表末尾

  function statsCheatHtml() {
    const bn = V.BasicNeeds;
    if (!bn) return null;
    try {
      const mk = (title, key) => Wikifier.wikifyEval(
        '<<numberStepper "' + title + '" ' + Math.round(BN.clamp(bn[key])) + ' { ' +
        'callback: value => { V.BasicNeeds.' + key + ' = value; }, ' +
        'max: 10000, reverse: true }>>'
      );
      // 脏污用原版 $hygiene 尺度（0-2000+ 档位）；心情 0-10000
      const mkHyg = () => Wikifier.wikifyEval(
        '<<numberStepper "脏污度" ' + Math.round(Math.max(0, V.hygiene || 0)) + ' { ' +
        'callback: value => { V.hygiene = Math.max(0, value); }, ' +
        'max: 3000, reverse: true }>>'
      );
      const mkMood = () => Wikifier.wikifyEval(
        '<<numberStepper "心情" ' + Math.round(BN.clamp(bn.mood === undefined ? BN.MOOD_DEFAULT : bn.mood)) + ' { ' +
        'callback: value => { V.BasicNeeds.mood = value; }, ' +
        'max: 10000, reverse: true }>>'
      );
      return $('<div id="bn-cheat-stats"></div>')
        .append(mk('饥饿', 'hunger')).append(mk('口渴', 'thirst'))
        .append(mkHyg()).append(mkMood())
        .append(mk('牙齿', 'teeth')).append(mk('头发', 'hairDirty'))[0];
    } catch (e) {
      console.warn('[BasicNeeds] stats cheat render failed:', e);
      return null;
    }
  }

  function syncStatsCheat() {
    const $box = $('#cheatstate');
    if (!$box.length) return;
    const $c = $('#bn-cheat-stats');
    if (!$c.length) {
      const el = statsCheatHtml();
      if (el) $box.append(el);
    } else if (!$box.has($c).length) {
      $c.appendTo($box);
    }
  }

  // 额外统计 overlay 的"状态"折叠区（#spoilerWarningConfirmed 第一个 .foldoutBody）
  // 追加四行数值，格式与原版行一致（"标签: 数值"纯文本、Math.trunc 取整）。
  // overlay 每次打开都重新渲染，observer 驱动注入、防重标记避免重复追加
  function syncStatsOverlay() {
    const $conf = $('#spoilerWarningConfirmed');
    if (!$conf.length) return;
    const $body = $conf.find('.foldoutBody').first();
    if (!$body.length) return;
    if ($('#bn-stat-overlay').length) return;
    const bn = BN.ensureVars();
    const rows = [['饥饿', bn.hunger], ['口渴', bn.thirst], ['小便', bn.bladder], ['大便', bn.bowels],
      ['脏污度', Math.max(0, V.hygiene || 0)], ['心情', bn.mood === undefined ? BN.MOOD_DEFAULT : bn.mood]]
      .map(([label, v]) => label + ': ' + Math.trunc(BN.clamp(v))).join('<br>');
    $body.append($('<span id="bn-stat-overlay"></span>').append(rows));
  }

  function watchBladderCheat() {
    let scheduled = false;
    new MutationObserver(() => {
      if (scheduled) return;
      scheduled = true;
      requestAnimationFrame(() => { scheduled = false; syncBladderCheat(); syncStatsCheat(); syncStatsOverlay(); bindStateLinks(); BN.annotateFoodLinks(); BN.annotateShowerLinks(); BN.syncHeightWeightCreate(); BN.syncHeightWeightStats(); });
    }).observe(document.body, { childList: true, subtree: true });
  }

  // 原版"刷新/损坏"只重置 pain/tiredness 等状态；追加 handler 让饥饿/口渴/脏污度/心情/
  // 牙齿/头发 一并处理（用户 257f91 v0.2.17 + 牙齿头发，明确排除小便/大便）：刷新=清零，
  // 损坏=拉满——心情 0=最佳（v0.2.12 语义反转），刷新=0 恰是"心情愉悦"、损坏=满即"心情低落"；
  // 脏污损坏拉到 3000 与作弊 stepper 上限一致。SugarCube 先执行原版 handler（含 replace
  // #cheatstate 销毁注入块），我们后设值，observer 下帧按新值重建
  function bindStateLinks() {
    const $box = $('#cheatstate').closest('.settingsToggleItem');
    if (!$box.length) return;
    $box.find('a').each(function () {
      const t = $(this).text();
      if (t !== '刷新' && t !== '损坏' && t !== 'Refresh' && t !== 'Ruin') return;
      if (this.dataset.bnStateBound) return;
      this.dataset.bnStateBound = '1';
      $(this).on('click', function () {
        const bn = BN.ensureVars();
        const ruin = (t === '损坏' || t === 'Ruin');
        bn.hunger = ruin ? BN.MAX : 0;
        bn.thirst = ruin ? BN.MAX : 0;
        V.hygiene = ruin ? 3000 : 0;
        bn.mood = ruin ? BN.MAX : 0;
        bn.teeth = ruin ? BN.MAX : 0;
        bn.hairDirty = ruin ? BN.MAX : 0;
      });
    });
  }

  // 厕所/浴室场景注入"解手"：主动排空小便（1 分钟）与大便（5 分钟），
  // 耗时经 Time.pass 推进、场景重载后由 :passageend 的 tick 自然结算
  const RELIEF_SCENES = [
    'Bathroom', 'Men\'s Toilets', 'Women\'s Toilets',
    'School Boy\'s Toilets', 'School Girl\'s Toilets',
    'Spa', 'Strip Club', 'Brothel', 'Farm Cottage', 'Prison Shower'
  ];

  // —— 三餐协议（用户指定：贝利办公室签约，孤儿院供三餐但收费）——
  // plan: 0 未签 / 1 只付自己（早£4 午晚各£6）/ 2 资助全院（早£10 午晚各£20，签约后不可改）
  // 贝利只在早 7-9 点在办公室（原版设定）；三餐在大厅吃，每餐每日一次、按时段供应
  const MEAL_SLOTS = [
    { key: 'breakfast', label: '早餐', from: 5, to: 9, prices: [400, 1000], effect: { hunger: 5000, thirst: 8000 } },
    { key: 'lunch', label: '午餐', from: 10, to: 15, prices: [600, 2000], effect: { hunger: 7000, thirst: 8000 } },
    { key: 'dinner', label: '晚餐', from: 16, to: 22, prices: [600, 2000], effect: { hunger: 6000, thirst: 8000 } }
  ];
  const MEAL_MINUTES = 20;

  function mobileColor(v) {
    if (!(v > 0)) return 'green';
    const p = Math.floor((BN.clamp(v) / BN.MAX) * 10);
    if (p >= 10) return 'red';
    if (p >= 8) return 'pink';
    if (p >= 6) return 'purple';
    if (p >= 4) return 'blue';
    if (p >= 2) return 'lblue';
    return 'teal';
  }

  // 脏污用原版 $hygiene 档位（0-2000+）；心情是好状态，色带按"坏度"取反复用十分位映射
  function mobileColorHyg(v) {
    if (v >= 2000) return 'red';
    if (v >= 1600) return 'pink';
    if (v >= 1200) return 'purple';
    if (v >= 800) return 'blue';
    if (v >= 400) return 'lblue';
    return 'green';
  }

  function injectMobileStats() {
    const $box = $('#mobileStats');
    if (!$box.length) return;
    $box.find('.stat.bn-mobile').remove();
    const mode = V.options && V.options.sidebarStats;
    if (mode === 'disabled') return;
    const showAll = mode === 'all';
    const bn = BN.ensureVars();
    const mood = BN.clamp(bn.mood === undefined ? BN.MOOD_DEFAULT : bn.mood);
    const items = [['饥', '饥饿', bn.hunger, 'v'], ['渴', '口渴', bn.thirst, 'v'], ['尿', '小便', bn.bladder, 'v'], ['便', '大便', bn.bowels, 'v'],
      ['牙', '牙齿', bn.teeth, 'v'], ['发', '头发', bn.hairDirty, 'v'],
      ['脏', '脏污度', Math.max(0, V.hygiene || 0), 'h'], ['心', '心情', mood, 'm']]
      .filter(([, , v, kind]) => showAll || (kind === 'v' && v > BN.MAX / 2) || (kind === 'h' && v >= 1200) || (kind === 'm' && mood > 5000))
      .map(([ch, label, v, kind]) => {
        const cls = kind === 'h' ? mobileColorHyg(v) : mobileColor(v);
        return '<div class="stat bn-mobile ' + cls + '"><mouse class="tooltip-centertop">' + ch +
          '<span>' + label + ': ' + Math.trunc(kind === 'v' ? BN.clamp(v) : v) + '</span></mouse></div>';
      }).join('');
    if (!items) return;
    // 时间列被设在底部时插在它前面，保持"状态在上、时间在下"的原版分组
    const $time = $box.find('.stat.time').last();
    if ($time.length && $time.next().length === 0) $time.before(items);
    else $box.append(items);
  }


  // 吃一个库存条目：推 5 分钟并立即结算（不然时长记到下一次导航，刚清 0 回大厅就涨 200——用户报过）、
  // 扣数量与数值、刷新注入区与侧边栏
  // 跨文件共享：挂到 window.BN
  Object.assign(BN, {
    accident, applyStrain, barClass, bindStateLinks,
    bladderCheatHtml, bnBodyLiquidTotal,
    bnDetectEvents, bnWritingCount, describe,
    describeList, hygBarClass, injectMobileStats, mobileColor, mobileColorHyg,
    moodBarClass, panelHtml, settle, statsCheatHtml, syncBladderCheat,
    syncStatsCheat, syncStatsOverlay, tick,
    updatePanel, watchBladderCheat, BAR_LABELS,
    BN_LIQUID_PARTS, CAPTIONS, HAIR_CAPTIONS, HYGIENE_CAPTIONS, TEETH_CAPTIONS,
    MEAL_MINUTES, MEAL_SLOTS, MOOD_CAPTIONS, RELIEF_SCENES, TEETH_CAPTIONS,
    bnMealsNow: window.bnMealsNow, bnMoodBoost: window.bnMoodBoost, bnReliefNow: window.bnReliefNow, bnSettleNow: window.bnSettleNow,
  });
})();
