/* ========================================================================== */
/*                               NEEDMEET 遇欲                                */
/*                                 @隨風飄逸                                   */
/*                        本模组由大模型生成，由人工监制                        */
/* https://github.com/ANLINSTUDIO/Degrees-of-Lewdity-Traceability-ModSourceDisplay */
/*                    有任何议题或拉取请求欢迎前往Github讨论                    */
/*                更多模组查看 https://dol.alseece.top/release/                */
/* ========================================================================== */


// Traceability：按需檢視 Twee Passage、Widget 定義及修改來源。
(function () {
	'use strict';

	if (window.modSourceDisplayInstalled) return;
	window.modSourceDisplayInstalled = true;

	let VANILLA = 'Degrees of Lewdity';
	let ID = 'modSourceDisplay';
	let SOURCE_ID = 'modSourceView';
	let SOURCE_CODE_ID = 'modSourceCode';
	let SOURCE_EXIT_ID = 'modSourceExit';
	let PRESS_MS = 500;
	let sourceMap = null;
	let currentPassage = null;
	let viewing = false;
	let hiddenPassages = [];
	let pressTimer = null;

	// 段落名 -> 模组显示名。后加载的模组覆盖先加载的。
	function buildSourceMap() {
		let map = new Map();
		let manager = window.modSC2DataManager;
		if (!manager || typeof manager.getModLoader !== 'function') return map;

		let entries = manager.getModLoader().getModCacheArray() || [];
		for (let i = 0; i < entries.length; i++) {
			let info = entries[i] && entries[i].mod;
			if (!info) continue;
			let items = info.cache && info.cache.passageDataItems && info.cache.passageDataItems.map;
			if (!items) continue;
			let label = info.name;
			if (!label) continue;
			items.forEach(function (_item, passageName) {
				map.set(passageName, label);
			});
		}
		return map;
	}

	// 合并后（含所有模组改动）的段落 twee 源码。
	function getPassageSource(name) {
		let manager = window.modSC2DataManager;
		if (!name || !manager || typeof manager.getSC2DataInfoAfterPatch !== 'function') return null;
		let item = manager.getSC2DataInfoAfterPatch().passageDataItems.map.get(name);
		return item && typeof item.content === 'string' ? item.content : null;
	}

	function escapeHtml(text) {
		return text.replace(/[&<>]/g, function (c) {
			return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c];
		});
	}

	// 宏块内部：字符串 / 变量 / 数字 / 运算符
	const RE_INNER = /(\/\/[^\n]*)|("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')|(\$[\w.]+|_[\w.]+)|(\b\d+(?:\.\d+)?\b)|(\b(?:to|is|isnot|eq|neq|and|or|not|gte|lte|gt|lt|def|ndef|even|odd)\b)/g;
	// 外层：注释 / 宏块 / html 标签 / 链接 / 字符串 / 变量
	const RE_OUTER = /(\/\/[^\n]*|\/\*[\s\S]*?\*\/)|(<<(?:"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|[^"'])*?>>)|(<\/?[A-Za-z][\w-]*(?:\s+[^>]*?)?\/?>)|(\[\[[^\]]*?\]\])|("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')|(\$[\w.]+|_[\w.]+)/g;

	// VS Code Twee 风格高亮，单次外层正则避免嵌套破坏。输出 token 段，供逐行渲染。
	function segments(text) {
		let out = [];
		let last = 0;
		text.replace(RE_OUTER, function (m, comment, macro, tag, link, str, variable, offset) {
			if (offset > last) out.push({ text: text.slice(last, offset), cls: null });
			if (comment) out.push({ text: m, cls: 'c' });
			else if (macro) pushMacro(out, m);
			else if (tag) out.push({ text: m, cls: 't' });
			else if (link) out.push({ text: m, cls: 'l' });
			else if (str) out.push({ text: m, cls: 's' });
			else out.push({ text: m, cls: 'v' });
			last = offset + m.length;
			return m;
		});
		if (last < text.length) out.push({ text: text.slice(last), cls: null });
		return out;
	}

	function pushMacro(out, block) {
		let inner = block.slice(2, -2);
		let name = (/^\/?[\w-]*/.exec(inner) || [''])[0];
		let rest = inner.slice(name.length);
		out.push({ text: '<<', cls: 'md' });
		out.push({ text: name, cls: 'm' });
		let last = 0;
		rest.replace(RE_INNER, function (m, comment, str, variable, number, operator, offset) {
			if (offset > last) out.push({ text: rest.slice(last, offset), cls: null });
			out.push({ text: m, cls: comment ? 'c' : str ? 's' : variable ? 'v' : number ? 'n' : 'o' });
			last = offset + m.length;
			return m;
		});
		if (last < rest.length) out.push({ text: rest.slice(last), cls: null });
		out.push({ text: '>>', cls: 'md' });
	}

	function toLines(segs) {
		let lines = [[]];
		for (let i = 0; i < segs.length; i++) {
			let parts = segs[i].text.split('\n');
			for (let j = 0; j < parts.length; j++) {
				if (j) lines.push([]);
				if (parts[j]) lines[lines.length - 1].push({ text: parts[j], cls: segs[i].cls });
			}
		}
		return lines;
	}

	function lineHtml(cells) {
		let s = '';
		for (let i = 0; i < cells.length; i++) {
			s += cells[i].cls ? '<span class="' + cells[i].cls + '">' + escapeHtml(cells[i].text) + '</span>' : escapeHtml(cells[i].text);
		}
		return s;
	}

	// 从模组 zip 读取 replaceFile 内容（entry.zip 可能是 ModZipReader，也可能是裸 JSZip）。
	async function readModFile(entry, path) {
		if (typeof path !== 'string') return null;
		try {
			let reader = entry && entry.zip;
			let zip = (reader && reader.zip) || reader;
			if (!zip || typeof zip.file !== 'function') return null;
			let file = zip.file(path.replace(/^\.?\//, ''));
			return file ? await file.async('string') : null;
		} catch (e) {
			return null;
		}
	}

	// 本段落被哪些模组改写过：TweeReplacer 四种参数形态 + ReplacePatcher。
	async function collectPatches(name) {
		let out = [];
		let manager = window.modSC2DataManager;
		if (!manager || typeof manager.getModLoader !== 'function') return out;
		let entries = manager.getModLoader().getModCacheArray() || [];

		let records = [];
		let collect = function (info, entry, list, key) {
			if (!Array.isArray(list)) return;
			list.forEach(function (q) { if (q) records.push([info, entry, q, q[key]]); });
		};
		for (let i = 0; i < entries.length; i++) {
			let info = entries[i] && entries[i].mod;
			if (!info) continue;
			let addons = (info.bootJson && info.bootJson.addonPlugin) || [];
			addons.forEach(function (p) {
				let params = p && p.params;
				if (Array.isArray(params)) collect(info, entries[i], params, 'passage');
				else if (params) collect(info, entries[i], params.twee, 'passageName');
			});
			(info.replacePatcher || []).forEach(function (rp) {
				collect(info, entries[i], rp && rp.patchInfo && rp.patchInfo.twee, 'passageName');
			});
		}

		for (let i = 0; i < records.length; i++) {
			let info = records[i][0], entry = records[i][1], q = records[i][2];
			if (records[i][3] !== name) continue;
			let to = typeof q.to === 'string' ? q.to
				: typeof q.replace === 'string' ? q.replace
					: await readModFile(entry, q.replaceFile);
			if (typeof to !== 'string') continue;
			let from = typeof q.from === 'string' ? q.from
				: typeof q.findString === 'string' ? q.findString : null;
			if (from == null && typeof q.findRegex !== 'string') continue;
			out.push({ mod: info.name, from: from, to: to, regex: from == null ? q.findRegex : null, flag: q.regexFlag });
		}
		return out;
	}

	// 被补丁插入的行 -> 模组名。按「行号」定位，避免 <br> 这类通用行被整篇误标。
	function buildLineOwners(patches, source) {
		let owners = new Map();
		let lineOf = function (pos) {
			let n = 0;
			for (let i = 0; i < pos; i++) if (source[i] === '\n') n++;
			return n;
		};
		patches.forEach(function (patch) {
			let keep = new Set();
			if (patch.regex) {
				try {
					let flag = patch.flag || '';
					let re = new RegExp(patch.regex, flag.indexOf('g') < 0 ? flag + 'g' : flag);
					let m;
					while ((m = re.exec(source)) !== null) {
						m[0].split('\n').forEach(function (s) { keep.add(s.trim()); });
						if (m.index === re.lastIndex) re.lastIndex++;
					}
				} catch (e) { /* 正则无效则不做保留 */ }
			}
			else patch.from.split('\n').forEach(function (s) { keep.add(s.trim()); });

			// TweeReplacer 把 replace 原样写入源码，因此 to 能在合并结果里定位到唯一位置。
			let pos = source.indexOf(patch.to);
			if (pos < 0) return;
			let start = lineOf(pos);
			patch.to.split('\n').forEach(function (line, i) {
				let key = line.trim();
				if (key && !keep.has(key)) owners.set(start + i, patch.mod);
			});
		});
		return owners;
	}

	// 模组名 -> 特征色，同名同色。

	// 以合併後的 Passage 定義建立 Widget 索引；保留定義所在段落及原始碼行數。
	function buildWidgetIndex() {
		let result = new Map();
		let manager = window.modSC2DataManager;
		let data = manager && manager.getSC2DataInfoAfterPatch && manager.getSC2DataInfoAfterPatch();
		let map = data && data.passageDataItems && data.passageDataItems.map;
		if (!map) return result;
		map.forEach(function (item, passage) {
			let source = item && item.content;
			if (typeof source !== 'string') return;
			let re = /<<widget\s+(["'])([^"']+)\1[^>]*>>/gi;
			let match;
			while ((match = re.exec(source))) {
				let end = source.indexOf('<</widget>>', re.lastIndex);
				if (end < 0) continue;
				let line = source.slice(0, match.index).split('\n').length;
				result.set(match[2], { passage: passage, line: line,
					source: source.slice(match.index, end + 11) });
				re.lastIndex = end + 11;
			}
		});
		return result;
	}

	function hue(name) {
		let h = 0;
		for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) % 360;
		return h;
	}

	function getElement() {
		let el = document.getElementById(ID);
		if (el) return el;
		if (!document.body) return null;
		el = document.createElement('div');
		el.id = ID;
		el.title = '长按查看本段源码';
		el.addEventListener('pointerdown', pressStart);
		el.addEventListener('pointerup', pressEnd);
		el.addEventListener('pointercancel', pressEnd);
		el.addEventListener('contextmenu', function (e) { e.preventDefault(); });
		document.body.appendChild(el);
		return el;
	}

	// 紧贴 gameVersionDisplay 下方，随其高度变化自动跟随。
	function alignToVersion(el) {
		let version = document.getElementById('gameVersionDisplay');
		if (!version || !version.getBoundingClientRect().height) return;
		el.style.top = Math.ceil(version.getBoundingClientRect().bottom) + 1 + 'px';
	}

	function refresh() {
		if (!sourceMap) sourceMap = buildSourceMap();
		closeSourceView();
		currentPassage = window.State && State.passage;

		let el = getElement();
		if (!el) return;
		el.textContent = (currentPassage && sourceMap.get(currentPassage)) || VANILLA;
		alignToVersion(el);
	}

	function pressStart(event) {
		if (event.button) return;
		event.preventDefault();
		if (event.currentTarget.setPointerCapture && event.pointerId != null) {
			try { event.currentTarget.setPointerCapture(event.pointerId); } catch (e) { /* 忽略 */ }
		}
		pressTimer = setTimeout(function () {
			pressTimer = null;
			viewing ? closeSourceView() : openSourceView();
		}, PRESS_MS);
	}

	function pressEnd() {
		if (pressTimer) {
			clearTimeout(pressTimer);
			pressTimer = null;
		}
	}

	async function openSourceView() {
		let passage = currentPassage;
		if (viewing) return;
		let source = getPassageSource(passage);
		let passages = document.getElementById('passages');
		if (source == null || !passages) return;

		let patches = await collectPatches(passage);
		let owners = buildLineOwners(patches, source);
		console.log('[MSD] patches=' + patches.length + ' marks=' + owners.size);

		hiddenPassages = [];
		for (let i = 0; i < passages.children.length; i++) {
			let child = passages.children[i];
			if (!child.classList || !child.classList.contains('passage')) continue;
			if (child.style.display !== 'none') {
				hiddenPassages.push(child);
				child.style.display = 'none';
			}
		}

		let rawLines = source.split('\n');
		let htmlLines = toLines(segments(source));
		let html = '';
		for (let i = 0; i < rawLines.length; i++) {
			let mod = owners.get(i);
			let h = mod ? hue(mod) : 0;
			html += '<div class="ln"' + (mod ? ' style="background-color:hsla(' + h + ',70%,45%,0.22)"' : '') + '>'
				+ lineHtml(htmlLines[i] || []);
			if (mod && owners.get(i + 1) !== mod) html += '<span class="tag" style="background-color:hsla(' + h + ',70%,38%,0.9)">' + escapeHtml(mod) + '</span>';
			html += '</div>';
		}

		let view = document.createElement('div');
		view.id = SOURCE_ID;
		let code = document.createElement('div');
		code.id = SOURCE_CODE_ID;
		code.innerHTML = html;
		view.appendChild(code);
		passages.appendChild(view);
		// 只在點擊原始碼中的巨集名稱時，查詢對應 Widget 定義。
		installWidgetNavigation(view, code, passage, source);


		let exit = document.createElement('button');
		exit.id = SOURCE_EXIT_ID;
		exit.type = 'button';
		exit.textContent = '退出源码';
		exit.addEventListener('click', closeSourceView);
		passages.appendChild(exit);

		viewing = true;
	}


	// 只將巨集名稱變成可點擊目標；不在渲染時建立 Widget 索引。
	function linkMacroNames(root) {
		root.querySelectorAll('span.m').forEach(function (node) {
			const name = node.textContent.trim();
			if (!/^[A-Za-z][\w-]*$/.test(name) || name === 'widget') return;
			node.classList.add('msd-macro-link');
			node.setAttribute('data-msd-widget', name);
			node.setAttribute('role', 'button');
			node.setAttribute('tabindex', '0');
			node.title = '点击查找 Twee Widget：' + name;
		});
	}

	function renderLinkedSource(source, owners) {
		const lines = toLines(segments(source));
		let html = '';
		for (let i = 0; i < lines.length; i++) {
			const mod = owners && owners.get(i);
			const h = mod ? hue(mod) : 0;
			html += '<div class="ln"' + (mod ? ' style="background-color:hsla(' + h + ',70%,45%,0.22)"' : '') + '>' + lineHtml(lines[i]);
			if (mod && owners.get(i + 1) !== mod) html += '<span class="tag" style="background-color:hsla(' + h + ',70%,38%,0.9)">' + escapeHtml(mod) + '</span>';
			html += '</div>';
		}
		return html;
	}


	// 安全模式：不掃描任何 JavaScript 原始碼。

	function passageTargets(line) {
		const found = [];
		function add(start, end, target) {
			if (!target || !target.trim()) return;
			found.push({start, end, target: target.trim()});
		}
		// 連結標記：[[text->Passage]]、[[Passage<-text]]、[[text|Passage]]、[[Passage]]。
		const wiki = /\[\[([^\]\n]+)\]\]/g;
		let m;
		while ((m = wiki.exec(line))) {
			const body = m[1];
			let target, offset;
			if (body.includes('->')) { const i = body.indexOf('->'); target = body.slice(i + 2); offset = i + 2; }
			else if (body.includes('<-')) { const i = body.indexOf('<-'); target = body.slice(0, i); offset = 0; }
			else if (body.includes('|')) { const i = body.indexOf('|'); target = body.slice(i + 1); offset = i + 1; }
			else { target = body; offset = 0; }
			if (!/[`$<>]/.test(target)) add(m.index + 2 + offset, m.index + 2 + offset + target.length, target);
		}
		// SugarCube link/button 的第二個字串參數，goto/include/display 的第一個參數。
		const macros = /<<\s*(link|button|goto|include|display)\b([^>\n]*)>>/gi;
		while ((m = macros.exec(line))) {
			const name = m[1].toLowerCase(), args = m[2], base = m.index + m[0].indexOf(args);
			const strings = [...args.matchAll(/(["'])(?:\\.|(?!\1)[^\\])*?\1/g)];
			const idx = (name === 'link' || name === 'button') ? 1 : 0;
			if (strings[idx]) {
				const v = strings[idx], value = v[0].slice(1, -1);
				if (!/[`$]/.test(value)) add(base + v.index + 1, base + v.index + v[0].length - 1, value);
			}
		}
		// HTML data-passage：只處理字面量。
		const attr = /\bdata-passage\s*=\s*(["'])(.*?)\1/g;
		while ((m = attr.exec(line))) if (!/[`$]/.test(m[2])) add(m.index + m[0].indexOf(m[2]), m.index + m[0].indexOf(m[2]) + m[2].length, m[2]);
		return found.sort((a,b) => b.start - a.start).filter((x,i,arr) => !arr.slice(0,i).some(y => x.end > y.start && x.start < y.end));
	}
	function markPassageLinks(root) {
		root.querySelectorAll('.ln').forEach(line => {
			if (line.dataset.msdPassageReady) return;
			line.dataset.msdPassageReady = '1';
			const raw = line.textContent;
			const targets = passageTargets(raw);
			for (const hit of targets) {
				const walker = document.createTreeWalker(line, NodeFilter.SHOW_TEXT);
				let node, pos = 0, startNode = null, endNode = null, startOffset = 0, endOffset = 0;
				while ((node = walker.nextNode())) {
					const next = pos + node.textContent.length;
					if (!startNode && hit.start >= pos && hit.start < next) { startNode = node; startOffset = hit.start - pos; }
					if (startNode && hit.end > pos && hit.end <= next) { endNode = node; endOffset = hit.end - pos; break; }
					pos = next;
				}
				if (!startNode || !endNode) continue;
				try {
					const range = document.createRange();
					range.setStart(startNode, startOffset); range.setEnd(endNode, endOffset);
					const span = document.createElement('span');
					span.className = 'msd-passage-link'; span.dataset.msdPassage = hit.target;
					span.setAttribute('role', 'button'); span.tabIndex = 0;
					span.title = '查看 Passage 源码：' + hit.target;
					span.appendChild(range.extractContents()); range.insertNode(span);
				} catch (error) { console.debug('[MSD] Passage link skipped', error); }
			}
		});
	}

	function installWidgetNavigation(view, code, passage, source) {
		const history = [];
		let navigationBusy = false;
		let navigationEpoch = 0;
		let activeNotice = null;
		
		function clearNotice() {
			if (activeNotice) activeNotice.remove();
			activeNotice = null;
		}
		function noticeAt(node, message) {
			clearNotice();
			if (!node || !node.isConnected) return;
			const bubble = document.createElement('span');
			bubble.className = 'msd-inline-notice';
			bubble.setAttribute('role', 'status');
			bubble.textContent = message;
			node.insertAdjacentElement('afterend', bubble);
			activeNotice = bubble;
		}

		const toolbar = document.createElement('div');
		toolbar.className = 'msd-nav-toolbar';
		const back = document.createElement('button');
		back.type = 'button';
		back.textContent = '← 返回上一层';
		back.disabled = true;
		const title = document.createElement('span');
		title.textContent = 'Passage：' + passage;
		const status = document.createElement('span');
		status.className = 'msd-nav-status';
		toolbar.append(back, title, status);
		// 非主畫面入口：只列出實際存在的特殊 Twee Passage，不碰 JS 或 Widget handler。
		const entryBox = document.createElement('div');
		entryBox.className = 'msd-entry-picker';
		const entrySelect = document.createElement('select');
		entrySelect.setAttribute('aria-label', '选择独立界面的 Twee 入口');
		const entryButton = document.createElement('button');
		entryButton.type = 'button';
		entryButton.textContent = '查看界面来源';
		const entryHint = document.createElement('span');
		entryHint.className = 'msd-entry-hint';
		entryHint.textContent = '只显示可取得原始码的 Twee 入口；不保证涵盖纯JS弹窗';
		entryBox.append(entrySelect, entryButton, entryHint);
		view.insertBefore(entryBox, code);
		const entryNames = [
			'StoryCaption', 'StoryMenu', 'StoryBanner', 'StorySubtitle',
			'StoryInterface', 'StoryHeader', 'StoryFooter',
			'PassageHeader', 'PassageFooter', 'StoryAuthor', 'StoryTitle',
			'StoryInit', 'StoryShare'
		];
		function refreshEntries() {
			entrySelect.replaceChildren();
			const names = [...new Set(entryNames)].filter(n => getPassageSource(n) != null);
			for (const name of names) {
				const option = document.createElement('option');
				option.value = name;
				option.textContent = name;
				entrySelect.appendChild(option);
			}
			entryButton.disabled = !names.length;
			if (!names.length) entryHint.textContent = '未找到已知的独立界面 Twee 入口';
		}
		refreshEntries();
		view.insertBefore(toolbar, code);
		linkMacroNames(code);
		markPassageLinks(code);
		function show(frame) {
			clearNotice();
			code.innerHTML = frame.html;
			linkMacroNames(code);
			markPassageLinks(code);
			title.textContent = frame.title;
			status.textContent = frame.status || '';
			back.disabled = history.length === 0;
			code.scrollTop = 0;
		}
		back.addEventListener('click', function () {
			if (navigationBusy) return;
			if (history.length) {
				const previous = history.pop();
				show(previous);
				code.scrollTop = previous.scrollTop || 0;
			}
		});
		async function follow(name, node) {
			if (navigationBusy) return;
			clearNotice();
			navigationBusy = true;
			const epoch = ++navigationEpoch;
			const previousStatus = status.textContent;
			status.textContent = '查询 ' + name + '…';
			try {
				// 按需索引；不在開啟檢視器時掃描。
				const index = buildWidgetIndex();
				const def = index.get(name);
				if (!def) {
					status.textContent = previousStatus;
					noticeAt(node, '找不到 Twee Widget 定义；可能不是由 Twee 定义的巨集。');
					return;
				}
				const patches = await collectPatches(def.passage);
				const full = getPassageSource(def.passage) || '';
				const owners = buildLineOwners(patches, full);
				const snippetOwners = new Map();
				for (let i = 0; i < def.source.split('\n').length; i++) {
					const owner = owners.get(def.line - 1 + i);
					if (owner) snippetOwners.set(i, owner);
				}
				if (!view.isConnected || epoch !== navigationEpoch) return;
				history.push({html: code.innerHTML, title: title.textContent, status: previousStatus, scrollTop: code.scrollTop});
				const origin = (sourceMap && sourceMap.get(def.passage)) || VANILLA;
				// 僅採用此 Widget 定義範圍內、原版行級標記實際命中的模組。
				// 同 Passage 其他 Widget 的補丁不得混入修改來源。
				const widgetModifiers = [...new Set([...snippetOwners.values()].filter(Boolean))];
				show({html: renderLinkedSource(def.source, snippetOwners), title: 'Widget：' + name + ' ｜ ' + def.passage + ':' + def.line,
					status: '来源：' + origin + (widgetModifiers.length ? ' ｜ Widget 修改行来源：' + widgetModifiers.join('、') : ' ｜ 无可辨识的 Widget 修改行')});
			} catch (error) {
				status.textContent = previousStatus;
				noticeAt(node, '查询失败：' + String(error));
				console.error('[MSD] Widget navigation failed', error);
			} finally {
				navigationBusy = false;
			}
		}
		async function followPassage(name, node) {
			if (navigationBusy) return;
			clearNotice(); navigationBusy = true;
			const previousStatus = status.textContent;
			status.textContent = '查询 Passage ' + name + '…';
			try {
				const full = getPassageSource(name);
				if (full == null) { status.textContent = previousStatus; noticeAt(node, '找不到 Passage：' + name); return; }
				const patches = await collectPatches(name);
				const owners = buildLineOwners(patches, full);
				if (!view.isConnected) return;
				history.push({html:code.innerHTML,title:title.textContent,status:previousStatus,scrollTop:code.scrollTop});
				if (!sourceMap) sourceMap = buildSourceMap();
				const origin = sourceMap.get(name) || VANILLA;
				show({html:renderLinkedSource(full, owners), title:'Passage：'+name,
					status:'来源：'+origin+' ｜ 修改行依原版补丁标记'});
			} catch(error) {
				status.textContent = previousStatus;
				noticeAt(node,'Passage 查询失败：'+String(error));
				console.error('[MSD] Passage lookup',error);
			} finally { navigationBusy = false; }
		}


		entryButton.addEventListener('click', () => { if (entrySelect.value) followPassage(entrySelect.value, entryButton); });

		code.addEventListener('click', function (event) {
			const passageNode = event.target.closest('[data-msd-passage]');
			if (passageNode && code.contains(passageNode)) { if (event.type === 'keydown') event.preventDefault(); followPassage(passageNode.dataset.msdPassage, passageNode); return; }
			const node = event.target.closest('[data-msd-widget]');
			if (node && code.contains(node)) follow(node.dataset.msdWidget, node);
		});
		code.addEventListener('keydown', function (event) {
			if (event.key !== 'Enter' && event.key !== ' ') return;
			const passageNode = event.target.closest('[data-msd-passage]');
			if (passageNode && code.contains(passageNode)) { if (event.type === 'keydown') event.preventDefault(); followPassage(passageNode.dataset.msdPassage, passageNode); return; }
			const node = event.target.closest('[data-msd-widget]');
			if (node && code.contains(node)) { event.preventDefault(); follow(node.dataset.msdWidget, node); }
		});
	}

	function closeSourceView() {
		let view = document.getElementById(SOURCE_ID);
		if (view) view.remove();
		let exit = document.getElementById(SOURCE_EXIT_ID);
		if (exit) exit.remove();
		for (let i = 0; i < hiddenPassages.length; i++) hiddenPassages[i].style.display = '';
		hiddenPassages = [];
		viewing = false;
	}

	jQuery(document).on(':passagedisplay', function () {
		requestAnimationFrame(refresh);
	});
})();
