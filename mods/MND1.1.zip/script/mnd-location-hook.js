(function () {
    'use strict';

    // Register the location/wardrobe patches during InjectEarlyLoad so
    // MapleBirch can apply them at its normal :addon:beforePatch stage.
    try {
        if (typeof maplebirch === 'undefined' || !maplebirch.tool || typeof maplebirch.tool.inject !== 'function') {
            console.error('[MND] MapleBirch tool.inject is unavailable during InjectEarlyLoad.');
            return;
        }

        maplebirch.tool.inject({
            locationPassage: {
                'Connudatus Street': [
                    {
                        // Connudatus Street only: insert immediately after the
                        // vanilla location-list heading. The heading is English
                        // before I18N or Chinese after I18N, so support both forms
                        // while remaining independent of the Strip Club and events.
                        srcmatch: /(?:Places of interest|可访问地点)\s*<br>/,
                        applyafter: '\n\t\t<<MNDConnudatusLink>>',
                        expected: 1
                    }
                ]
            },
            widgetPassage: {
                'Widgets Wardrobe': [
                    {
                        src: '<<case "Changing Room">>',
                        applybefore: '<<case "MND Changing Room">>\n\t\t\t<<getouticon>><<link [[离开|MND Room]]>><<cleanupOnWardrobeExit>><</link>>\n\t\t'
                    }
                ]
            }
        });

        console.info('[MND] 1.1 location and wardrobe patches registered.');
    } catch (e) {
        console.error('[MND] Failed to register MapleBirch patches.', e);
    }
})();
