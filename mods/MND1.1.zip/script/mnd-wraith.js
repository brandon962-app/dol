(function () {
    'use strict';

    /* ===== 可调参数 ===== */
    const WRAITH_MIN_DAY = 32;     // 游戏第几天起才可能出现（与本体 checkWraith 一致）
    const WRAITH_BASE_CHANCE = 35; // 基础触发概率(%)；本体 rngWraith 只有 2%~4%
    const WRAITH_LUST_STEP = 10;   // 怨灵「执念」每 10 点 +1%
    const WRAITH_MAX_CHANCE = 90;  // 概率上限(%)

    window.MND = window.MND || {};
    const MND = window.MND;

    function bloodMoon() {
        try { return typeof Time !== 'undefined' && typeof Time.isBloodMoon === 'function' && !!Time.isBloodMoon(); }
        catch (e) { return false; }
    }

    /** 本体 checkWraith 已把 $wraith.state 初始化，且已过第 32 天。 */
    MND.wraithUnlocked = function () {
        try {
            if (typeof V === 'undefined' || !V.wraith || !V.wraith.state) return false;
            if (typeof Time === 'undefined' || Time.days == null || Time.days < WRAITH_MIN_DAY) return false;
            return true;
        } catch (e) { return false; }
    };

    /** 豪华客房 + 已解锁 + 今天还没看过时显示「好像有什么在注视着你」；血月也允许进入，由入口分支处理附身。 */
    MND.wraithOptionVisible = function () {
        try {
            if (!V.mnd || V.mnd.room !== 'deluxe') return false;
            if (V.mnd.deluxeWraithDay === Time.days) return false;
            return MND.wraithUnlocked();
        } catch (e) { return false; }
    };

    MND.wraithChance = function () {
        let lust = 0;
        try { lust = Number(C.npc['Ivory Wraith'].lust) || 0; } catch (e) { /* ignore */ }
        return Math.min(WRAITH_MAX_CHANCE, WRAITH_BASE_CHANCE + Math.floor(lust / WRAITH_LUST_STEP));
    };

    /** 非血月豪华客房遭遇使用本 Mod 当前随机判定；血月入口改为直接调用原版附身流程。 */
    MND.rollWraith = function () {
        MND.ensureState();
        const hit = MND.wraithUnlocked() && !bloodMoon() && (Math.random() * 100 < MND.wraithChance());
        V.mnd.wraithEncounter = !!hit;
        return hit;
    };

    function patchWraithExit() {
        if (window.MND_WRAITH_EXIT_PATCHED) return true;
        if (typeof Macro === 'undefined' || typeof Macro.get !== 'function') return false;

        const macro = Macro.get('exitWraith');
        if (!macro || typeof macro.handler !== 'function') return false;

        const original = macro.handler;
        macro.handler = function () {
            try {
                if (typeof V !== 'undefined' && V.mnd && V.mnd.wraithReturn === true) {
                    const text =
                        '你看到那个身影靠近客房的镜子。祂的身影忽明忽暗。' +
                        '<br><br>' +
                        '"<span class="wraith">我的时间已经结束了。但是你永远无法摆脱我。</span>"祂咯咯笑着。' +
                        '<br><br>' +
                        '那个身影消失了。' +
                        '<br><br>' +
                        '<i>是梦吗？还是真实？</i>' +
                        '<br><br>' +
                        '你暂时安全了。' +
                        '<br><br>' +
                        '<<link [[回神|MND Room]]>>' +
                        '<<set V.mnd.wraithReturn to false>>' +
                        '<<endWraith>><<endcombat>>' +
                        '<</link>>';
                    new Wikifier(this.output, text);
                    return;
                }
            } catch (e) {
                console.warn('[MND Wraith] failed to handle Wraith exit', e);
            }
            return original.apply(this, arguments);
        };

        window.MND_WRAITH_EXIT_PATCHED = true;
        return true;
    }

    let tries = 0;
    (function waitForExitMacro() {
        if (patchWraithExit() || ++tries > 400) return;
        setTimeout(waitForExitMacro, 50);
    })();
})();
