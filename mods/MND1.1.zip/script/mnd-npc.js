/*
 * Midsummer Night Dream 0.3.32 - 奈奈 NPC registration
 *
 * 通过 maplebirchAddon 的 params.script 加载（见 boot.json）。
 * 用框架的 maplebirch.npc.add 注册「奈奈」，由框架在读档 / 每个段落开始时
 * 把她注入 V.NPCName、setup.NPCNameList、C.npc，时机早于游戏本体的 backComp。
 * 因此不再需要 TweeReplacer 去改 variablesStatic / npcNamed。
 */
(function () {
    'use strict';

    const NANA = '奈奈';

    try {
        if (typeof maplebirch === 'undefined' || !maplebirch.npc || typeof maplebirch.npc.add !== 'function') {
            console.error('[MND] maplebirch.npc.add is unavailable; 奈奈 was not registered.');
            return;
        }

        const ok = maplebirch.npc.add(
            {
                nam: NANA,
                title: '口悪者',
                description: NANA,
                insecurity: 'looks',
                gender: 'f',
                pronoun: 'f',
                type: 'human',
                adult: 1,
                teen: 0,
                eyeColour: 'red',
                hairColour: 'silver',
                vagina: 'vagina',
                breastsize: 2,
                bottomsize: 2,
                pregnancyAvoidance: 100,
                pregnancy: {},
                virginity: { anal: true, oral: true, penile: true, vaginal: true, hand: true, thigh: true },
                chastity: { penis: '', vagina: '', anus: '' },
                init: 0
            },
            {
                // 社交栏：只显示「好感」。
                // 官方老师（西里斯、温特）的 lust 一直是 0，所以不会出现性欲条；
                // 这里额外用 requirements:false 明确隐藏，哪怕数值被别处碰到也不显示。
                love: { maxValue: 100 },
                loveAlias: ['Affection', '好感'],
                lust: { requirements: false }
            }
        );

        if (ok) console.info('[MND] 奈奈 registered via maplebirch.npc.add.');
        else console.warn('[MND] maplebirch.npc.add returned false for 奈奈 (already registered?).');
    } catch (e) {
        console.error('[MND] Failed to register 奈奈.', e);
    }
})();
