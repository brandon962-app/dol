(function () {
    'use strict';

    const NAMES = [
        'Robin',
        'Whitney',
        'Eden',
        'Kylar',
        'Avery',
        'Alex',
        'Sydney'
    ];

    const LABELS = {
        'Robin': '罗宾',
        'Whitney': '惠特尼',
        'Eden': '伊甸',
        'Kylar': '凯拉尔',
        'Avery': '艾弗里',
        'Alex': '艾利克斯',
        'Sydney': '悉尼'
    };

    // Do not abort if MapleBirch has not exposed simpleFrameworks yet.
    // The framework hooks are registered lazily below.
    window.MND = window.MND || {};
    const MND = window.MND;
    MND.names = NAMES.slice();

    MND.ensureState = function () {
        V.mnd = V.mnd || {};
        if (!Array.isArray(V.mnd.invitees)) V.mnd.invitees = [];
        if (V.mnd.nanaLove === undefined) V.mnd.nanaLove = 0;
        if (V.mnd.nanaMet === undefined) V.mnd.nanaMet = false;
        if (V.mnd.room === undefined) V.mnd.room = null;
        if (V.mnd.arrived === undefined) V.mnd.arrived = false;
        if (V.mnd.encounterInit === undefined) V.mnd.encounterInit = false;
        if (V.mnd.rewardedForCombat === undefined) V.mnd.rewardedForCombat = false;
        if (V.mnd.encounterSite === undefined) V.mnd.encounterSite = null;
        if (V.mnd.lastGuestCount === undefined) V.mnd.lastGuestCount = 0;
        if (V.mnd.lastGuestNames === undefined) V.mnd.lastGuestNames = [];
        if (V.mnd.morningReady === undefined) V.mnd.morningReady = false;
        if (V.mnd.morningWarned === undefined) V.mnd.morningWarned = false;
        if (V.mnd.inWardrobe === undefined) V.mnd.inWardrobe = false;
        if (V.mnd.inviteSentAt === undefined) V.mnd.inviteSentAt = null;
        if (!Array.isArray(V.mnd.activeNpcNames)) V.mnd.activeNpcNames = [];
    };

    MND.label = function (name) {
        return LABELS[name] || name;
    };

    MND.isMorningCheckout = function () {
        MND.ensureState();
        return V.mnd.morningReady === true && Time.hour >= 8;
    };

    MND.isLover = function (name) {
        return typeof isLoveInterest === 'function' && isLoveInterest(name);
    };

    MND.candidates = function () {
        return NAMES.filter(name => MND.isLover(name));
    };

    MND.canInviteAtLeast30Minutes = function () {
        const total = (Time.hour * 60) + Time.minute;
        const closing = 8 * 60;
        const minutesUntilClosing = total < closing
            ? closing - total
            : (24 * 60 - total) + closing;
        return minutesUntilClosing > 30;
    };

    MND.humanEncounterGroup = function () {
        MND.ensureState();
        return V.mnd.invitees.length > 0 && V.mnd.invitees.every(name => NAMES.includes(name));
    };

    /** 战斗前保证命名 NPC 的 chastity 结构完整（sydneyExpose 会直接对 chastity.penis/vagina 调 .includes）。 */
    MND.normalizeChastity = function (name) {
        const seen = [];
        try {
            if (Array.isArray(V.NPCName)) {
                const byName = V.NPCName.find(n => n && n.nam === name);
                if (byName) seen.push(byName);
            }
            if (typeof C !== 'undefined' && C.npc) {
                const viaC = C.npc[name];
                if (viaC && !seen.includes(viaC)) seen.push(viaC);
            }
        } catch (e) { console.warn('[MND] normalizeChastity lookup', name, e); }
        for (const npc of seen) {
            if (!npc.chastity || typeof npc.chastity !== 'object') npc.chastity = {};
            for (const k of ['penis', 'vagina', 'anus']) {
                if (npc.chastity[k] == null) npc.chastity[k] = '';
            }
        }
        return seen.length > 0;
    };

    /**
     * 本体的 sydneyExpose 在「首次移除贞操带肛塞」的一次性提示里会读临时变量 _sydneyStatus
     * （= T.sydneyStatus），它只由 statusCheck("Sydney") 设置。MND Encounter 是我们自己的段落，
     * 不会像本体 Sydney 场景那样先跑 statusCheck，所以第一次会 undefined.includes 报错。
     * 这里每次渲染前补一次（只写临时变量 T.*，不改存档）。
     */
    MND.refreshInviteeStatus = function () {
        try {
            MND.ensureState();
            if (typeof statusCheck !== 'function') return;
            if (V.mnd.invitees.includes('Sydney') && V.NPCNameList && V.NPCNameList.includes('Sydney')) {
                statusCheck('Sydney');
            }
        } catch (e) { console.warn('[MND] refreshInviteeStatus', e); }
    };

    MND.activateInvitees = function () {
        MND.ensureState();
        if (!Array.isArray(V.mnd.invitees) || V.mnd.invitees.length === 0) return false;
        if (typeof wikifier !== 'function') {
            console.error('[MND] Wikifier unavailable; cannot activate named NPCs.');
            return false;
        }
        for (const name of V.mnd.invitees) {
            MND.normalizeChastity(name);
            wikifier('npc', name, -1);
        }
        MND.refreshInviteeStatus();
        return true;
    };

    MND.clearStay = function () {
        MND.ensureState();
        V.mnd.room = null;
        V.mnd.invitees = [];
        V.mnd.arrived = false;
        V.mnd.encounterInit = false;
        V.mnd.rewardedForCombat = false;
        V.mnd.encounterSite = null;
        V.mnd.lastGuestCount = 0;
        V.mnd.lastGuestNames = [];
        V.mnd.morningReady = false;
        V.mnd.morningWarned = false;
        V.mnd.inWardrobe = false;
        V.mnd.inviteSentAt = null;
        if (Array.isArray(V.mnd.activeNpcNames) && typeof wikifier === 'function') {
            for (const name of V.mnd.activeNpcNames) {
                try { wikifier('endnpc', name); } catch (e) { console.warn('[MND] endnpc cleanup failed', name, e); }
            }
        }
        V.mnd.activeNpcNames = [];
        if (typeof V.bedGuest !== 'undefined') delete V.bedGuest;
    };



    const NANA = '奈奈';

    /*
     * 奈奈本体由 script/mnd-npc.js 通过 maplebirch.npc.add 注册。
     * 框架会在读档（Save.onLoad → loadInit）和每个段落开始时把她注入
     * V.NPCName / setup.NPCNameList / C.npc，早于游戏本体的 doVersionCheck → backComp，
     * 所以这里不再手动改 NPCNameList、V.NPCName，也不再调用 initCNPC()
     * （initCNPC 会把 C.npc 重置成"按下标取值"的版本，下标一错位就会得到 undefined）。
     * 本段只负责：按名字查到她、补全缺失字段、保持好感同步。
     */
    const STAT_DEFAULTS = { trust: 0, love: 0, dom: 0, lust: 0, rage: 0, trauma: 0, state: '' };

    MND._findNana = function () {
        try {
            if (Array.isArray(V.NPCName)) {
                const hit = V.NPCName.find(n => n && n.nam === NANA);
                if (hit) return hit;
            }
            if (typeof C !== 'undefined' && C.npc) return C.npc[NANA];
        } catch (e) { /* ignore */ }
        return undefined;
    };

    /** 保证「奈奈」条目存在且字段完整（只补缺，不覆盖已有数据）。 */
    MND.ensureNanaNpc = function () {
        try {
            if (typeof setup !== 'undefined') {
                // 不孕：跳过怀孕初始化
                if (setup.pregnancy) {
                    setup.pregnancy.infertile = setup.pregnancy.infertile || [];
                    if (!setup.pregnancy.infertile.includes(NANA)) setup.pregnancy.infertile.push(NANA);
                }
                setup.loveAlias = setup.loveAlias || {};
                if (typeof setup.loveAlias[NANA] !== 'function') setup.loveAlias[NANA] = function () { return '好感'; };
            }

            let npc = MND._findNana();
            if (!npc && typeof maplebirch !== 'undefined' && maplebirch.npc && typeof maplebirch.npc.injectModNPCs === 'function') {
                // 兜底：框架还没注入时主动触发一次（幂等）
                maplebirch.npc.injectModNPCs();
                npc = MND._findNana();
            }
            if (!npc) return null;

            if (npc.pregnancy == null || typeof npc.pregnancy !== 'object') npc.pregnancy = {};
            if (npc.type == null) npc.type = 'human';
            if (npc.pregnancyAvoidance == null) npc.pregnancyAvoidance = 100;
            if (!npc.virginity || typeof npc.virginity !== 'object') {
                npc.virginity = { anal: true, oral: true, penile: true, vaginal: true, hand: true, thigh: true };
            }
            if (!npc.chastity || typeof npc.chastity !== 'object') npc.chastity = {};
            for (const k of ['penis', 'vagina', 'anus']) {
                if (npc.chastity[k] == null) npc.chastity[k] = '';
            }
            for (const k of Object.keys(STAT_DEFAULTS)) {
                if (npc[k] == null) npc[k] = STAT_DEFAULTS[k];
            }
            // 奈奈只有「好感」，不使用性欲：始终清零（社交栏另有 lust 隐藏配置）
            npc.lust = 0;

            MND._patchRelationshipText();
            return npc;
        } catch (e) {
            console.warn('[MND] ensureNanaNpc', e);
            return null;
        }
    };

    /** 进店一次：标记认识奈奈（init=1），之后才出现在社交栏。 */
    MND.meetNana = function () {
        MND.ensureState();
        try {
            const npc = MND.ensureNanaNpc();
            if (npc) npc.init = 1;
            V.mnd.nanaMet = true;
        } catch (e) {
            console.warn('[MND] meetNana', e);
        }
    };

    MND.syncNanaLove = function () {
        MND.ensureState();
        V.mnd.nanaLove = Math.clamp(Number(V.mnd.nanaLove) || 0, 0, 100);
        try {
            const npc = MND.ensureNanaNpc();
            if (npc) npc.love = V.mnd.nanaLove;   // init 仅由 meetNana 设为 1
        } catch (e) {
            console.warn('[MND] syncNanaLove', e);
        }
    };

    MND._patchRelationshipText = function () {
        if (MND._relPatched) return;
        if (typeof Macro === 'undefined' || !Macro.get) return;
        const macro = Macro.get('relationshiptext');
        if (!macro || typeof macro.handler !== 'function') return;
        const original = macro.handler;
        macro.handler = function () {
            try {
                const tmp = State && State.temporary ? State.temporary : {};
                if (tmp.npc === NANA || tmp.npc === 'Nana') {
                    let love = (V.mnd && V.mnd.nanaLove != null) ? Number(V.mnd.nanaLove) : 0;
                    // 头像用 data URI，不依赖 ImageLoader 路径（避免社交栏裂图）
                    const _nanaIcon = '<img class="icon" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAACXBIWXMAAAsTAAALEwEAmpwYAAAHtElEQVRIib2WeXDU5RnHP7/d397ZI7ubkGwOwhHYRNCAUW4ZT6SoDBWLsYo3nlSLztQRCx4zipWO41WpHSsFFSm2YutRORQ5FKwmhtsEgpuQzSabczd7/PZ3vP3DqVNFJS1OvzPPP+98n/fzvM+87zMvDEFrr1w1as3834WG4h2qTEMxCd2Y4xyW175+8erNz5Qs8/7fwAs33P50Kpac6i7yXVB01ZgP5hKUTxVsPpnh5bpVk66YOu8yDKEORvoPF48vv6qiYlLmL5+9ufNUwD9Y+e8nPy4LQ9yVXxqs848eRkdbtL833oPst10LrDgVsDQU09prXhlhGH23SZLyC6ffb7OHvMbhVRvviX25pyNLVtlLpHE7HPvRwTdA+dx5v352xJxplxRNqpacxflk2+JoqSyZvgTNO+uzRzd/8u72+j89sg7R8N8U8L16gOqzt971XErkxNfSVV2coLQuPnpyvbHMPP32U4YuoSz80dI/JoUQwsgZhprIClVRhZo9MXRdGEIIEd3aKFYEZz90Klzze1c/tlekdaELYWht/eKHwP8OIYSIbtwt7mfinf8Tdc3pNz+S3XNUCCGEms4J7UjPSaFqVhWqogkhhNjxwAuZmyid+r2n+q7Fl2944Y2y2upFIy+ZgGGRQRdIgznw2k/eJquMJCHsVq8lz1N540+nzjdt2P3XbScFr738ueuGTxlxnxSw09PcQ2jCcIQEUjIHThlM3/EQBJgsJkwmE91NnXz+xidSpKWdkrMq0JLp4bb3TS82sD/3nyknjExfieehwlIvsqFjc9mQJJDMJrCakeJpkE+csmabTHdTJztWbeazv+0mY85hdVpQexNi3GkVFefddvGT386RARqC80L+2qqnhKq64wcOOjpL83CqGuWTChFAti+Jq8SDaO5FTyrgtoGqgyQh274afmpWJ5lK4vO7sB3vwd3eRVfNaKk1cpTSlmMTvhPsr616IlAbnp+pKsax4yDZ+kMi4/JIst/DrqfWMxCJkUtlufDBRbj6cxhZ7avWD/cRbWhm3/rNOHxuXJ4iHBYJc0sU9UiU/EGNPKcF5wXhM/dmF685/cNnFn6j1YYQpsTAAMc/bhCGomKuCknSMBu6oiCOdjLr5vkMszjoboogVXhBF5h8Lr7c1cixHfUUV5ajd/YhawpK0sDoT5N/7hkMC7rwjh/O0ZYWcoo6pwsc37hcDw0UbjnSnxzvLykdY5XNJAb6SUf7KD5nIkGXC6Otl9Kzq/BMHA2yGeG2IuVZyCXTWPYep/onM7DFEoxaMJ38plakgT46CmXUlk4svRnyLQ5c4yodq5tVdetg04dfg1ekDymzamddPf3RRZWU5GOOD+KtHkk2mSN/ehXmiiBqaQCT1YKs6UiqgclixlnkxyLMGB095NWMxFZeRPy1bYjBFEZHH26fj8Dd87HVjiWw4ByUgfS0ru1/X3cEes0ASxgz46JbFj7qrypFOG04asPYw6UgDJINEXSrlcat+2n5+AuURA5VUWlvbKVpyz5ivWnKZ1ZjtdtpWrc1snP1Wy8U11ROK5k0Ht91s7BWhjAX+EBA2dhR5vifD2mbE19sMgFUVtbeWHZmmFQihZpR0FNpjJSCZ2QRvV3xyIbJ917RHWlPllUF+fKDAxzY3EDLrsMUlTvJJBN8unIjb17/6KYViy8NX3vs1eVMGTfgvXk2clkBelpBS2dRUhmsxV7KZ9RcCkgmgFDt2PPx2lFSGdSchqYZSLIZLTpA5N09vxkcI1/ksTncHQ2tBDJJitCwtsY4Wt+O2WzlrOV15E0bW3MECoBs9MPPdwIIVUPXDdScipLLkVZVRp1bW7mIgpAJwO73BFSho2kauqYhEMgWE/s21avNMcnprxw9ZbRsUNbUStCcInCsjUqXSoWuUOmzC4vPzojTw4VBCALsen7D8+1vf4pss6CqKtmMQqqzl0SsB1vAixOv1QSQ7R9M2M1WbHY7DocDWRMcfGc/HV2Dlmm3nvNEsc0bRmgU1s1EUsFcMxqr10tocphA0Cn98/oV7evvfmLZ7AtXVv1h7ovBB9j59o7H164mlsKQzWSSKZJftJKJdBCPxkgQHZABop8cWt7w0rtL3KGArCZTmVhLn5xQ7cV5Y72kk4Oe6poSedgdczHl5xGqHYval8QS9GLLzyN1vId9S1d3TfjZlePLy/IfbjsebwAm1u14+nrPfaHySb+sO0/yWTHy7Aifm9YP6mPvkB74xsS/CKybIPfwuKWh4nCp3K3aLTVNn916/vO33GuZOQ4BSIkceKwA6LrAZJLE/sfWS5HOpGELeExaQiXZ2v/agg131gGWdZPvWBmcXXtnyZTxpkRzO/9Y8ttHHlS2Lzvpn0uAqW3xswfK7vl5eGB3I4dXvbkxVV7gdhXm15y9/IaAlGclte0gW+YtW9l88eWv9x9uO7bA293oL/VnhKLalcYjv5rTvOb9GwvmLEj19He/ZOx6pRX0IX329lBV6K6afJnaFj9wxuBbHwPcBeEFdz+7vXzGhILDr763rWD3obfdHqeuGSIhrNZrxiycOzMebc90rNtSc0bs9aZv7zkk8PfpfnC4COYtpTsOcHDcTTZJwi4Mw5DdzqlqT+Lz05rXdJ4K40fXvwCaXOfSSTcpEQAAAABJRU5ErkJggg==" alt="" style="width:1.5em;height:1.5em;vertical-align:middle;">';
                    let html;
                    if (love >= 81) {
                        html = '奈奈 佩服你<span class="green">异于常人的体质</span>。 ' + _nanaIcon;
                    } else if (love >= 51) {
                        html = '奈奈 认为你<span class="pink">欲望强的令人不安</span>。 ' + _nanaIcon;
                    } else if (love >= 1) {
                        html = '奈奈 认为你是<span class="red">超绝冤大头</span>。 ' + _nanaIcon;
                    } else {
                        // 好感 0：刚认识、尚未闲聊
                        html = '奈奈 对你没什么看法。 ' + _nanaIcon;
                    }
                    // 直接插入 HTML（含 data URI 头像），不用 wiki 以免被过滤
                    if (typeof jQuery !== 'undefined') jQuery(this.output).append(html);
                    else if (typeof $ !== 'undefined') $(this.output).append(html);
                    else {
                        const d = document.createElement('span');
                        d.innerHTML = html;
                        this.output.appendChild(d);
                    }
                    return;
                }
            } catch (e) {}
            return original.apply(this, arguments);
        };
        MND._relPatched = true;
    };

    MND.installFrameworkHooks = function () {
        if (MND._frameworkHooksInstalled) return true;
        if (typeof simpleFrameworks === 'undefined' || typeof simpleFrameworks.addto !== 'function') return false;
        simpleFrameworks.addto('iModHeader', 'mndInit');
        MND._frameworkHooksInstalled = true;
        return true;
    };

    function waitForFramework() {
        if (MND.installFrameworkHooks()) return;
        setTimeout(waitForFramework, 50);
    }
    waitForFramework();

    if (typeof $ !== 'undefined' && $.fn) {
        $(document).on(':storyready :passageinit', function () {
            try { if (typeof V !== 'undefined' && V && V.mnd) { MND.ensureNanaNpc(); } } catch (e) {}
        });
    }

    console.info('[MND] 1.1 loaded: hours + 奈奈 social bar.');
})();
