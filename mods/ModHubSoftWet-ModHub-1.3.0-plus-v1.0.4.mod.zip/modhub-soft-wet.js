"use strict";
(() => {
  // compat/modhub-soft-wet/modhub-soft-wet.ts
  (function() {
    "use strict";
    if (window.ModHubSoftWet) return;
    const spec = {
      id: "ModHubSoftWet",
      version: "1.0.4",
      target: { name: "ModHub", versions: [">=1.3.0"] },
      scope: ['#customOverlay[data-overlay="modloader"]'],
      fingerprint: {
        id: "modhub-overlay-1.3.0",
        safe: [[":scope>#customOverlayContent"], ["#overlayTabs.modhub-modloader-tabs"]],
        required: [["#modHubModManageContainer.modhub-container", "#modHubModMarketContainer.modhub-container", "#modHubReadmeContainer.modhub-container", "#modHubLogContent.modhub-log-wrapper", "#modHubHelpContainer.modhub-container.modhub-help"]]
      },
      roles: [
        { role: "page-shell", selectors: [":scope"], safe: true },
        { role: "toolbar", selectors: ["#overlayTabs.modhub-modloader-tabs"], safe: true },
        { role: "title", selectors: ["#customOverlayTitle"], safe: true },
        { role: "toolbar", selectors: [".modhub-sticky-toolbar"], all: true },
        { role: "compact-row", selectors: [".modhub-list .modhub-item"], all: true },
        { role: "card", selectors: [".modhub-market-card"], all: true },
        { role: "section", selectors: [".modhub-section,.modhub-stat-card,.modhub-help-section,.modhub-help-home-block"], all: true },
        { role: "danger-action", selectors: [".modhub-btn-group .btn-delete"], all: true }
      ]
    };
    const toolsSpec = {
      id: "ModHubSoftWetTools",
      version: "1.0.4",
      target: spec.target,
      scope: ['#modHubManagerToolsMenu.modhub-manager-tools-menu[role="menu"]'],
      fingerprint: { id: "modhub-manager-tools-1.7.6", safe: [[":scope"]], required: [[":scope>.modhub-manager-tool-row:first-child>.modhub-manager-tool-action"]] },
      roles: [{ role: "page-shell", selectors: [":scope"], safe: true }, { role: "toolbar", selectors: [".modhub-manager-tool-row"], all: true }]
    };
    const modalSpec = {
      id: "ModHubSoftWetModal",
      version: "1.0.4",
      target: spec.target,
      scope: [".modhub-modal-backdrop"],
      fingerprint: {
        id: "modhub-modal-1.8.0",
        safe: [[':scope>.modhub-modal-dialog[role="dialog"][aria-modal="true"]']],
        required: [[".modhub-modal-header"], [".modhub-modal-body"], [".modhub-modal-footer"]]
      },
      roles: [{ role: "section", selectors: [":scope>.modhub-modal-dialog"] }]
    };
    const restoreSpec = {
      id: "ModHubSoftWetRestore",
      version: "1.0.4",
      target: spec.target,
      scope: ["#modHubRestorePanelOverlay.modhub-restore-panel-overlay"],
      fingerprint: {
        id: "modhub-restore-panel-2.0.2",
        safe: [[':scope>section#modHubRestorePanel.modhub-restore-panel[role="dialog"][aria-modal="true"]']],
        required: [[":scope>section#modHubRestorePanel>.modhub-restore-panel-header"], [":scope>section#modHubRestorePanel>.modhub-restore-panel-body"], [":scope>section#modHubRestorePanel>.modhub-restore-panel-footer"]]
      },
      roles: [{ role: "section", selectors: [":scope>section#modHubRestorePanel.modhub-restore-panel"] }]
    };
    let owner = null;
    let handle = null, tools = null, modal = null, restore = null, reason = "runtime-unavailable";
    function attach() {
      const ui = window.DoLGameUI?.ui;
      if (owner === ui) return;
      handle?.destroy();
      tools?.destroy();
      modal?.destroy();
      restore?.destroy();
      owner = ui;
      handle = tools = modal = restore = null;
      reason = ui ? "runtime-api-unsupported" : "runtime-unavailable";
      if (ui?.apiVersion !== 1 || typeof ui.getCapabilities !== "function" || typeof ui.registerStyleAdapter !== "function") return;
      try {
        if (!ui.getCapabilities().styleAdapters) {
          reason = "style-adapter-unavailable";
          return;
        }
      } catch {
        reason = "runtime-capability-failed";
        return;
      }
      try {
        handle = ui.registerStyleAdapter(spec);
        tools = ui.registerStyleAdapter(toolsSpec);
        modal = ui.registerStyleAdapter(modalSpec);
        restore = ui.registerStyleAdapter(restoreSpec);
      } catch {
        reason = "registration-failed";
      }
    }
    document.addEventListener("dol-ui-runtime-ready", attach);
    window.ModHubSoftWet = Object.freeze({
      getDiagnostics: () => handle ? Object.freeze({ ...handle.getDiagnostics(), components: { tools: tools?.getDiagnostics(), modal: modal?.getDiagnostics(), restore: restore?.getDiagnostics() } }) : Object.freeze({ status: "inactive", reason }),
      destroy() {
        document.removeEventListener("dol-ui-runtime-ready", attach);
        handle?.destroy();
        tools?.destroy();
        modal?.destroy();
        restore?.destroy();
        handle = tools = modal = restore = null;
        owner = null;
        delete window.ModHubSoftWet;
      }
    });
    attach();
  })();
})();
