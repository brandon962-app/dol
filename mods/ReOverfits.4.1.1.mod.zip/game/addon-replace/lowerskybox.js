$(document).on(':passageend', () => {
  if (V.options.LowerSkyBox == null) V.options.LowerSkyBox = true;
  if (V.options.LowerSkyBox) {
    $('#img').css('overflow', 'hidden');
    $('#canvasSkybox').css('zIndex', 5);
  } else {
    $('#img').css('overflow', 'visible');
    $('#canvasSkybox').css('zIndex', 0);  
  }
});